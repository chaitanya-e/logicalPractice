package comptech.ivy.springboot.restservices;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalManagementPort;
import org.springframework.boot.test.web.server.LocalServerPort;

import comptech.ivy.springboot.restservices.model.Address;
import comptech.ivy.springboot.restservices.model.Employee;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT) // for defined port 8090
class SpringTestRestTemplateTests {

	// TestRestTemplate testRestTemplate = new TestRestTemplate();

	@Autowired
	private TestRestTemplate testRestTemplate;

	@LocalServerPort
	private int port;

	@Test
	void testGetEmployeeByID() {
		// Arrange
		final String baseURL = "http://localhost:" + port + "/individualEmployee/11220";
		var employee = Employee
				.builder().employeeId(11220).name("First Employee").jobTitle("Engineer").address(Address.builder()
						.addressline1("123, james street").city("Richmond").state("Virginia").zipcode(544332).build())
				.build();

		// Act
		var response = this.testRestTemplate.getForObject(baseURL, Employee.class);

		// Assert
		assertEquals(response, employee);
	}

	@Test
	void testGetEmployeeById() {
		// Arrange
		final String base_URL = "http://localhost:" + port + "/allEmployees";
		var employee = Employee
				.builder().employeeId(11220).name("First Employee").jobTitle("Engineer").address(Address.builder()
						.addressline1("123, james street").city("Richmond").state("Virginia").zipcode(544332).build())
				.build();

		// Act
		var responseEntity = this.testRestTemplate.getForObject(base_URL, Employee[].class);
		var employeeResponse = Arrays.stream(responseEntity).filter(x -> x.getEmployeeId() == 11220).findFirst().get();

		// Assert
		assertEquals(employeeResponse, employee);
	}

	@Test
	void testPostNewEmployee() {
		// Arrange
		var employee = Employee
				.builder().employeeId(11225).name("Fifth Employee").jobTitle("Architect").address(Address.builder()
						.addressline1("666, jj street").city("Auckland").state("New Zealand").zipcode(54433).build())
				.build();
		final String base_URL = "http://localhost:" + port + "/addEmployee";

		// Act
		var responseEntity = this.testRestTemplate.postForObject(base_URL, employee, Employee[].class);
		var responseEmployeeForAssert = Arrays.stream(responseEntity).filter(x -> x.getEmployeeId() == 11225)
				.findFirst().get();

		// Assert
		assertEquals(employee, responseEmployeeForAssert);
	}
}

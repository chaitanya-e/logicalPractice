package comptech.ivy.springboot.restservices;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import comptech.ivy.springboot.restservices.model.Address;
import comptech.ivy.springboot.restservices.model.Employee;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class RestAssuredTestsUsingSpringBoot {
	
	@LocalServerPort
	private int port;
	
	@Value("${base.url}")
	private String base_URL;
	
	@Test
	void simpleGetTestUsingRestAssured()
	{
		given()
			.baseUri(base_URL)
			.port(port)
			.basePath("/individualEmployee/11220")
		.when()
			.get()
		.then()
			.assertThat()
			.body("name", Matchers.equalTo("First Employee"));
		
	}
	
	@Test
	void testGetAnotherWay()
	{
		var employee = Employee.builder().employeeId(11220).name("First Employee").jobTitle("Engineer")
		.address(Address.builder().addressline1("123, james street").city("Richmond").state("Virginia")
				.zipcode(544332).build()).build();
		
		//Arrange
		var response = given()
			.baseUri(base_URL)
			.port(port)
			.basePath("/individualEmployee/11220")
		.when()
			.get();
		
		//Act
		var defragmenting_response = response.body().as(Employee.class);
		
		//Assert
		assertEquals(defragmenting_response, employee);
		
	}
	
	@Test
	void testPostRequestRestAssured()
	{
		var employee = Employee
				.builder().employeeId(11225).name("Fifth Employee").jobTitle("Architect").address(Address.builder()
						.addressline1("666, jj street").city("Auckland").state("New Zealand").zipcode(54433).build())
				.build();
		
		var responseEntity = given()
			.baseUri(base_URL)
			.port(port)
			.basePath("/addEmployee")
			.contentType("application/json")
			.body(employee)
		.when()
			.post();
		
		var defragmentedResponse = responseEntity.body().as(Employee[].class);
		
		var expectedEmployeeResponse = Arrays.stream(defragmentedResponse).filter(x -> x.getEmployeeId() == 11225)
				.findFirst().get();
		
		assertEquals(employee, expectedEmployeeResponse);
	}
	
	@Test
	void testPutRequestRestAssured()
	{
		var employee = Employee
				.builder().employeeId(11220).name("Sizth Employee").jobTitle("Architect").address(Address.builder()
						.addressline1("666, jj street").city("Auckland").state("New Zealand").zipcode(54433).build())
				.build();
		
		var responseEntity = given()
			.baseUri(base_URL)
			.port(port)
			.basePath("/employeeUpdate/11220")
			.contentType("application/json")
			.body(employee)
		.when()
			.put();
		
		var defragmentedResponse = responseEntity.body().as(Employee.class);
		
		//var expectedEmployeeResponse = Arrays.stream(defragmentedResponse).filter(x -> x.getEmployeeId() == 11225)
		//		.findFirst().get();
		
		assertEquals(employee, defragmentedResponse);
	}
}

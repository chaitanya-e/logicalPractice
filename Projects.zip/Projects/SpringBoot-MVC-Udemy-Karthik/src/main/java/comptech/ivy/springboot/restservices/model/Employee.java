package comptech.ivy.springboot.restservices.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Employee {
	
	private String name;
	private int employeeId;
	private String jobTitle;
	private Address address;
	
	@Override
	public String toString()
	{
		return "name - " + name +
				"; employeeId - " +employeeId + 
				"; jobTitle - " +jobTitle +
				"; Address - " + address;
	}
}

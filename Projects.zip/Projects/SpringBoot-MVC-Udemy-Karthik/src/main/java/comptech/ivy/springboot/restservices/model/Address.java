package comptech.ivy.springboot.restservices.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Address {
	private String addressline1;
	private String city;
	private String state;
	private int zipcode;
}

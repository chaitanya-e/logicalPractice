package comptech.ivy.springboot.restservices.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import comptech.ivy.springboot.restservices.model.Address;
import comptech.ivy.springboot.restservices.model.Employee;

@Service
public class EmployeeService {

	List<Employee> employeeListOuter = new ArrayList<>(
			List.of(Employee.builder().employeeId(11220).name("First Employee").jobTitle("Engineer")
					.address(Address.builder().addressline1("123, james street").city("Richmond").state("Virginia")
							.zipcode(544332).build())
					.build(),
					Employee.builder().employeeId(11221).name("Second Employee").jobTitle("Jr Engineer")
							.address(
									Address.builder().addressline1("234, james street").city("Kansas").state("Texas")
											.zipcode(54434).build())
							.build(),
					Employee.builder().employeeId(11222).name("Third Employee").jobTitle("Sr Engineer")
							.address(Address.builder().addressline1("345, james street").city("Norfolk")
									.state("Newyork").zipcode(34455).build())
							.build()));

	public Employee getEmployeeById(int id) {
		return employeeListOuter.stream().filter(x -> x.getEmployeeId() == id).findFirst().get();
	}

	public List<Employee> getAllEmployeesAsList() {
		return employeeListOuter;
	}

	public List<Employee> addEmployeeAndReturnAllAsList(Employee employee) {
		System.out.println("before adding");
		System.out.println(employee.builder().build().toString());
		employeeListOuter.add(employee);
		return employeeListOuter;
	}

	public Employee updateAndReturnEmployee(int employeeId, Employee employee) {
		Employee updatedEmployee = employeeListOuter.stream().filter(x -> x.getEmployeeId() == employeeId)
											.peek(o -> o.setName(employee.getName()))
											.peek(o -> o.setJobTitle(employee.getJobTitle()))
											.peek(o -> o.setAddress(employee.getAddress()))
											.findFirst().get();
		return updatedEmployee;
	}

	public List<Employee> deleteAndGetRemainingEmployees(int id) {
		employeeListOuter.removeIf(x -> x.getEmployeeId() == id);
		return employeeListOuter;
	}
	
	

}

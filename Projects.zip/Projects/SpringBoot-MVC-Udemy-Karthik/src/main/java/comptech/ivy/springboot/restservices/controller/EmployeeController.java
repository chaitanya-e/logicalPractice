package comptech.ivy.springboot.restservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import comptech.ivy.springboot.restservices.model.Employee;
import comptech.ivy.springboot.restservices.services.EmployeeService;

@RestController
public class EmployeeController {

	/*
	 * List<Employee> employeeListOuter = new ArrayList<>(List.of(
	 * Employee.builder().employeeId(11220).name("First Employee").jobTitle(
	 * "Engineer").address(Address.builder()
	 * .addressline1("123, james street").city("Richmond").state("Virginia").zipcode
	 * (544332).build()) .build(),
	 * Employee.builder().employeeId(11221).name("Second Employee").
	 * jobTitle("Jr Engineer").address(Address.builder()
	 * .addressline1("234, james street").city("Kansas").state("Texas").zipcode(
	 * 54434).build()) .build(),
	 * Employee.builder().employeeId(11222).name("Third Employee").
	 * jobTitle("Sr Engineer").address(Address.builder()
	 * .addressline1("345, james street").city("Norfolk").state("Newyork").zipcode(
	 * 34455).build()) .build() ));
	 * 
	 * @RequestMapping("/employee-test") public String getEmployee() { return
	 * "This is the return data.use localhost:8090/employee to view the return data"
	 * ; }
	 * 
	 * @RequestMapping("/") public String getEmpty() { return "Empty URI"; }
	 * 
	 * @RequestMapping("/employeeData") public Employee employeeData() { return
	 * Employee
	 * .builder().employeeId(11220).name("First Employee").jobTitle("Engineer").
	 * address(Address.builder()
	 * .addressline1("123, james street").city("Richmond").state("Virginia").zipcode
	 * (544332).build()) .build(); }
	 * 
	 * @RequestMapping("/allEmployeesData") public List<Employee> allEmployeesData()
	 * { List<Employee> employeeList = new ArrayList<>(List.of(
	 * Employee.builder().employeeId(11220).name("First Employee").jobTitle(
	 * "Engineer").address(Address.builder()
	 * .addressline1("123, james street").city("Richmond").state("Virginia").zipcode
	 * (544332).build()) .build(),
	 * Employee.builder().employeeId(11221).name("Second Employee").
	 * jobTitle("Jr Engineer").address(Address.builder()
	 * .addressline1("234, james street").city("Kansas").state("Texas").zipcode(
	 * 54434).build()) .build(),
	 * Employee.builder().employeeId(11222).name("Third Employee").
	 * jobTitle("Sr Engineer").address(Address.builder()
	 * .addressline1("345, james street").city("Norfolk").state("Newyork").zipcode(
	 * 34455).build()) .build() )); return employeeList; }
	 * 
	 * @RequestMapping("/individualEmployee/{id}") public Employee
	 * getIndividualEmployee(@PathVariable int id) { return
	 * employeeListOuter.stream().filter(x -> x.getEmployeeId() ==
	 * id).findFirst().get(); }
	 */

	/*
	 * @RequestMapping("/employee-test") public String getEmployee() { return
	 * "This is the return data.use localhost:8090/employee to view the return data"
	 * ; }
	 * 
	 * @RequestMapping("/employeeData") public Employee employeeData() { return
	 * Employee
	 * .builder().employeeId(11220).name("First Employee").jobTitle("Engineer").
	 * build(); }
	 */

	@Autowired
	private EmployeeService employeeService;

	@RequestMapping("/individualEmployee/{id}")
	public Employee getIndividualEmployee(@PathVariable int id) {
		return employeeService.getEmployeeById(id);
	}

	@RequestMapping(method=RequestMethod.GET, value = "/allEmployees")
	public List<Employee> getAllEmployees() {
		return employeeService.getAllEmployeesAsList();
	}

	// To be checked
	@RequestMapping(method = RequestMethod.POST, value = "/addEmployee")
	public List<Employee> addEmployeeAndReturnAll(@RequestBody Employee employee) {
		System.out.println("From controller");
		System.out.println(employee.toString());
		return employeeService.addEmployeeAndReturnAllAsList(employee);
	}

	@PutMapping("/employeeUpdate/{id}")
	public Employee updateEmployee(@RequestBody Employee employee, @PathVariable int id) {
		System.out.println(id);
		return employeeService.updateAndReturnEmployee(id, employee);
	}

	@DeleteMapping("/deleteEmployee/{id}")
	public List<Employee> deleteAndGetRemainingEmployees(@PathVariable int id) {
		return employeeService.deleteAndGetRemainingEmployees(id);
	}
}

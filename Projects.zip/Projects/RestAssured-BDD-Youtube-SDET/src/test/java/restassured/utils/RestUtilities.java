package restassured.utils;

import org.apache.commons.lang3.RandomStringUtils;

public class RestUtilities {
	public String getName()
	{
		return "PrefixUserName" + RandomStringUtils.randomAlphabetic(3);
	}
	
	public String getJobTitle()
	{
		return "PrefixJobTitle" + RandomStringUtils.randomAlphabetic(5);
	}
}

package restassured.tests;

import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import restassured.utils.RestUtilities;

public class PostRequest {
	HashMap<String, String> requestBodyMap; 
	RestUtilities ru;
	String name, job;
	
	@BeforeClass
	public void createPostRequestData()
	{
		
		requestBodyMap = new HashMap<String, String>();
		ru = new RestUtilities();
		name = ru.getName();
		job = ru.getJobTitle();
		requestBodyMap.put("name", name);
		requestBodyMap.put("job", job );
		
		RestAssured.baseURI = "https://reqres.in/";
		RestAssured.basePath = "/api/users";
	}
	
	@Test
	public void sendPostRequest()
	{
		given()
		.contentType("application/json")
		.body(requestBodyMap)
		.when()
		.post()
		.then()
		.statusCode(201)
		.and()
		.body("name", equalTo(name))
		.body("job", equalTo(job));
	}
}

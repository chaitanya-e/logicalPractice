package restassured.tests;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

public class BasicAPIValidations {

	@Test
	public void statusCode()
	{
		
	}
}

package restassured.tests;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class DeleteRequest {
	@BeforeClass
	public void preReq()
	{
		RestAssured.baseURI = "https://reqres.in";
		RestAssured.basePath = "/api/users/2";
	}
	
	@Test
	public void delete()
	{
		given()
		.when()
		.delete()
		.then()
		.statusCode(204)
		.statusLine("HTTP/1.1 204 No Content")
		.log()
		.all();
	}
	
	@Test
	public void response()
	{
		Response r = given()
				.when()
				.delete()
				.then()
				.statusCode(204)
				.statusLine("HTTP/1.1 204 No Content")
				.log()
				.all().extract().response();
		
		String responseStr = r.asString();
		Assert.assertEquals(responseStr.contains(""), true);
	}
}

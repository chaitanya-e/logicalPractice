package restassured.tests;

import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import restassured.utils.RestUtilities;

public class PutRequest {
	HashMap <String, String> requestBody;
	RestUtilities ru;
	@BeforeClass
	public void setPutBody()
	{
		RestAssured.baseURI = "https://reqres.in";
		RestAssured.basePath = "/api/users/2";
		
		requestBody = new HashMap<String, String>();
		requestBody.put("name", "morpheus");
		requestBody.put("job", "zion resident");
		ru = new RestUtilities();
	}
	
	@Test
	public void putRequest()
	{
		Response response = given()
		.contentType("application/json")
		.body(requestBody)
		.when()
		.put()
		.then()
		.assertThat()
		//.body("name", equalTo("morpheus"))
		//.and()
		//.body("job", equalTo("zion resident"))
		//.and()
		.body("updatedAt", containsString("2022-10-27"))
		.and()
		.statusCode(200)
		.and()
		.header("Content-Type", equalTo("application/json; charset=utf-8"))
		//.log()
		//.all()
		.extract()
		.response()
		;
		
		System.out.println(response.asPrettyString());
	}
}

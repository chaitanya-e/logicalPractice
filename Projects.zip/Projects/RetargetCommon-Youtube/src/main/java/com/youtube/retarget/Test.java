package com.youtube.retarget;

import org.json.JSONArray;

public class Test {
	public static void main(String[] args) {
		String[] s = { "flower", "flow", "abcd", "flowing" };
		
		int minlen = 9999;
		int index = 0, breakindex = 0;
		for (String s1 : s) {

			if (s1.length() < minlen) {
				minlen = s1.length();
				breakindex = index;
			}
			index++;
		}
		
		//4 - len
		//breakindex = 1
		

		boolean breakflag = false;
		String searchStr = s[breakindex];
		while (searchStr.length()>0) {
			String[] s4 = s;
			int hits = 0;
			for (String s3 : s4) {
				if (!s3.contains(searchStr))
				{
					searchStr = searchStr.substring(0,searchStr.length()-1);
					break;
				}
				else
					hits++;
			}
			
			if(hits==s4.length)
				break;
			
		}
		System.out.println("Common word is - "+searchStr);
		
		
		JSONArray ja1 = [
		                 {
		                	    "firstname": "Jim",
		                	    "lastname": "Brown",
		                	    "age": 28,
		                	    "address": {
		                	      "flatno": 203,
		                	      "road": "enclave",
		                	      "pin": 2345690
		                	    },
		                	    "sal": 20.98,
		                	    "married": true
		                	  },
		                	  {
		                	    "firstname": "Jim2",
		                	    "lastname": "Brown2",
		                	    "age": 29,
		                	    "address": {
		                	      "flatno": 2032,
		                	      "road": "enclave2",
		                	      "pin": 2345692
		                	    },
		                	    "sal": 20.982,
		                	    "married": false
		                	  },
		                	  {
		                	    "firstname": "Jim3",
		                	    "lastname": "Brown3",
		                	    "age": 23,
		                	    "address": {
		                	      "flatno": 2033,
		                	      "road": "enclave3",
		                	      "pin": 2345693
		                	    },
		                	    "sal": 20.983,
		                	    "married": true
		                	  },
		                	  {
		                	    "firstname": "Jim4",
		                	    "lastname": "Brown4",
		                	    "age": 24,
		                	    "address": {
		                	      "flatno": 2034,
		                	      "road": "enclave4",
		                	      "pin": 23456904
		                	    },
		                	    "sal": 20.984,
		                	    "married": false
		                	  },
		                	  {
		                	    "firstname": "Jim5",
		                	    "lastname": "Brown5",
		                	    "age": 25,
		                	    "address": {
		                	      "flatno": 2035,
		                	      "road": "enclave5",
		                	      "pin": 23456905
		                	    },
		                	    "sal": 20.985,
		                	    "married": true
		                	  }
		                	]

	}
}

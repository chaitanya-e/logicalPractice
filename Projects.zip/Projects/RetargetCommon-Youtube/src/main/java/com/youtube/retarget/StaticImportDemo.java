package com.youtube.retarget;

//import static com.youtube.retarget.UtilityClass.method1;
import static com.youtube.retarget.UtilityClass.*;

public class StaticImportDemo {
	public static void main(String[] args) {
		/*
		 * Without Static Import
		 * 
		 * UtilityClass u1 = new UtilityClass(); 
		 * u1.method1(); 
		 * u1.method2();
		 */
		
		/* With static import */
		method1();
		method2();
		System.out.println(variable1);
		
	}
}

package com.youtube.retarget;

public class UtilityClass {
	public static int variable1 = 20;

	public static void method1() {
		System.out.println("Inside Method 1");
	}
	
	public static void method2( ) {
		System.out.println("Inside Method 2");
		System.out.println(variable1);
	}
}

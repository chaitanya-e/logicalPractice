package com.youtube.retarget;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MethodChainingUsingStreams {

	public static void main(String[] args) {
		//Below is the input
		List<String> fruits = Arrays.asList("Apple", "Banana", "Orange", "Pineapple");
		System.out.println("Input ------> "+fruits);
		
		//Expected output is [Apple Fruit, Banana Fruit, Orange Fruit, Pineapple Fruit]
		
		//Novice Method
		/*
		 * List<String> modifiedName = new ArrayList<String>(); 
		 * for(String fruit : fruits) 
		 * { fruit = fruit + " Fruit"; 
		 * modifiedName.add(fruit); 
		 * }
		 * System.out.println("Output -----> "+modifiedName);
		 */
		
		//Streams Method
		/*
		 * Stream<String> fruitsStream = fruits.stream(); 
		 * Stream<String> fruitsStreamMap = fruitsStream.map(whateverInput -> whateverInput + " Fruit"); 
		 * List<String> newFruits = fruitsStreamMap.collect(Collectors.toList());
		 * System.out.println("Output -----> "+newFruits);
		 */
		
		//Streams with Method Chaining
		List<String> newFruits = fruits.stream().map(name -> name + " is a Fruit").collect(Collectors.toList());
		System.out.println("Output -----> "+newFruits);
	}

}

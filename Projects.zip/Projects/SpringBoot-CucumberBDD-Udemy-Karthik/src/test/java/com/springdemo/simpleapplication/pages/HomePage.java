package com.springdemo.simpleapplication.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.springframework.stereotype.Component;

@Component
public class HomePage extends BasePage {
	/*
	 * @Autowired 
	 * private WebDriver webdriver;
	 * 
	 */
	
	@FindBy(id="registerLink")
	private WebElement register;
	
	@FindBy(how=How.LINK_TEXT, using="Employee Details")
	private WebElement employeeDetails;
	
	@FindBy(linkText="")
	private WebElement test;
	
	@FindBy(id="loginLink")
	private WebElement login; 
	
	/*
	 * @PostConstruct 
	 * public void initHomePage() {
	 * 	System.out.println("HomePage constructor called");
	 * PageFactory.initElements(webdriver, this); 
	 * }
	 */
	public ALoginPage loginClick()
	{
		login.click();
		//System.out.println("Inside HomePage - login() -> Returns LoginPage");
		return new ALoginPage();
	}
	
	public void register()
	{
		
		register.click();
		//System.out.println("Inside HomePage - register()");
	}
	
	
	
	
	public boolean isEmployeeDetailsPresent()
	{
		if(employeeDetails.isDisplayed())
			return true;
		else
			return false;
	}
}

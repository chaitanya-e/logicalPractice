package com.springdemo.simpleapplication.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.stereotype.Component;

@Component
public class ALoginPage extends BasePage{
	/*
	 * @Autowired private WebDriver webdriver;
	 */
	
	@FindBy(id="UserName")
	private WebElement userName;
	
	@FindBy(id="Password")
	private WebElement password;
	
	@FindBy(xpath="//input[@type='submit']")
	private WebElement submit;
	
	public HomePage loginProcess(String userName, String password)
	{
		//this.userName.sendKeys(userName);
		//this.password.sendKeys(password);
		//System.out.println("Inside LoginPage - login(username, password) -> Returns HomePage");
		//System.out.println("username , password = " + userName +" , " + password);
		this.userName.sendKeys(userName);
		this.password.sendKeys(password);
		this.submit.click();
		return new HomePage();
	}

	/*
	 * @PostConstruct public void initLoginPage() {
	 * //System.out.println("LoginPage constructor called");
	 * PageFactory.initElements(webdriver, this); }
	 */
}

package com.springdemo.simpleapplication.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions
(
		features={"src/test/java/com/springdemo/simpleapplication/features"},
		glue= "com.springdemo.simpleapplication.steps"			)
public class TestRunner extends AbstractTestNGCucumberTests{
}

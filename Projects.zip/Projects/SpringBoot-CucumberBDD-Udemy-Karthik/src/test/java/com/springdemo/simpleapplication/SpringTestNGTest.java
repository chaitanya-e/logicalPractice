package com.springdemo.simpleapplication;

import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.springdemo.simpleapplication.pages.MainPage;

@SpringBootTest
public class SpringTestNGTest extends AbstractTestNGSpringContextTests{
	
	@Autowired
	private WebDriver webdriver;
	
	@Autowired
	private MainPage mainpage;
	
	@Value("${app.url}")
	private String url;
	
	@BeforeTest
	protected void setupWebDriver()
	{
		webdriver.navigate().to(url);
	}
	
	@Test
	public void test()
	{
		mainpage.performLogin();
	}
	
	//testng overrides spring therefore without below method web
	@BeforeClass(alwaysRun=true)
	@BeforeSuite(alwaysRun=true)
	@Override
	protected void springTestContextPrepareTestInstance() throws Exception
	{
		super.springTestContextPrepareTestInstance();
	}
	
}

package com.springdemo.simpleapplication.pages;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MainPage extends BasePage{
	/*
	 * public MainPage(HomePage homepage, ALoginPage loginpage) {
	 * System.out.println("Inside mainpage constructor"); this.homepage = homepage;
	 * this.loginpage = loginpage; }
	 */
	
	/*
	 * public MainPage() { System.out.println("Mainpage Constructor called"); }
	 */
	
	@Autowired
	HomePage homepage;
	
	@Autowired
	ALoginPage loginpage;
	
	@Value("${app.url}")
	public String applicationUrl;
	
	@Value("${app.url.login}")
	public String applicationUrlLogin;
	
	/*
	 * @Autowired private WebDriver webdriver;
	 */
	@Value("${login-username}")
	private String username;
	
	@Value("${password}")
	private String password;
	
	public void performLogin()
	{
		//homepage.login();
		//loginpage.login("username", "password");
		
		//webdriver.navigate().to(applicationUrl);
		
		homepage.loginClick();
		loginpage.loginProcess(username, password);
	}
}

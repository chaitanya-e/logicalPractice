package com.springdemo.simpleapplication.steps;

import org.springframework.beans.factory.annotation.Autowired;

import com.springdemo.simpleapplication.model.TestUserDetails;
import com.springdemo.simpleapplication.pages.ALoginPage;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;

public class HomeSteps {

	@Autowired
	private ALoginPage loginpage;

	@Autowired
	private TestUserDetails testuserdetails;

	@And("^I enter the following for Login$")
	public void i_enter_the_following_for_login(DataTable datatable) {
		// List<List<String>> row = data.cells();
		loginpage.loginProcess(testuserdetails.getUserCredentials().getUsername(),
				testuserdetails.getUserCredentials().getPassword());
	}
}

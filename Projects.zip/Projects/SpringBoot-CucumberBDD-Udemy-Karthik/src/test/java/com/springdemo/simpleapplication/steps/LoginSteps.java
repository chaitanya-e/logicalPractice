package com.springdemo.simpleapplication.steps;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;

import com.springdemo.simpleapplication.model.TestUserDetails;
import com.springdemo.simpleapplication.model.UserCredentials;
import com.springdemo.simpleapplication.pages.ALoginPage;
import com.springdemo.simpleapplication.pages.HomePage;
import com.springdemo.simpleapplication.pages.MainPage;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class LoginSteps {

	@Autowired
	HomePage homepage;
	
	@Autowired
	ALoginPage loginpage;
	
	@Autowired
	MainPage mainpage;
	
	@Autowired
	TestUserDetails testuserdetails;

	@Given("^I navigate to the login page$")
	public void i_navigate_to_the_login_page() {
		homepage.loginClick();
		//cannot use datatable as in feature file there are no data under Given
		//List<List<String>> row = datatable.cells();
		//testuserdetails.setUserCredentials(new UserCredentials(row.get(1).get(0), row.get(1).get(1)));
		testuserdetails.setUserCredentials(new UserCredentials("admin","password"));
	}

//	@And("^I enter the following for Login$")
//	public void i_enter_the_following_for_login(DataTable data) {
//		List<List<String>> row = data.cells();
//		loginpage.loginProcess(row.get(1).get(0), row.get(1).get(1));		
//	}

	@And("^I click login button$")
	public void i_click_login_button() {
		System.out.println("Dummy");
	}
	
	@Then("^I should see the userform page$")
	public void i_should_see_the_userform_page()  {
		Assert.assertEquals(homepage.isEmployeeDetailsPresent(), true);;
	}

}

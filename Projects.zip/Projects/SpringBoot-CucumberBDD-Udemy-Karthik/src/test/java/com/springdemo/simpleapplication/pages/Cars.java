package com.springdemo.simpleapplication.pages;

import org.springframework.stereotype.Component;

@Component
public class Cars{
	public Cars() {
		System.out.println("Cars Test Class");
	}

	public void getCarBrand() {
		System.out.println("BMW from Test");
	}
}

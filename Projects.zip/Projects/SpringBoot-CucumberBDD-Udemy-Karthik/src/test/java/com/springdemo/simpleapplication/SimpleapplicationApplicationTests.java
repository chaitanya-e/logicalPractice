package com.springdemo.simpleapplication;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;

import com.springdemo.simpleapplication.pages.MainPage;

@SpringBootTest
@Profile("!qa")
class SimpleapplicationApplicationTests {
	
	@Autowired
	private MainPage main;
	
	@Value("temp-text")
	private String randomText;
	
	@Value("chrome,firefox,edge")
	private List<String> browsers;
	
	@Value("${name}")
	private String nameFromPropertiesFile;
	
	@Value("${app.url}")
	private String url;
	
	//@Autowired
	//private HomePage homepage; 
	
	@Test
	
	void contextLoads() {
		System.out.println(nameFromPropertiesFile);
		/*
		 * 
		 * 
		 * homepage.inithomepage()
		 * homepage.register();
		 * 
		 * 
		 * System.out.println(randomText); browsers.forEach(System.out::println);
		 * System.out.println(nameFromPropertiesFile);
		 * 
		 * ApplicationContext context =
		 * SpringApplication.run(SimpleapplicationApplication.class); var car =
		 * context.getBean(Cars.class); car.getCarBrand();
		 * 
		 * System.out.println("Autowired");
		 */
		
		//HomePage homepage = new HomePage();
		//LoginPage loginpage = new LoginPage();
		//LoginPage login = homepage.login();
		//login.login("test", "pass");
		//MainPage main = new MainPage(homepage, loginpage);
		
		main.navigateToURL(url);
		main.performLogin();
	}
}

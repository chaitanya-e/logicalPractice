package com.springdemo.simpleapplication.pages;

import javax.annotation.PostConstruct;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

public abstract class BasePage {
	@Autowired
	private WebDriver webdriver;
	
	@PostConstruct
	public void initPage()
	{
		PageFactory.initElements(webdriver, this);
	}
	
	public void navigateToURL(String URL)
	{
		webdriver.navigate().to(URL);
	}
}

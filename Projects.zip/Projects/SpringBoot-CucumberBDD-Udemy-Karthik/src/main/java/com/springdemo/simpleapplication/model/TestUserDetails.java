package com.springdemo.simpleapplication.model;

import org.springframework.stereotype.Component;

import io.cucumber.spring.ScenarioScope;

@Component
@ScenarioScope
public class TestUserDetails {

	private UserCredentials usercredentials;
	
	public UserCredentials getUserCredentials()
	{
		return usercredentials;
	}
	
	public void setUserCredentials(UserCredentials usercredentials)
	{
		this.usercredentials = usercredentials;
	}
}

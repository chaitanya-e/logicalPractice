package com.springdemo.simpleapplication;

import org.springframework.stereotype.Component;

@Component
public class Car {
	public Car() {
		System.out.println("Car object instantiated");
	}

	public void getCarBrand() {
		System.out.println("BMW");
	}
}

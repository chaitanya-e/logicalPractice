package cucumberTests;

public class simpleMyStorePurchase {

}

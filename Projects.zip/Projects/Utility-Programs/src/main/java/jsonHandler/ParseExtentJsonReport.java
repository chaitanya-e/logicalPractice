package jsonHandler;

import org.testng.annotations.Test;

public class ParseExtentJsonReport {
	String filePath = System.getProperty("user.dir")+"\\Resources\\Columbus_GiacoDigitale_Book_of_Venus_GameSpinValidations.json";
	
	@Test
	public void readJsonFile() {
		
	}
}

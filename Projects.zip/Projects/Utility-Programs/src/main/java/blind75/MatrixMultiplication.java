package blind75;

public class MatrixMultiplication {
	int a[][]= {{1,2},{3,4}};
	int b[][]= {{1,2},{3,4}};
	
	//int arr1_rows=a;
}

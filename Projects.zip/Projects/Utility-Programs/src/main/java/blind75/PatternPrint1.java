package blind75;

public class PatternPrint1 {

	public static void main(String[] args) {
		String space = String. format("%2s", "");
		
		int numOfLines=5;
		int mid = numOfLines;
		for(int i=1;i<=numOfLines;i++)
		{
			boolean flag=false;
			for(int j=1;j<=i;j++)
			{
				if(flag==false)
				{
				for(int k=1;k<=mid;k++)
					System.out.print(space);
				flag=true;
				}
				
				System.out.print(j);
				System.out.print(space+space);
			}
			System.out.println();
			mid=mid-1;
		}
	}

}

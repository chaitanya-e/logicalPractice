package blind75;

import java.util.Arrays;

public class TwoSum {
	public static void main(String[] args) {
		int arr[]= {3,2,4};
		System.out.println(Arrays.toString(twoSum1(arr,6)));
	}
	 public static int[] twoSum1(int[] nums, int target) {
	        int ret[] = new int[2];
	        boolean end=false;
	        for(int i=0;i<=nums.length-2&&end!=true;i++)
	        {
	            for(int j=i+1;j<=nums.length-1&&end!=true;j++)
	            {
	                if((nums[i]+nums[j])==target)
	                {
	                    ret[0]=i;
	                    ret[1]=j;
	                    end=true;
	                }
	            }
	        }
	        return ret;
	    }
	 
	 public static int[] twoSum2()
	 {
		 int a[] = {1,2};
		return null ; 
	 }
}

package localmongodb;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class pushJSON {
	public static void main(String[] args) throws IOException {
		MongoClient mongoClient;
		MongoDatabase mongoDatabase;
		MongoCollection<Document> mongoCollection;
		Document mongoDocument;

		// MongoDB Connection Setup - Connect to Reddit
		//mongoClient = new MongoClient("localhost", 27017);
		mongoClient = new MongoClient(new MongoClientURI("mongodb://127.0.0.1:27017"));
		mongoDatabase = mongoClient.getDatabase("Columbus_1");
		mongoCollection = mongoDatabase.getCollection("Giocodigitale");
		System.out.println("MongoDB Client, Database and Collection are successfully establised");
		
		String jsonPath = "C:\\Users\\emani.chaitanya\\eclipse-workspace\\columbusus\\src\\main\\resources\\report\\07_09_2021\\Columbus_GiacoDigitale_Book_of_Venus_GameSpinValidations.json";
		String  jsonString = new String(Files.readAllBytes(Paths.get(jsonPath)));
			
		mongoDocument = new Document("ExtentReport",jsonString);
		mongoCollection.insertOne(mongoDocument);
		
		mongoClient.close();
		
	}
}

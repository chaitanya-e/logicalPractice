package ivyprojects.test;

public class StringLastCharToFirst {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String str = "0,50 €";
		String str = "€ 0,50";
		String returnString;
		System.out.println("Len - "+str.length());
		int strLength = str.length();
		char lastChar = str.charAt(strLength -1);
		System.out.println("Last Char - "+lastChar);
		Boolean isDigitFlag = Character.isDigit(lastChar);
		System.out.println("Flag - "+isDigitFlag);
		if(isDigitFlag == false)
		{
			returnString = lastChar + " " + str.substring(0,strLength-2);
		}
		else
			returnString = str;
		
		System.out.println("Return - "+returnString);
		
	}

}

package ivyprojects.test;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MaxBetClick {
	public WebDriver driver;

	@BeforeTest
	public void setup() {
		System.out.println("Setup");
		WebDriverManager.chromedriver().setup();
		ChromeOptions ops = new ChromeOptions();

		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		ops.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		ops.setExperimentalOption("useAutomationExtension", false);

		ops.addArguments("--disable-notifications");
		ops.addArguments("--start-maximized");

		ops.setExperimentalOption("prefs", prefs);
		driver = new ChromeDriver(ops);
		driver.manage().deleteAllCookies();
	}

	@AfterTest
	public void tearDown() {
		System.out.println("Teardown");
		// driver.close();
	}

	String URL = "https://imgcolumbus-test.eurobet.it/vegas_prj/html5test/game-wrapper/?accountId=117063006&secureToken=6affc39d-345d-4752-9599-ee069700b34c&gameContext=GDCA&clientChannel=WC&gameCode=bookofvenus&currencyCode=EUR&country=IT&IP=172.20.1.11&language=it&mode=Real&gameSessionId=0&brandId=GIOCOD&jurisdiction=ITA";

	@Test
	public void start() throws InterruptedException {
		driver.get(URL);

		Thread.sleep(20000);
		String ladbrokesGameLoading = "//p[text()='Loading']";
		String giocoDigitaleGameLoading = "//p[text()='Caricamento in corso']";

		while (driver.findElements(By.xpath(giocoDigitaleGameLoading)).size() > 0) {
			Thread.sleep(1000);
		}

		System.out.println("Waiting for game load completed");

		clickContinue();
		Thread.sleep(5000);
		// Finding Maxbet Button
		// Find SpinReel Y offset
		System.out.println("Start Spin button search");
		Actions maxBetFinder = new Actions(driver);
		WebElement canvas2 = driver.findElement(By.xpath("//canvas"));
		// WebElement canvas2 = driver.findElement(By.xpath("//div[@id='content']"));
		int y_offset = 0,x_offset = 0 ;
		String canvas_pointer = "//canvas[contains(@style,'pointer')]";
		String canvas_inherit = "//canvas[contains(@style,'inherit')]";
		System.out.println(driver.findElement(By.xpath("//canvas")).getAttribute("style"));
		while (driver.findElements(By.xpath(canvas_pointer)).size() <= 0) {
			System.out.println(driver.findElement(By.xpath("//canvas")).getAttribute("style"));
			System.out.println("Spin Button yOffset Start = " + y_offset);
			maxBetFinder.moveToElement(canvas2, 0, y_offset).build().perform();
			y_offset = y_offset + 5;
		}

		//maxBetFinder.click().build().perform();
		//Thread.sleep(10000);
		int spinReel_start = y_offset;
		System.out.println("SpinReel Start = " + spinReel_start);

		while (driver.findElements(By.xpath(canvas_inherit)).size() <= 0) {
			System.out.println(driver.findElement(By.xpath("//canvas")).getAttribute("style"));
			System.out.println("Spin Button yOffset End = " + y_offset);
			maxBetFinder.moveToElement(canvas2, 0, y_offset).build().perform();
			y_offset = y_offset + 5;
		}
		
		int spinReel_end = y_offset - 5;
		System.out.println("SpinReel End = " + spinReel_end);
		int spinReel_mid = spinReel_start + ((spinReel_end - spinReel_start) / 2);
		System.out.println("SpinReel Mid = " + spinReel_mid);
		
		//maxBetFinder.moveToElement(canvas2, 0, spinReel_mid).click().build().perform();
		while (driver.findElements(By.xpath(canvas_inherit)).size() <= 0) {
			System.out.println(driver.findElement(By.xpath("//canvas")).getAttribute("style"));
			System.out.println("Spin Button yOffset End = " + y_offset);
			maxBetFinder.moveToElement(canvas2, x_offset, spinReel_mid).build().perform();
			x_offset = x_offset + 5;
		}
		
		System.out.println(driver.findElement(By.xpath("//canvas")).getAttribute("style"));
		int maxBetEnd = x_offset-5;
		int maxBet_mid = (maxBetEnd/ 2);
		maxBetFinder.moveToElement(canvas2, maxBet_mid, spinReel_mid).click().build().perform();
		System.out.println();
		
	}

	public void clickContinue() {
		Actions builder = new Actions(driver);
		WebElement canvas = driver.findElement(By.xpath("//canvas"));
		int b = 0;
		String locator = "//canvas[contains(@style,'pointer')]";
		while (driver.findElements(By.xpath(locator)).size() <= 0) {
			System.out.println("Offset-" + b);
			builder.moveToElement(canvas, 0, b).build().perform();
			b = b + 5;
		}
		builder.click().build().perform();
	}
}

package ivyprojects.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormatter2 {
	public static void main(String[] args) throws ParseException {

		String date = "Date\r\n" + 
				"2/23/22 4:00:45 PM";
		date = date.replace("Date", "").trim();
		System.out.println(date);
		SimpleDateFormat formatter3 = new SimpleDateFormat("M/d/yy");
		Date date_onlyDate = formatter3.parse(date);
		
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/YYYY");
		String onlyDate_str = formatter.format(date_onlyDate);
		System.out.println(onlyDate_str);
	}
}

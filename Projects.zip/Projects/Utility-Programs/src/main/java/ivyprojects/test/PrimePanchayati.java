package ivyprojects.test;

import java.util.Scanner;

public class PrimePanchayati {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int i = sc.nextInt();
	boolean flag=false;
	
	for(int j=2;j<=(i/2);j++)
	{
		int rem = i%j;
		if(rem==0)
		{
			flag=true;
			break;
		}
	}
	
	if(flag==true)
		System.out.println("Not a prime");
	else
		System.out.println("Prime");
}
}

package ivyprojects.test;

import java.util.Scanner;

public class StringPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		String tmp = input;
		String output = "";
		int length = input.length();
		while (!(length < 1)) {
			char last = input.charAt(length - 1);
			output = output + last;
			input = input.substring(0, length - 1);
			length = input.length();
		}
		if(tmp.equals(output))
		{
			System.out.println("Palindrome");
		}
		else
			System.out.println("Not");
	}

}

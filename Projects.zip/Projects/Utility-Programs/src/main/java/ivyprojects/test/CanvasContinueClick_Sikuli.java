package ivyprojects.test;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CanvasContinueClick_Sikuli {
	public WebDriver driver;

	@BeforeTest
	public void setup() {
		System.out.println("Setup");
		WebDriverManager.chromedriver().setup();
		ChromeOptions ops = new ChromeOptions();

		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		ops.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		ops.setExperimentalOption("useAutomationExtension", false);

		ops.addArguments("--disable-notifications");
		ops.addArguments("--start-maximized");

		ops.setExperimentalOption("prefs", prefs);
		driver = new ChromeDriver(ops);
		driver.manage().deleteAllCookies();
	}

	@AfterTest
	public void tearDown() {
		System.out.println("Teardown");
		// driver.close();
	}

	String URL = "https://imgcolumbus-test.eurobet.it/vegas_prj/html5test/game-wrapper/?accountId=117063004&secureToken=27c9ab44-fd8f-4382-9c5b-b63e89df5518&gameContext=GDCA&clientChannel=WC&gameCode=bookofvenus&currencyCode=EUR&country=IT&IP=172.20.1.11&language=it&mode=Real&gameSessionId=0&brandId=GIOCOD&jurisdiction=ITA";
			
	@Test
	public void start() throws InterruptedException, FindFailed
	{
		driver.get(URL);

		Thread.sleep(30000);
		
		//driver.switchTo().frame("vendor-ebbookofneptune");
		
		String ladbrokesGameLoading = "//p[text()='Loading']";
		String giocoDigitaleGameLoading = "//p[text()='Caricamento in corso']";
		
		while (driver.findElements(By.xpath(giocoDigitaleGameLoading)).size()>0) {
			Thread.sleep(1000);
		}
		
		Thread.sleep(1000);
		System.out.println("Waiting for game load completed");
		
		WebElement canvas = driver.findElement(By.xpath("//canvas"));
		Rectangle dimX = canvas.getRect();
		int length = dimX.getWidth();
		int breadth = dimX.getHeight();
		
		int x = dimX.getX();
		int y = dimX.getY();
		
		System.out.println("Length, Breadth : "+length+", "+breadth);
		System.out.println("x, y : "+x+", "+y);
		
		String imageLocation = "C:\\Users\\emani.chaitanya\\eclipse-workspace\\gd\\src\\main\\resources\\game-images\\Continue_Button2.PNG";
		Screen game = new Screen();
		Thread.sleep(5000);
		//Pattern continueBtn = new Pattern(imageLocation);
		//game.click(continueBtn);
		
		game.hover(imageLocation);
		Thread.sleep(2000);
		game.click(imageLocation);
	}
}

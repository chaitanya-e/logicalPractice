package ivyprojects.test;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CanvasContinueClick {
	public WebDriver driver;

	@BeforeTest
	public void setup() {
		System.out.println("Setup");
		WebDriverManager.chromedriver().setup();
		ChromeOptions ops = new ChromeOptions();

		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		ops.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		ops.setExperimentalOption("useAutomationExtension", false);

		ops.addArguments("--disable-notifications");
		ops.addArguments("--start-maximized");

		ops.setExperimentalOption("prefs", prefs);
		driver = new ChromeDriver(ops);
		driver.manage().deleteAllCookies();
	}

	@AfterTest
	public void tearDown() {
		System.out.println("Teardown");
		// driver.close();
	}
	
	String URL = "https://imgcolumbus-test.eurobet.it/vegas_prj/html5test/game-wrapper/?accountId=122405439&secureToken=64d32e26-42f1-4faa-be1b-5a9cff601546&gameContext=GDCA&clientChannel=WC&gameCode=bookofvenus&currencyCode=EUR&country=IT&IP=172.20.1.11&language=it&mode=Real&gameSessionId=0&brandId=GIOCOD&jurisdiction=ITA";
	@Test
	public void start() throws InterruptedException
	{
		driver.get(URL);

		Thread.sleep(20000);
		String ladbrokesGameLoading = "//p[text()='Loading']";
		String giocoDigitaleGameLoading = "//p[text()='Caricamento in corso']";
		
		while (driver.findElements(By.xpath(giocoDigitaleGameLoading)).size()>0) {
			Thread.sleep(1000);
		}
		
		System.out.println("Waiting for game load completed");
		
		Actions builder = new Actions(driver);
		WebElement canvas = driver.findElement(By.xpath("//canvas"));
		int b=0;
		String locator = "//canvas[contains(@style,'pointer')]";
		System.out.println("current canvas - pointer size - " + driver.findElements(By.xpath(locator)).size());
		System.out.println("Navigating towards continue button");
		while(driver.findElements(By.xpath(locator)).size()<=0)
		{
			System.out.println("Offset-" + b);
			builder.moveToElement(canvas, 0, b).build().perform();
			b=b+5;
		}
		System.out.println("Final Navigation Coordinates");
		System.out.println("Offset-" + b);
		builder.click().build().perform();
	}
}

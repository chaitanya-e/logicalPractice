package ivyprojects.test;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

public class Base {
	public static void main(String[] args) {
		String str1 = " 1.99.943,4";
		String str2 = "€99.30";
		
		int String = 20;
		System.out.println(String);
		
		int aa=20;
		int c=20;
		System.out.println(aa+c);
		System.out.println("OP"+aa+c);
		
		System.out.println(str1.replaceAll("[\\s€$.]", "").replace(",", "."));
		NumberFormat numberFormat = null;
		
		switch(str2.charAt(0))
		{
			case '€':
				numberFormat = NumberFormat.getCurrencyInstance(Locale.GERMAN);
				break;
			case '$':
				numberFormat= NumberFormat.getCurrencyInstance(Locale.US);
				break;
			default:
				System.out.println("Other than Euro and US Dollar - Invalid!!");
		}
		
		try {
			BigDecimal b1 = new BigDecimal(numberFormat.parse(str2).toString());
			System.out.println(b1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Invalid Format Read");
			e.printStackTrace();
		}
		
		
		System.out.println("75.13 euro: " + numberFormat.format(75.13));

		try {
		  System.out.println("Parsed blam1: " + numberFormat.parse("EUR 75,11"));
		} catch (ParseException exception) {
		  System.out.println("Parse Exception1: " + exception);
		}

		try {
		  System.out.println("Parsed blam2: " + numberFormat.parse("75,12 €"));
		} catch (ParseException exception) {
		  System.out.println("Parse Exception2: " + exception);
		}

		try {
			System.out.println("Parsed str2: " + numberFormat.parse(str2));
		  System.out.println("Parsed blam3: " + numberFormat.parse("75,13"));
		} catch (ParseException exception) {
		  System.out.println("Parse Exception3: " + exception);
		}
	}
}

package ivyprojects.test;

public class ChildClass2ExtendsBaseSharedClass extends BaseSharedClass {
	

}

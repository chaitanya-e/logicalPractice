package ivyprojects.test;

public class BaseSharedClass {
	String str = "BaseSharedClass";

}

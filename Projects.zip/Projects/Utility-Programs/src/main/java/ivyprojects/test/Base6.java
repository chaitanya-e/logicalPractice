package ivyprojects.test;

public class Base6 {

	public static void main(String[] args) {
		
		String jenkinsJobName = "Columbus_GiacoDigitale&param1=value1&param2=value2";
		int isParameteredBuild = jenkinsJobName.indexOf("&");

		String jobName = "";
		String parameters = "";

		if (isParameteredBuild > 0) {
			jobName = jenkinsJobName.substring(0, jenkinsJobName.indexOf("&"));
			parameters = jenkinsJobName.substring(jenkinsJobName.indexOf("&"));
		} else {
			jobName = jenkinsJobName;
			parameters = "";
		}

		String ipAddressJenkins = "localhost";

		String finalURL = "http://" + ipAddressJenkins + ":8080/buildByToken/build?job=" + jobName + "&token="
				+ "columbusus-gd-remote" + parameters;
		
		System.out.println(finalURL);
		
		int c= 6;
		char a = 0;
		System.out.println(a);
	}

}

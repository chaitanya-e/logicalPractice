package ivyprojects.test;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CanvasContinueClick2 {
	public WebDriver driver;

	@BeforeTest
	public void setup() {
		System.out.println("Setup");
		WebDriverManager.chromedriver().setup();
		ChromeOptions ops = new ChromeOptions();

		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		ops.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		ops.setExperimentalOption("useAutomationExtension", false);

		ops.addArguments("--disable-notifications");
		ops.addArguments("--start-maximized");

		ops.setExperimentalOption("prefs", prefs);
		driver = new ChromeDriver(ops);
		driver.manage().deleteAllCookies();
	}

	@AfterTest
	public void tearDown() {
		System.out.println("Teardown");
		// driver.close();
	}
	
	String URL = "https://imgcolumbus-test.eurobet.it/vegas_prj/html5test/game-wrapper/?accountId=117063004&secureToken=731eb641-abaf-401f-9c94-448845a9e419&gameContext=GDCA&clientChannel=WC&gameCode=bookofvenus&currencyCode=EUR&country=IT&IP=172.20.1.11&language=it&mode=Real&gameSessionId=0&brandId=GIOCOD&jurisdiction=ITA";
	@Test
	public void start() throws InterruptedException
	{
		driver.get(URL);

		Thread.sleep(20000);
		String ladbrokesGameLoading = "//p[text()='Loading']";
		String giocoDigitaleGameLoading = "//p[text()='Caricamento in corso']";
		
		while (driver.findElements(By.xpath(giocoDigitaleGameLoading)).size()>0) {
			Thread.sleep(1000);
		}
		
		System.out.println("Waiting for game load completed");
		
		Actions builder = new Actions(driver);
		WebElement canvas = driver.findElement(By.xpath("//canvas"));
		Rectangle dimX = canvas.getRect();
		int length = dimX.getWidth();
		int breadth = dimX.getHeight();
		int x = dimX.getX();
		int y = dimX.getY();
		
		int b=0;
		String locator = "//canvas[contains(@style,'pointer')]";
		
		int searchY_min = y + (breadth*(2/3));
		int searchY_max = y + breadth;
		int searchX_min = x;
		int searchX_max = x + length;
		
		int currentY = searchY_min; 
		int currentX = searchX_min; 
		
		boolean found = false;
		System.out.println("Length : "+length);
		System.out.println("Breadth : "+breadth);
		System.out.println("SearchY_min : "+searchY_min);
		System.out.println("SearchY_max : "+searchY_max);
		System.out.println("SearchX_min : "+searchX_min);
		System.out.println("SearchX_max : "+searchX_max);
		
		while(currentY <= searchY_max)
		{
			//builder.moveToElement(canvas, 0, b).build().perform();
			//b=b+5;
			currentX = searchX_min;
			while(currentX <= searchX_max)
			{
				System.out.println("Current X, Y : " + currentX + " , "+currentY);
				builder.moveByOffset(currentX, currentY).build().perform();
				if(driver.findElements(By.xpath(locator)).size()>0)
				{
					found = true;
					break;
				}
				else
					currentX = (currentX + 10);
			}
			
			if(found==true)
				break;
			else
				currentY = currentY + 10;
		}
		
		System.out.println("X / Y : "+ currentX + " / "+currentY);
		builder.click().build().perform();
	}
}

package ivyprojects.test;

public class UserName {
public static void main(String[] args) {
	System.out.println(System.getProperty("user.name"));
}
}

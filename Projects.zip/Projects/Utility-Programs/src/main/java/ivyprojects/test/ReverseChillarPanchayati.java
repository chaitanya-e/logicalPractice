package ivyprojects.test;

import java.util.Scanner;

public class ReverseChillarPanchayati {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int i = sc.nextInt();
	
	int j=0;String out="";
	while(i>0)
	{
		int last =(i%10);
		j=(j*10)+last;
		out = out+last;
		i=i/10;
	}
	System.out.println(j);
	System.out.println(out);
}
}

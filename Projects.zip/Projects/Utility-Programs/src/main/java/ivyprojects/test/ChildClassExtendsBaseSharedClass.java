package ivyprojects.test;

public class ChildClassExtendsBaseSharedClass extends BaseSharedClass {
	public static void main(String[] args) {
			
	}

}

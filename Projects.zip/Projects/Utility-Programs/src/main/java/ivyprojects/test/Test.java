package ivyprojects.test;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Screen;

public class Test {
public static void main(String[] args) throws FindFailed, InterruptedException {
	String imageLocation = "C:\\Users\\emani.chaitanya\\eclipse-workspace\\gd\\src\\main\\resources\\game-images\\Continue_Button2.PNG";
	Screen s = new Screen();
	Thread.sleep(5000);
	s.hover(imageLocation);
	s.click(imageLocation);
}
}

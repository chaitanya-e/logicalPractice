package ivyprojects.test;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Base2 {
	static StackTraceElement[] stackTraceElements;

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy"); // use this to directly send keys to textbox
		Date date = new Date();
		date.setDate(1);
		String currentDate = formatter.format(date).toString();
		System.out.println(currentDate);

		String[][] a = new String[2][2];
		a[0][0] = "A1";
		a[0][1] = "B1";
		a[1][0] = "A2";

		A();
	}

	static void A() {
		System.out.println("A");
		System.out.println(callHierarchy());
		/*
		 * stackTraceElements = Thread.currentThread().getStackTrace(); int len =
		 * stackTraceElements.length;
		 * System.out.println(stackTraceElements[2].toString());
		 */
		B();
	}

	static void B() {
		System.out.println("B");
		System.out.println(callHierarchy());
		/*
		 * stackTraceElements = Thread.currentThread().getStackTrace(); int len =
		 * stackTraceElements.length;
		 * System.out.println(Arrays.deepToString(stackTraceElements));
		 * System.out.println(stackTraceElements[2].toString());
		 */
		C();
	}

	static void C() {
		System.out.println("C");
		System.out.println(callHierarchy());
		/*
		 * stackTraceElements = Thread.currentThread().getStackTrace();
		 * System.out.println(Arrays.deepToString(stackTraceElements)); int len =
		 * stackTraceElements.length;
		 */

		D();
	}

	static void D() {

		System.out.println("D");
		System.out.println(callHierarchy());

	}

	static String callHierarchy() {
		stackTraceElements = Thread.currentThread().getStackTrace();
		int len = stackTraceElements.length;
		String trace = "";
		for (int i = 2; i < len-1; i++) {
			trace = trace + stackTraceElements[i].toString();
			if (i < len - 1)
				trace = trace + " --> ";
		}
		return trace;
	}
}

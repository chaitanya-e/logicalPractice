package ivyprojects.test;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExtentReportTest {
	WebDriver driver;
	ExtentReports extent;
	ExtentTest tester;
	ExtentSparkReporter reporter;

	@BeforeTest
	public void setup() {
		System.out.println("Setup");
		WebDriverManager.chromedriver().setup();
		ChromeOptions ops = new ChromeOptions();

		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		ops.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		ops.setExperimentalOption("useAutomationExtension", false);

		ops.addArguments("--disable-notifications");
		ops.addArguments("--start-maximized");

		ops.setExperimentalOption("prefs", prefs);
		driver = new ChromeDriver(ops);
		driver.manage().deleteAllCookies();

		reporter = new ExtentSparkReporter(System.getProperty("user.dir") + "/Reports/newTestReport.html");
		reporter.config().setReportName("Extent Report - First Test");

		extent = new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Test Name", "IVY First Extnt Report Test");
		extent.setSystemInfo("Author", "Chaitanya");

		
	}

	@AfterTest
	public void tearDown() {
		System.out.println("Teardown");
		extent.flush();
		driver.close();
	}

	@Test
	public void extentTest1() {
		tester = extent.createTest("First Extent Report Test Program");
		driver.get("https://www.google.co.in/");
		tester.pass("First Test Passed");
	}
	@Test
	public void extentTest2() {
		tester = extent.createTest("Second Extent Report Test Program");
		driver.get("https://www.google.co.in/");
		tester.pass("Second Test Passed");
	}
	@Test
	public void extentTest3() {
		tester = extent.createTest("Third Extent Report Test Program");
		driver.get("https://www.google.co.in/");
		tester.fail("Third Test failed");
	}
}

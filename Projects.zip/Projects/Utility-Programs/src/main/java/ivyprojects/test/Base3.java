package ivyprojects.test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Base3 {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		/*
		 * String currStake = "$100.23"; String currBet = "$10.50"; String currWin =
		 * "$20.11";
		 */
		
		
		  String currStake = "€ 1.000,50"; String currBet = "€ 100,50"; String currWin
		  = "€ 2.000,23";
		 
		String currencyFormat = "EU";
		NumberFormat numberFormat = NumberFormat.getCurrencyInstance(Locale.ITALY);

		switch (currencyFormat) {
		case "EU":
			numberFormat = NumberFormat.getCurrencyInstance(Locale.ITALY);
			break;
		case "US":
			numberFormat = NumberFormat.getCurrencyInstance(Locale.US);
			break;
		default:
			System.out.println("Other than Euro and US Dollar - Invalid!!");
		}

		BigDecimal stake = new BigDecimal(numberFormat.parse(currStake).toString());
		BigDecimal bet = new BigDecimal(numberFormat.parse(currBet).toString());
		BigDecimal win = new BigDecimal(numberFormat.parse(currWin).toString());

		BigDecimal newStakeAfterSpin = stake.add(win).subtract(bet).setScale(2, RoundingMode.CEILING);
		double newStake_doubleVal = newStakeAfterSpin.doubleValue();
		System.out.println(numberFormat.format(newStake_doubleVal));
		
		System.out.println(numberFormat.format(0.00));
		
		//date
		SimpleDateFormat formatter = new SimpleDateFormat("d/MMM/yyyy");  
	    Date date = new Date();  
	    String currentDate = formatter.format(date).toString();
	    System.out.println(currentDate);
	    
	    int[] a = {1,2,3,4,5};
	    System.out.println(a.length);
	    
	    
	}
}

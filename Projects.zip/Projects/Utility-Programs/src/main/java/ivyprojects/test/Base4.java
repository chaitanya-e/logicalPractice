package ivyprojects.test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Base4 {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("d/MMM/yyyy");
		System.out.println("Today's date is " + dateFormat.format(cal.getTime()));

		cal.add(Calendar.DATE, -1);
		System.out.println("Yesterday's date was " + dateFormat.format(cal.getTime()));

		boolean flag = false;
		int i = 3;
		while (flag != true) {
			if (i == 1) {
				flag = true;
				break;
			} else
				i--;
			System.out.println(i);
		}
		String cheatToolURL = "http://172.17.152.20:10150/?action=add&numbers=0,4,2,0,8&account=117063009";
		String accountID = cheatToolURL.substring(cheatToolURL.lastIndexOf("=")+1);
		System.out.println(accountID);
		
		String  path1 = System.getProperty("user.dir");
		System.out.println("user.dir = "+path1);
		String path2 = System.getProperty("user.home");
		System.out.println("user.home = "+path2);
	}
}

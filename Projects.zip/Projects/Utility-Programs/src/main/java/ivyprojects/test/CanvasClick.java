package ivyprojects.test;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CanvasClick {
	public WebDriver driver;

	@BeforeTest
	public void setup() {
		System.out.println("Setup");
		WebDriverManager.chromedriver().setup();
		ChromeOptions ops = new ChromeOptions();

		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		ops.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		ops.setExperimentalOption("useAutomationExtension", false);

		ops.addArguments("--disable-notifications");
		ops.addArguments("--start-maximized");

		ops.setExperimentalOption("prefs", prefs);
		driver = new ChromeDriver(ops);
		driver.manage().deleteAllCookies();
	}

	@AfterTest
	public void tearDown() {
		System.out.println("Teardown");
		// driver.close();
	}

	public WebElement waitForElement(By locator) {
		System.out.println("Waiting for Element");
		//WebDriverWait wait = new WebDriverWait(driver, 20);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		return driver.findElement(locator);
	}

	public void log(String logMessage) {
		System.out.println(logMessage);
	}

	/* Main Tests start */
	String URL = "https://qa2.casino.giocodigitale.it/it/games";
	String overlayCSS = "div[data-id='dj_casino_a_ovl_br']";
	String overlayCloseXpath = "//div[@data-id='dj_casino_a_ovl_br']/span";

	@Test
	public void openApplication() {
		log("Login Test Start");
		driver.get(URL);

		// wait for overlay
		log("Overlay Handling");

		By overlayCSSLocator = By.cssSelector(overlayCSS);
		WebElement overlayCSSEle = waitForElement(overlayCSSLocator);

		// close overlay
		if (overlayCSSEle.isDisplayed()) {
			driver.findElement(By.xpath(overlayCloseXpath)).click();
		}

		// Cookies Handling
		WebElement acceptCookieBtn = driver.findElement(By.id("onetrust-accept-btn-handler"));
		acceptCookieBtn.click();

	}

	String loginBtnCSS = "a[href*='login']";
	String loginBtnXpath = "//button[text()=' Login ']";

	@Test(dependsOnMethods = { "openApplication" })
	public void login() {

		// login
		log("Login Handling");

		By loginBtnLocator = By.cssSelector(loginBtnCSS);
		WebElement loginBtn = waitForElement(loginBtnLocator);
		loginBtn.click();

		// loginOverlay
		By loginOverlayLocator = By.id("cdk-overlay-1");
		if (waitForElement(loginOverlayLocator).isDisplayed()) {
			log("Login Overlay Displayed");
			WebElement userId = driver.findElement(By.id("userId"));
			userId.clear();
			userId.sendKeys("rkitaly@rkitaly.com");
			WebElement password = driver.findElement(By.name("password"));
			password.clear();
			password.sendKeys("Entain@123");
			driver.findElement(By.xpath(loginBtnXpath)).click();
		} else {
			log("Login Overlay not displayed");
			Assert.assertTrue(false);
		}

	}

	@Test(dependsOnMethods = { "login" })
	public void validateLogin() {
		By paymentBtnAfterLogin = By.cssSelector("a[href*='cashier/deposit']");
		if (waitForElement(paymentBtnAfterLogin).isDisplayed()) {
			log("Login Successful");
		} else {
			log("Login Failed - Termination");
			Assert.assertTrue(false);
		}
	}
	
	String searchResultXpath="//span[@class='search-result-title']//pre[text()='Venus']";
	@Test(dependsOnMethods= {"validateLogin"})
	public void gameSearch()
	{
		log("Searching for Game");
		By gameSearchBox = By.id("search-text");
		driver.findElement(gameSearchBox).sendKeys("Book of Venus");
		By gameResult = By.xpath(searchResultXpath);
		driver.findElement(gameResult).click();
	}
	
	String gameTitleCSS = "div.game-title";
	@Test(dependsOnMethods= {"gameSearch"})
	public void validateGameTitle()
	{
		log("Validating Game Title");
		By gameTitle = By.cssSelector(gameTitleCSS);
		String gameTitleText = driver.findElement(gameTitle).getText();
		if(!gameTitleText.equalsIgnoreCase("Book of Venus"))
			Assert.assertTrue(false);
		else
			log("Game Page load completed");
	}
	
	String canvasCSS = "div#content canvas";
	String iframeCSS = "iframe#vendor-ebbookofvenus";
	@Test(dependsOnMethods= {"validateGameTitle"})
	public void validateCanvasGame()
	{
		log("Game Validation");
		By iframe = By.cssSelector(iframeCSS);
		WebElement iframeElement = driver.findElement(iframe);
		driver.switchTo().frame(iframeElement);
		By canvas = By.cssSelector(canvasCSS);
		
	}
}

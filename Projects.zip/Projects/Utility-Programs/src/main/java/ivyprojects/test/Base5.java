package ivyprojects.test;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Base5 {
	public static void main(String[] args) {
		String a = "1,00 €";
		String lastChar = a.substring(0, a.length() - 1);
		// System.out.println(lastChar);

		double value = 200.3456;
		// System.out.printf("Value: %.2f", value);

		String date = "10/28/2021";
		String date_formatted = date.substring(0, date.lastIndexOf("/") + 1);
		String year = date.substring(date.lastIndexOf("/") + 1);
		String year_formatted = year.substring(2);
		date_formatted = date_formatted + year_formatted;
		System.out.println(date_formatted);

		double winFromGame = dollarToBigDecimal("").setScale(2, RoundingMode.CEILING).doubleValue();
		System.out.println("Winning value read from the gameplay is " + String.format("%.2f", winFromGame));
	}

	public static BigDecimal dollarToBigDecimal(String inputCurrency) {
		BigDecimal returnVal;
		System.out.println("Input Currency Value to be Formatted is - " + inputCurrency);
		inputCurrency = inputCurrency.replace(" ", "").trim();
		String inputCurrency_fmt = inputCurrency.substring(1);
		returnVal = new BigDecimal(inputCurrency_fmt);
		return returnVal;
	}
}

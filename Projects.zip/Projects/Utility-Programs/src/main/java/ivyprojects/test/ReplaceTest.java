package ivyprojects.test;

public class ReplaceTest {

	public static void main(String[] args) {
		String input = "{login_session_id}";
		String keyToFetch = input.replace("{","").replace("}","");
		System.out.println(keyToFetch);
		
	}

}

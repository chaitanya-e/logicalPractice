package ivyprojects.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Timestamp {

	public static void main(String[] args) throws ParseException {
		String gameDate = "01/13/2022";
		String historyDate = "01/12/2022 23:49:25";

		// History Page Date with timestamp formatting
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date historyDate_fmt = formatter.parse(historyDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(historyDate_fmt);
		int historyDate_hour = cal.get(Calendar.HOUR_OF_DAY);

		// History Date Page with only Date value
		SimpleDateFormat formatter3 = new SimpleDateFormat("MM/dd/yyyy");
		Date historyDate_onlyDate = formatter3.parse(historyDate);
		String historyDate_onlyDate_str = formatter3.format(historyDate_onlyDate);

		// Date from game
		SimpleDateFormat formatter2 = new SimpleDateFormat("MM/dd/yyyy");
		Date gameDate_fmt = formatter2.parse(gameDate);
		Calendar calendar_gameDate = Calendar.getInstance();
		calendar_gameDate.setTime(gameDate_fmt);
		calendar_gameDate.add(Calendar.DAY_OF_YEAR, -1);
		Date previousDate = calendar_gameDate.getTime();
		String previousDate_str = formatter2.format(previousDate);

		if (historyDate_hour == 23 || historyDate_hour == 22) {
			System.out
					.println("History Date Hour is " + historyDate_hour + "; History Page timestamp = " + historyDate);
			System.out.println(
					"Validating Date from History Page with Date from Game play || Date-1 from Game play due to server timestamp");
			if (historyDate_onlyDate_str.contentEquals(previousDate_str)
					|| historyDate_onlyDate_str.contentEquals(gameDate))
			{
				
				System.out.println("Date Validation successful || History Page Date = "+historyDate_onlyDate_str+"Game Play Date = "+previousDate_str);
			}
			else
				System.out.println("Fail");
		} else {
			System.out.println("else");
		}

	}

}

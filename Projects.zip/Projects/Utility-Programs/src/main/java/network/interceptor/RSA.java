package network.interceptor;

import java.util.Optional;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v99.network.Network;
import org.testng.annotations.Test;

public class RSA {

      @Test(enabled=false)

      public void captureRequestSelenium() {

            System.setProperty("webdriver.chrome.driver", "C:\\Users\\emani.chaitanya\\drivers\\chromedriver\\chromedriver.exe");

            ChromeDriver driver = new ChromeDriver();

            DevTools devTool = driver.getDevTools();

            devTool.createSession();

            devTool.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));

            devTool.addListener(Network.requestWillBeSent(), requestSent -> {

                  System.out.println("Request URL => " + requestSent.getRequest().getUrl());

                  System.out.println("Request Method => " + requestSent.getRequest().getMethod());

                  System.out.println("Request Headers => " + requestSent.getRequest().getHeaders().toString());

                  System.out.println("------------------------------------------------------");

            });

            driver.get("https://rahulshettyacademy.com/#/index");

      }
      
      @Test
      public void approach2()
      {
    	  System.out.println("Using Approach 2");
    	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\emani.chaitanya\\drivers\\chromedriver\\chromedriver.exe");
    	  WebDriver driver = new ChromeDriver();
    	  driver.get("http://www.google.com");
    	  String scriptToExecute = "var performance = window.performance || window.mozPerformance || window.msPerformance || window.webkitPerformance || {}; var network = performance.getEntries() || {}; return network;";
    	  String netData = ((JavascriptExecutor)driver).executeScript(scriptToExecute).toString();
    	  System.out.println(netData);
      }

}
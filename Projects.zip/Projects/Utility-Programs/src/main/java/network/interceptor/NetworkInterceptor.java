package network.interceptor;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class NetworkInterceptor {
	@Test
	public void test1() 
	{
		System.out.println("Using Approach 2");
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\emani.chaitanya\\drivers\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com");
		String scriptToExecute = "var performance = window.performance || window.mozPerformance || window.msPerformance || window.webkitPerformance || {}; var network = performance.getEntries() || {}; return network;";
		String netData = ((JavascriptExecutor) driver).executeScript(scriptToExecute).toString();
		System.out.println(netData);
	}
}

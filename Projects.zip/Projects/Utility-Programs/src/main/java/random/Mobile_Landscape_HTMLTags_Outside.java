package random;

// Sample test in Java to run Automate session.
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import com.browserstack.local.Local;

import io.appium.java_client.AppiumDriver;

public class Mobile_Landscape_HTMLTags_Outside {
	public static final String AUTOMATE_USERNAME = "eurobet_hEvMtUxZtSk";
	public static final String AUTOMATE_ACCESS_KEY = "rmmdPF2HGoXdVHTsbuAH";
	public static final String URL = "https://" + AUTOMATE_USERNAME + ":" + AUTOMATE_ACCESS_KEY
			+ "@hub-cloud.browserstack.com/wd/hub";
	static String acceptCookies = "//button[@id='onetrust-accept-btn-handler']";
	static String closeAddvertisementButton = "//span[@class='ui-icon theme-ex']";
	static String loginButtonHomePage = "//span[normalize-space()='Login']";
	static String userIdForLogIn = "//input[@id='userId']";
	static final String passwordForLogin = "//input[@name='password']";
	static final String loginButtonInPopUp = "//button[normalize-space()='Login']";
	static String findGameSearchBox = "//div[@class='icon theme-search-i']";
	static int count = 1;
	static String searchResult = "//span[@class='search-result-title']";
	static String searchBar = "//input[@id='serachTxt']";
	String globalSearch = "//span[contains(@class,'global-search-icon')]";
	String searchInput = "//input[@id='search-input']";
	String globalSearchSelect = "//span[contains(@class,'icon-title')]/pre[contains(text(),'Roman Gods - Book of Venus')]/ancestor::div[@data-icon='imagetitle']";
	public static final String gameIframeXpath = "//iframe[@id='vendorGameIFrame']";
	String LabelsIdentified = "";

	@Test
	public void browserStackMobileAutomationTest() throws Exception {

		Local bsLocal = new Local();
		HashMap<String, String> bsLocalArgs = new HashMap<String, String>();
		bsLocalArgs.put("key", "rmmdPF2HGoXdVHTsbuAH");
		bsLocalArgs.put("forcelocal", "true");
		bsLocal.start(bsLocalArgs);
		System.out.println(bsLocal.isRunning() + " Local is On");

		DesiredCapabilities caps = new DesiredCapabilities();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--ignore-ssl-errors=yes");
		options.addArguments("--allow-insecure-localhost");
		options.addArguments("--ignore-certificate-errors");
		caps.setCapability(ChromeOptions.CAPABILITY, options);

		caps.setCapability("browserName", "chrome");
		// caps.setCapability("browserName", "Android");
		caps.setCapability("device", "Samsung Galaxy S21");
		caps.setCapability("realMobile", "true");
		caps.setCapability("os_version", "11");
		caps.setCapability("name", "GiacoDigitale"); // test name
		caps.setCapability("build", "GD_MobileBrowser"); // CI/CD job or build name
		caps.setCapability("browserstack.local", "true");
		caps.setCapability("browserstack.console", "info");
		caps.setCapability("browserstack.networkLogs", "true");
		caps.setCapability("browserstack.debug", "true");
		caps.setCapability("deviceOrientation", "landscape");
		caps.setCapability("automationName", "UiAutomator2");
		caps.setCapability("browserstack.idleTimeout", 500);

		AppiumDriver driver = new AppiumDriver(new URL(URL), caps);

		System.out.println("Opening Driver");
		driver.get("https://imgcolumbus-test.eurobet.it/vegas_prj/html5test/stub-portal/#/stub-portal");
		System.out.println("Application URL Driverget");

		Thread.sleep(5000);

		String gameImage = "//img[contains(@title,'Book of Jupiter')]";
		WebElement game = driver.findElement(By.xpath(gameImage));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", game);
		Thread.sleep(3000);

		game.click();
		System.out.println("Clicked on Image");

		Thread.sleep(5000);

		String iframe = "//iframe[contains(@class,'stubIFrame')]";

		int attempts = 50;
		while (driver.findElements(By.xpath(iframe)).size() < 1 && attempts > 0) {
			Thread.sleep(1000);
			attempts--;
			System.out.println(" game frame visibility, attempts " + attempts);
		}

		driver.switchTo().frame(driver.findElement(By.xpath(iframe)));
		System.out.println("Switched to gameframe");

		attempts = 200;
		while (driver.findElements(By.xpath("//p[@class='percentage']")).size() < 1 && attempts > 0) {
			Thread.sleep(1000);
			attempts--;
			System.out.println("percentage visibility, attempts " + attempts);
		}

		int breakCounter = 0;
		while (driver.findElements(By.xpath("//p[@class='percentage']")).size() >= 1 && breakCounter < 300) {
			System.out.println(
					"Waiting for the game % to be completed to 100 or breakcounter reach 300 - current counter "
							+ breakCounter);
			Thread.sleep(1000);
			breakCounter++;
		}
		System.out.println("Waiting done for the game launch");

		Thread.sleep(5000);
		
		String audioXpath = "//span[text()='Si']";
		WebElement audio = driver.findElement(By.xpath(audioXpath));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", audio);
		
		//System.out.println("" - driver.findElements(By.xpath()));
		
		
		driver.quit();
		bsLocal.stop();
	}

	public static Boolean existElement(AppiumDriver driver, String locator) {
		int elementiTrovati = driver.findElements(By.xpath(locator)).size();
		Boolean exist = elementiTrovati > 0 ? true : false;
		if (elementiTrovati > 1) {
			System.out.println("Element Exist");
		}
		return exist;
	}

	
}
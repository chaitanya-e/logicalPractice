package random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SoftwareRendering {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\emani.chaitanya\\drivers\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com");
		driver.get("chrome://flags");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='search']")).sendKeys("Override software rendering list");
		Thread.sleep(2000);
		String optionDropDownXpath = "//select[@aria-labelledby='ignore-gpu-blocklist_name']";
		//scrollIntoViewJS(optionDropDownXpath);
		WebElement ele = driver.findElement(By.xpath(optionDropDownXpath));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true)", ele);
		WebElement optionDropDownEle = driver.findElement(By.xpath(optionDropDownXpath));
		
		Select options = new Select(optionDropDownEle);
		options.selectByVisibleText("Enabled");
		Thread.sleep(3000);
		String relaunchXpath = "//button[contains(text(),'Relaunch')]";
		if(driver.findElements(By.xpath(relaunchXpath)).size() > 0)
		{
			System.out.println("Clicking on Relaunch");
			driver.findElement(By.xpath(relaunchXpath)).click();
		}
		System.out.println("Flag is enabled for renedering list");
		//driver.quit();
		driver.get("http://www.google.com");
	}

}

package random;

public class LongestString {
public static void main(String[] args) {
	String s = "abcabcbb";
	char c[] = new char[s.length()];
	c = s.toCharArray();
	String sub="",maxsub="",prevsub="",partsub="";
	int count=0,maxcount=0;
	for(char c1 : c)
	{
		sub = sub+c1;
		count++;
		
		
		if(maxsub.contains(c1+""))
		{
			partsub = partsub+c1;
			count=0;
		}
		else
		{
			maxcount=count;
			maxsub = sub;
		}
	}
	System.out.println(maxcount);
	System.out.println(maxsub);
}
}

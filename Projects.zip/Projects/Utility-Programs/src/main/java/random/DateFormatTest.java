package random;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DateFormatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String dateFromScreen = "Data\r\n"
				+ "08/06/22 10:57:39";
		System.out.println(dateFromScreen);
		dateFromScreen = dateFromScreen.replace("Data", "").trim();
		System.out.println("only date "+dateFromScreen);
		dateFromScreen = dateFromScreen.substring(0, dateFromScreen.indexOf(' '));
		System.out.println("issue"+dateFromScreen);
		
		System.out.println(System.getProperty("user.dir"));
		
		
		List<Integer> a = new ArrayList<Integer>();
		Integer[] arr = {1,2,4};
		a = Arrays.asList(arr);
		a.add(5);
		Object o = new Object();
	}

}

package random;

import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v99.network.Network;

import java.io.File;
import java.util.*;

public class ChromeDevTools {
	@Test(enabled = false)
	public void chromeDevTools() {
		//static int i=1;
		File file = new File("C:\\Users\\emani.chaitanya\\drivers\\chromedriver\\chromedriver.exe");
		ChromeDriverService service = new ChromeDriverService.Builder().usingDriverExecutable(file).usingAnyFreePort()
				.build();
		ChromeOptions options = new ChromeOptions().addArguments("--incognito");
		ChromeDriver driver = new ChromeDriver(service, options);
		DevTools chromeDevTools = driver.getDevTools();

		chromeDevTools.createSession();
		chromeDevTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));
		chromeDevTools.addListener(Network.loadingFinished(), entry -> {
			System.out.println("Body: " + chromeDevTools.send(Network.getResponseBody(entry.getRequestId())).getBody());
		});

		driver.get("https://www.google.com");

		chromeDevTools.send(Network.disable());
		driver.quit();
	}

	@Test
	public void captureRequestSelenium() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\emani.chaitanya\\drivers\\chromedriver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		DevTools devTool = driver.getDevTools();

		devTool.createSession();

		devTool.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));

		devTool.addListener(Network.requestWillBeSent(), requestSent -> {

			System.out.println("Request URL => " + requestSent.getRequest().getUrl());

			System.out.println("Request Method => " + requestSent.getRequest().getMethod());

			System.out.println("Request Headers => " + requestSent.getRequest().getHeaders().toString());

			System.out.println("------------------------------------------------------");

		});

		driver.get("https://rahulshettyacademy.com/#/index");

	}
}

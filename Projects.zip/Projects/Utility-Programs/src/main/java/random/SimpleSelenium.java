package random;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SimpleSelenium {
	@Test
	public void start() throws InterruptedException {
		System.out.println("Inside Start");
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\emani.chaitanya\\drivers\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.flipkart.com/");

		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@class='_3704LK']")).click();

		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@class='_3704LK']")).sendKeys("Galaxy");
		Thread.sleep(3000);

		String searchResults = driver.findElement(By.xpath("//li[@class='Y5N33s']")).getText();
		 driver.findElement(By.xpath("//li[@class='Y5N33s']")).click();
		System.out.println(searchResults);
		Thread.sleep(3000);

	}
}

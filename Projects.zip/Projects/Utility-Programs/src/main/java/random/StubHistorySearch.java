package random;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class StubHistorySearch {
	WebDriver driver; 
	@Test
	public void stubHistoryDatePicker() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\emani.chaitanya\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		//driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.get("https://imgcolumbus-test.eurobet.it/vegas_prj/html5test/stub-portal/#/stub-history-search");
		
		Thread.sleep(10000);
		System.out.println("Waiting complete");
		String fromDateXpath = "//input[@name='dataDa']";
		String toDateXpath = "//input[@name='dataA']";
		
		Date today = new Date();
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/YYYY");
		//String today_fmt = format.format(today);
		String today_fmt = "06/02/2022";
		System.out.println(today_fmt);
		getElement(fromDateXpath).sendKeys(today_fmt);
		Thread.sleep(1000);
		getElement(toDateXpath).sendKeys(today_fmt);
		Thread.sleep(1000);
		String submitBtn = "//button[@type='submit']";
		getElement(submitBtn).click();
		Thread.sleep(3000);
		System.out.println("Submit complete");
		
		SimpleDateFormat format2 = new SimpleDateFormat("d/M/YYYY");
		String today_fmt2 =  format2.format(today);
		System.out.println("Expected Date - " +today_fmt2);
		
		String startdate = "//div[contains(text(),'Start Date')]";
		String text = getElement(startdate).getText();
		
		if(text.contentEquals("Start Date : "+today_fmt2))
			System.out.println("Start Date Validated");
		else
			System.out.println("Start Date Validation failure");
		
		String enddate = "//div[contains(text(),'End date')]";
		text = getElement(enddate).getText();
		
		if(text.contentEquals("End date : "+today_fmt2))
			System.out.println("End Date Validated");
		else
			System.out.println("End Date Validation failure");
		
		Thread.sleep(1000);
		
		String paginationXpath = "//ul[contains(@class,'pagination')]";
		JavascriptExecutor je = (JavascriptExecutor) driver;
		WebElement pagination = driver.findElement(By.xpath(paginationXpath));
		je.executeScript("arguments[0].scrollIntoView(true)", pagination);
		String pagesXpath = "//li//a[not(contains(text(),'>')) and not(contains(text(),'<'))]";
		
		WebElement lastPage = getSpecificTableRow(pagesXpath, getTableSize(pagesXpath));
		boolean onlyOnePage = getTableSize(pagesXpath)==1?true:false;
		System.out.println("Clicking on last page");
		lastPage.click();
		Thread.sleep(2000);
		System.out.println("Clicked on last page");
		
		/*
		 * 
		 *  1 round id
		 *  2 game name
		 *  3 date
		 *  4 currency
		 *  5 bet
		 *  6 win
		 *  
		 */
		
		int spinsToValidate = 5;
		String tableRowsXpath = "//tbody/tr";
		int currPageRows = getTableSize(tableRowsXpath);
		if(spinsToValidate > currPageRows && !onlyOnePage)
		{
			System.out.println("Rows to Validate in current page = " + currPageRows);
			System.out.println("Rows to Validate in previous page = " + (spinsToValidate - currPageRows));
		}
		else if(spinsToValidate > currPageRows && onlyOnePage)
		{
			System.out.println("Only one page - Rows to validate are more than page entries");
		}
		else
		{
			System.out.println("Rows to validate in current page = "+currPageRows);
		}
	}
	
	public int getTableSize(String locator)
	{
		int tableSize = getTableRows(locator).size();
		System.out.println("Number of rows - "+ tableSize);
		return tableSize;
	}
	
	public List<WebElement> getTableRows(String locator)
	{
		System.out.println("Identifying number of rows for - "+locator);
		List<WebElement> detailTableRows = driver.findElements(By.xpath(locator));
		return detailTableRows;
	}
	
	public WebElement getSpecificTableRow(String tableLocator, int row)
	{
		System.out.println("Returning row "+row+" from table - "+tableLocator);
		return getTableRows(tableLocator).get(row-1);
	}
	
	public WebElement getElement(String locator)
	{
		System.out.println("Identifying WebElement for - " +locator );
		return driver.findElement(By.xpath(locator));
	}
}

package random;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ClearCacheChrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\emani.chaitanya\\drivers\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.co.in/");
		
		/*
		 * ChromeOptions options = new ChromeOptions();
		 * //options.addArguments("user-data-dir=/path/to/user/profile");
		 * WebDriverManager.chromedriver().setup(); WebDriver driver = new
		 * ChromeDriver(); driver.get("https://www.google.com"); // navigate to the
		 * settings page driver.get("chrome://settings/clearBrowserData");
		 * 
		 * 
		 * // wait for the settings page to load WebDriverWait wait = new
		 * WebDriverWait(driver, Duration.ofSeconds(30));
		 * wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(
		 * "settings-ui")));
		 * 
		 * // select the clear cache option WebElement clearCacheButton =
		 * driver.findElement(By.cssSelector("[aria-label='Clear browsing data']"));
		 * clearCacheButton.click();
		 * 
		 * // wait for the confirmation dialog to appear
		 * wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(
		 * "settings-confirmation-dialog")));
		 * 
		 * // click the confirm button to clear the cache WebElement confirmButton =
		 * driver.findElement(By.cssSelector("[aria-label='Clear']"));
		 * confirmButton.click();
		 * 
		 * // close the browser driver.quit();
		 */


	}

}

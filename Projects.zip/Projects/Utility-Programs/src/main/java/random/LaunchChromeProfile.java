package random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class LaunchChromeProfile {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\emani.chaitanya\\drivers\\chromedriver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("user-data-dir=C:\\Users\\emani.chaitanya\\OneDrive - Entain Group\\Desktop\\User Data\\");
		option.addArguments("--profile-directory=Default");
		WebDriver driver = new ChromeDriver(option);
		driver.get("chrome://flags");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='search']")).sendKeys("Override software rendering list");
		Thread.sleep(2000);
	
	}

}

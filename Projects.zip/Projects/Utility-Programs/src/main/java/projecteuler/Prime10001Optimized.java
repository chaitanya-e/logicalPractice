package projecteuler;

public class Prime10001Optimized {

	public static void main(String[] args) {
		//System.out.println(isPrime(21));
		int counter=0,number=2;
		/*
		 * for(number=3;counter<=10000;number=number+2) {
		 * 
		 * if(isPrime(number)) counter++; System.out.println(number+":"+counter); }
		 * 
		 * System.out.println(number);
		 */
		
		while (counter < 10001) {
			if (isPrime(number)==true) {
				System.out.println("Number - " + number);
				counter++;
			}
			number++;
		}
		number--;
		System.out.println(number);
	}
	
	public static boolean isPrime(int number)
	{
		boolean isPrime=false;
		if(number==1)
			return false;
		if(number==2)
			return true;
		for(int i=2;i*i<=number;i++)
		{
			//System.out.println("Factor - "+i);
			if(number%i==0)
			{
				isPrime=true;
				break;
			}
		}
		
		return isPrime;
	}

}

package projecteuler;

public class Prime10001 {
	public static void main(String[] args) {
		int counter = 0;
		int number = 2;

		while (counter < 10001) {
			if (isPrime(number)) {
				System.out.println("Number - " + number);
				counter++;
			}
			number++;
		}
		number--;
		System.out.println(number);

	}

	public static boolean isPrime(int number) {
		boolean flag = true;
		for (int i = 2; i <= (number / 2); i++) {
			if (number % i == 0) {
				flag = false;
				break;
			}
		}
		if (flag == false) {
			//System.out.println("Not a prime");
			return false;
		} else {
			//System.out.println("Prime");
			return true;
		}

	}
}

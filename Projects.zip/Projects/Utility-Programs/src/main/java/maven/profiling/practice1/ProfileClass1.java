package maven.profiling.practice1;

import org.testng.annotations.Test;

public class ProfileClass1 {
@Test
public void method1()
{
	System.out.println("Package 1 Class 1 Method 1");
}
}

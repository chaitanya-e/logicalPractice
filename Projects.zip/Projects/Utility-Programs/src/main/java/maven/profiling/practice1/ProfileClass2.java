package maven.profiling.practice1;

import org.testng.annotations.Test;

public class ProfileClass2 {
@Test
public void method2()
{
	System.out.println("Package 1 Class 2 Method 2");
}
}

package maven.profiling.practice2;

import org.testng.annotations.Test;

public class ProfileClass3 {
@Test
public void method3()
{
	System.out.println("Package 2 Class 3 Method 3");
}
}

package maven.profiling;

public abstract class AbstractClass1 implements Interface1 {
	public void abstractClassMethod()
	{
		System.out.println("Inside abstractClassMethod");
	}
}

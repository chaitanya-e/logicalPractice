package maven.profiling.practice2;

import org.testng.annotations.Test;

public class ProfileClass4 {
@Test
public void method4()
{
	System.out.println("Package 2 Class 4 Method 4");
}
}

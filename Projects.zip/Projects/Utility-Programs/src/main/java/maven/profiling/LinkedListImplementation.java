package maven.profiling;

public class LinkedListImplementation {
	
	LinkedListClass head;
	
	public static class LinkedListClass{
		String value;
		LinkedListClass next;
		
		LinkedListClass(String value)
		{
			this.value = value;
			this.next = null;
		}
	}
	
	
	public void insertAtBeginning(String newNodeValue)
	{
		if(head.next==null)
		{
			head = new LinkedListClass(newNodeValue);
		}
		else
		{
			LinkedListClass temp = new LinkedListClass(newNodeValue);
			temp.next = head;
			head = temp;
		}
	}
	
	public void displayNodes()
	{
		LinkedListClass start = head;
		while(start.next!=null)
		{
			System.out.println(start.value);
			start=start.next;
		}
	}
	
	public static void main(String[] args) {
		LinkedListImplementation lobj = new LinkedListImplementation();
		lobj.head = new LinkedListImplementation.LinkedListClass("12");
		lobj.displayNodes();
	}
}

package maven.profiling;

public interface Interface1 {
	
	public void InterfaceMethod();

}

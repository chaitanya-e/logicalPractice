package maven.profiling;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.stream.Stream;

public class SimpleExercises {

	public static void main(String[] args) {
		
		System.out.println("Factorial Recursion = " + getFact(5));

		fibonacciSeriesCheck(15);

		float f1 = 2.3f;
		float f2 = 3.4f;
		System.out.println("Float Product = " + f1 * f2);

		// divisible by 4 - non-century years
		// divisible by 400 - century years
		leapYearCheck(2012);

		numberOfDigits(102000);

		for (char c = 'a'; c <= 'z'; c++)
			System.out.print(c);

		System.out.println();

		reverseANumber(10203);

		reverseWithoutThirdVariable();

		for (int k = 2; k < 100; k++) {
			primeNumber(k);
		}
		
		printCharInString();
		
		duplicateElementsInArray();
		
		String frequency = "10011101101";
		
	}
	
	public static void factorial()
	{
		int n = 5, ans = 1;
		for (int i = 1; i <= n; i++)
			ans = ans * i;

		System.out.println("Factorial = " + ans);
	}
	
	public static void printCharInString()
	{
		String s1= "catastrophe";
		for(char c:s1.toCharArray())
			System.out.println(c);
	}

	public static void duplicateElementsInArray() {
		int a[] = { 1, 3, 23, 11, 44, 3, 23, 2, 3, 2, 11 };

		Set<Integer> duplicateSet = new HashSet<Integer>();
		for (int i = 0; i < a.length; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if (a[i] == a[j]) {
					if (!duplicateSet.contains(a[i])) {
						duplicateSet.add(a[i]);
					}
				}
			}
		}

		Iterator<Integer> it = duplicateSet.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}

	public static void printDuplicate(int[] a) {
		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
		for (int i : a) {
			if (hm.containsKey(i))
				hm.replace(i, hm.get(i) + 1);
			else
				hm.put(i, 1);
		}
		for (int key : hm.keySet()) {
			System.out.println(key + " -- " + hm.get(key));
			if (hm.get(key) > 0)
				System.out.println("repeat - " + key);
		}
	}

	public static void primeNumber(int input) {
		boolean flag = false;
		for (int i = 2; i <= (input / 2); i++) {
			if (input % i == 0) {
				flag = true;
				break;
			}
		}
		if (flag == false)
			System.out.println("Prime - " + input);
		// else
		// System.out.println("Composite");
	}

	public static void reverseWithoutThirdVariable() {
		int a = 10;
		int b = 20;
		System.out.println("Input - " + a + " ; " + b);
		a = a + b;
		b = a - b;
		a = a - b;
		System.out.println("Output - " + a + " ; " + b);
	}

	public static void reverseANumber(int temp) {
		int reverse = 0;
		while (temp != 0) {
			int lastdigit = temp % 10;
			reverse = (reverse * 10) + lastdigit;
			temp = temp / 10;
		}
		System.out.println(reverse);
	}

	public static void numberOfDigits(int temp) {
		int digits = 0;
		while (temp != 0) {
			digits++;
			temp = temp / 10;
		}
		System.out.println("Digits of number = " + digits);
	}

	public static void fibonacciSeriesCheck(int max) {
		int first = 0;
		int i = 1, j = 1;
		int result = i;
		System.out.println("Fibonacci series");
		System.out.println(i);
		System.out.println(j);
		do {
			result = i + j;
			System.out.println(result);
			i = j;
			j = result;
		} while (i + j < max);
	}

	public static void leapYearCheck(int year) {
		if (year % 4 == 0) {
			if (year % 100 == 0) {
				if (year % 400 == 0) {
					System.out.println("Century year and leap year");
				} else {
					System.out.println("Century year but non-leap year");
				}
			} else {
				System.out.println("Non-century leap year");
			}
		} else {
			System.out.println("Non-century but non-leap year");
		}
	}

	public static int getFact(int num) {
		if (num > 1)
			return num * getFact(num - 1);
		else
			return 1;
	}

}

package maven.profiling;

public class BaseClass1 extends AbstractClass1{

	@Override
	public void InterfaceMethod() {
		// TODO Auto-generated method stub
		System.out.println("Within BaseClass1.InterfaceMethod");
	}
	
	public static void main(String[] args) {
		AbstractClass1 absClsObj = new BaseClass1();
		absClsObj.InterfaceMethod();
	}

}

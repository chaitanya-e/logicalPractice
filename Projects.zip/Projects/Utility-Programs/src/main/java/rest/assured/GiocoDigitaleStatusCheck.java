package rest.assured;

import org.testng.annotations.Test;

public class GiocoDigitaleStatusCheck {
	String URL = "http://172.17.152.20:10150/?action=status&account=117063006";

	@Test
	public void testGuru99API() {
		C00RestAssuredUtils restObj = new C00RestAssuredUtils(URL);
		restObj.sendGetRequest();
		System.out.println(restObj.getResponseStatus());
		System.out.println(restObj.getResponseBody());
	}
}

package rest.assured;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class C00RestAssuredUtils {
	String URI;
	RequestSpecification httpRequest;
	Response response;

	C00RestAssuredUtils(String URI) {
		this.URI = URI;
		httpRequest = RestAssured.given();
	}

	public void sendGetRequest() {
		response = httpRequest.get(URI);
	}

	public int getResponseStatus() {
		return response.getStatusCode();
	}

	public String getResponseBody() {
		ResponseBody body = response.getBody();
		return body.asString();
	}
}

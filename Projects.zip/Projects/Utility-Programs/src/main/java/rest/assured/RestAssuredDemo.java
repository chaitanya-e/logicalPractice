package rest.assured;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

public class RestAssuredDemo {
	String URL = "http://demo.guru99.com/V4/sinkministatement.php";
	String URL2 = "http://demo.guru99.com/V4/sinkministatement.php?CUSTOMER_ID=68195&PASSWORD=1234!&Account_No=1";

	@Test
	public void testGuru99API() {
		getResponseBody();
		getResponseStatus();
	}

	public void getResponseStatus() {
		int statusCode = given().queryParam("CUSTOMER_ID", "68195").queryParam("PASSWORD", "1234!")
				.queryParam("Account_No", "1").when().get(URL).getStatusCode();

		System.out.println("Response Code is " + statusCode);

		given().when().get(URL).then().assertThat().statusCode(200);
	}

	public void getResponseBody() {
		given().when().get(URL2).then().log().all();

		given().queryParam("CUSTOMER_ID", "68195").queryParam("PASSWORD", "1234!").queryParam("Account_No", "1").when()
				.get(URL).then().log().body();
	}

}

package webscraping;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.bson.Document;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.json.*;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Scraper {
	WebDriver driver;
	String url = "https://www.reddit.com/r/news/";
	MongoClient mongoClient;
	MongoDatabase mongoDatabase;
	MongoCollection<Document> mongoCollection;
	Document mongoDocument;
	org.jsoup.nodes.Document jsoupDocument;
	

	@BeforeTest
	public void setup() {
		//MongoDB Connection Setup - Connect to Reddit
		mongoClient = new MongoClient("localhost", 27017);
		//mongoDatabase = mongoClient.getDatabase("Reddit");
		mongoDatabase = mongoClient.getDatabase("Columbus");
		//mongoCollection = mongoDatabase.getCollection("HTML_Pages");
		mongoCollection = mongoDatabase.getCollection("Giocodigitale");
		System.out.println("MongoDB Client, Database and Collection are successfully establised");
		
		//ChromeDriver Setup
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"}); 
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		System.out.println("Chromedriver successfully established");
		
		System.out.println("Setup() is complete");
	}

	@Test
	public void insertData() throws IOException {
		//Open Reddit URL
		driver.get(url);
		//String htmlPageSource = driver.getPageSource();
		//Read all headings from website and store it in MongoDB
		String pageHeadingsXpath = "//h3[@class='_eYtD2XCVieq6emjKBH3m']";
		List<WebElement> pageHeadings = driver.findElements(By.xpath(pageHeadingsXpath));
		String[] headings = new String[pageHeadings.size()];
		int index = 0;
		for(WebElement heading : pageHeadings)
		{
			headings[index] = heading.getText();
			index++;
		}
		System.out.println("Headings in the web page are retreived from URL");
		//System.out.println(Arrays.toString(headings));

		//Create HTML page source as Document
		//mongoDocument = new Document("URL",url).append("HTML", htmlPageSource);
		String tempString = Arrays.toString(headings);
		//mongoDocument = new Document("URL",url).append("Page_Headings", tempString);
		
		//test to push extent report to mongoDB
		String jsonPath = "C:\\Users\\emani.chaitanya\\eclipse-workspace\\columbusus\\src\\main\\resources\\report\\07_09_2021\\Columbus_GiacoDigitale_Book_of_Venus_GameSpinValidations.json";
		String  jsonString = new String(Files.readAllBytes(Paths.get(jsonPath)));
		
		//format Json
		JSONArray jArr = new JSONArray(jsonString);
		JSONObject obj = jArr.getJSONObject(0);
		
		String name = obj.getString("name");
		System.out.println(name);
		String status = obj.getString("status");
		System.out.println(status);
		
		//push to mongo
		//mongoDocument = new Document("Extrent_Report",jsonString);
		
		System.out.println("Document object is prepared");
		
		//Add the Document to a collection
		//mongoCollection.insertOne(mongoDocument);
		System.out.println("Page Source Document is inserted into collection");
		
		System.out.println("insertData() is complete");
	}
	
	public void retrieveAllDocuments(){
		FindIterable<Document> documentIterator = mongoCollection.find();
	      Iterator<Document> document  = documentIterator.iterator();
	      while (document.hasNext()) {
	         System.out.println(document.next());
	      }
		System.out.println("Retrieved Document in the collection");
	}
	
	public String retrieveFirstDocument()
	{
		return mongoCollection.find().first().toString();
	}
	
	@Test
	public void parseHTMLSource()
	{
		String pageSource = retrieveFirstDocument();
		jsoupDocument = Jsoup.parse(pageSource);
		Elements jsoupElements = jsoupDocument.getElementsByAttributeValue("class", "_eYtD2XCVieq6emjKBH3m");
		System.out.println("Printing H3 elements");
		for(Element element:jsoupElements)
		{
			System.out.println(element.text());
		}
	}
	
	@AfterTest
	public void tearDown() {
		mongoClient.close();
		//driver.quit();
		System.out.println("MongoClient collection and Chrome are closed");
		
		System.out.println("tearDown() is complete");
	}
}

package collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class CollectionsPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Adding two lists");
		List<String> list1 = new ArrayList<String>();
		List<String> list2 = new ArrayList<String>();
		list1.add("2");
		list1.add("3");
		System.out.println("List1 - "+list1);
		list2.add("4");
		list2.add("5");
		System.out.println("List2 - "+list2);
		list1.addAll(list2);
		System.out.println("Result - "+list1);
		List<String> result = new ArrayList<String>();
		// Streams -> map, filter, sorted
		// collect, foreach, reduce
		List elements = Arrays.asList(1,2,3,4);
		//elements = elements.stream().map(x->x*x).collect(Collectors.toList());
		
		List number = Arrays.asList(2,3,4,5,3);
		//Object square = number.stream().map(x->x*x).collect(Collectors.toSet());
		System.out.println(elements);
		
		System.out.println("Collection to Array");
		List<String> l1 = new ArrayList<String>();
		l1.add("a");
		l1.add("b");
		l1.add("c");
		Object s[] = l1.toArray();
		System.out.println("Object Array - "+Arrays.toString(s));
		
		String[] s2 = new String[l1.size()];
		l1.toArray(s2);
		System.out.println("String Array - "+Arrays.toString(s2));
		
		String[] sa = {"a","b","c"};
		List<String> op = Arrays.asList(sa);
		System.out.println("Array to List - "+op);
		Set<String> sp = new TreeSet<String>(Arrays.asList(sa));
		System.out.println(sp);
		
		System.out.println();
		System.out.println("hashmap to list");
		Map<Integer,String> m = new HashMap<Integer,String>();
		m.put(1, "a");
		m.put(2, "b");
		m.put(3, "c");
		m.put(4, "d");
		
		//Set<Integer> keys = m.keys
		
		
	}

}

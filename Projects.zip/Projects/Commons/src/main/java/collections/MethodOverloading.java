package collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;

public class MethodOverloading {
	public static void meth1(long a, int b) {
		System.out.println("meth1 - long");
	}
	public static void meth1(int b, long a) {
		System.out.println("meth1 - long");
	}
	/*
	public static void meth1(int a) {
		System.out.println("meth1 - int");
	}
	*/
	public static void meth1(short a) {
		System.out.println("meth1 - short");
	}
	

	public static void main(String[] args) {
		meth1((short)1);
		//meth1(1,1);
		short a1 = 1;
		a1++;
		a1 = (short) (a1+1);
		
		Integer n1[]={99,1,2,3,4,5};
		
		Integer b1[]={6,7,8,2,1};
		
		List<Integer> al1 = Arrays.asList(n1);
		List<Integer> al2 =  Arrays.asList(b1);
		
		//al1.addAll(al2);
		
		TreeSet<Integer> ts= new TreeSet<Integer>(al1);
		ts.addAll(al2);
		System.out.println(ts);
	}
}

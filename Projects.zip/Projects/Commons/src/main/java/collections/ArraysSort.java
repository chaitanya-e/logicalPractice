package collections;

public class ArraysSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = {134,110,167};
		String names[] = {"John","Doe","Kirk"};
		int indexStorage[] = {0,1,2};
		
		for(int i=0;i<a.length-1;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]<a[j])
				{
					int temp=a[j];
					a[j]=a[i];
					a[i]=temp;
					
					int temp2=indexStorage[j];
					indexStorage[j]=indexStorage[i];
					indexStorage[i]=temp2;
				}
			}
		}
		
		for(int i:indexStorage)
			System.out.println(names[i]);
	}

}

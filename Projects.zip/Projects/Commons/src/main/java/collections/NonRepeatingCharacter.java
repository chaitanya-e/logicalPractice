package collections;

import java.util.HashSet;
import java.util.Set;

public class NonRepeatingCharacter {
	public static void main(String[] args) {
		String s = "eeaaz";
		
		Set<String> s1 = new HashSet<String>();
		int retIndex=Integer.MAX_VALUE;
		
		for(int i=0;i<s.length();i++)
		{
			String temp = s.substring(i,i+1);
			if(s.substring(i+1, s.length()).contains(temp)||s1.contains(temp))
			{
				s1.add(temp);
			}
			else
			{
				retIndex=i;
				break;
			}
		}
		
		if(retIndex==Integer.MAX_VALUE)
			System.out.println("-1");
		else
			System.out.println(retIndex);
		
		/*
		char[] c = s.toCharArray();
		Set<Character> s1 = new HashSet<Character>();
		boolean matchesflag = false;
		int i;
		for (i = 0; i < s.length(); i++) {
			matchesflag = false;
			if ((!s1.contains(c[i]))||(i==s.length())) {
				for (int j = i + 1; j < s.length(); j++) {

					if (c[i] == c[j]) {
						// i=j+1;
						s1.add(c[i]);
						matchesflag = true;
						break;
					}
				}
				if (matchesflag == true) {
					i++;
				} else
					break;
			}
		}

		if (matchesflag == true)
			System.out.println(-1);
		else
			System.out.println(i);
*/
	}
}

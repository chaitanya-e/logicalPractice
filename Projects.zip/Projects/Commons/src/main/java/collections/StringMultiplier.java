package collections;

public class StringMultiplier {
	public static void main(String[] args) {
		String str = "aba";
		String tempStr = null;
		for (int i = 1; i <= str.length(); i++) {
			tempStr = str.substring(0, i);
			int multiplier = str.length() / i;
			String compare = multiplierFn(tempStr, multiplier);
			if (str.equals(compare))
				break;
		}
		if(tempStr.equals(str))
			System.out.println(false);
		else
			System.out.println(true + ":"+tempStr);
	}

	static String multiplierFn(String s, int m) {
		String res = "";
		for (int i = 0; i < m; i++)
			res = res + s;
		return res;
	}
}

package selenium;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ChromeFlag {
	public static void main(String[] args) {
		String s = "sad";
		String s2 = "sadbutsad";
		int index = s2.indexOf(s);
		//Pattern m = Matcher
		while(index>=0)
		{
			System.out.println(index);
			index = s2.indexOf(s,index+1);
		}
		
		ArrayList<String> a1 = new ArrayList<String>(); //abcd
		a1.add("a");
		a1.add("b");
		a1.add("c");
		a1.add("d");
		ArrayList<String> a2 = new ArrayList<String>(); //defg
		a2.add("d");
		a2.add("e");
		a2.add("f");
		a2.add("g");
		
		//System.out.println(a1.add);
		
		ArrayList<String> a4 = (ArrayList<String>) a1.clone();
		a4.addAll(a2);
		System.out.println(a4);
		
		//System.out.println(a1);
		ArrayList<String> a3 = a1;
		a3.retainAll(a2);
		System.out.println(a1);
		
		a4.removeAll(a3);
		
		System.out.println(a4);
		
		HashMap<Integer,String> hm = new HashMap<Integer,String>();
		hm.put(1, "a");
		hm.put(2, "b");
		hm.put(3, "c");
		
		Set<Map.Entry<Integer, String>> entries = hm.entrySet();
		for(Map.Entry<Integer,String> entry:entries)
		{
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
		}
		
		hm.forEach((key,value) -> {
			System.out.println(key + value);
		});
		
		String[] s1 = {"asd","asdf","assg","aser"};
		Arrays.sort(s1);
		System.out.println(Arrays.toString(s1));
	}
}

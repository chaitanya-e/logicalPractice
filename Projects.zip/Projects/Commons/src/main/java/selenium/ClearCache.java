package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ClearCache {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		System.out.println("Start");
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\emani.chaitanya\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.get("chrome://settings/clearBrowserData");
		//driver.get("http://watir.com/examples/shadow_dom.html");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		/*
		 * WebElement all = (WebElement)js.
		 * executeScript("document.querySelector('settings-ui').shadowRoot.querySelector('settings-main').shadowRoot.querySelector('settings-basic-page').shadowRoot.querySelector('settings-section > settings-privacy-page').shadowRoot.querySelector('settings-clear-browsing-data-dialog').shadowRoot.querySelector('#clearBrowsingDataDialog').shadowRoot.querySelector('settings-dropdown-menu').querySelector('#dropdownMenu')"
		 * ); Select time = new Select(all); time.selectByVisibleText("All time");
		 * Thread.sleep(5000); //all.click(); WebElement clearData = (WebElement) js.
		 * executeScript("return document.querySelector('settings-ui').shadowRoot.querySelector('settings-main').shadowRoot.querySelector('settings-basic-page').shadowRoot.querySelector('settings-section > settings-privacy-page').shadowRoot.querySelector('settings-clear-browsing-data-dialog').shadowRoot.querySelector('#clearBrowsingDataDialog').querySelector('#clearBrowsingDataConfirm')"
		 * );
		 */
		// now you can click on clear data button
		//clearData.click();
		
		/*
		 * SearchContext clearDataDialog = driver.findElement(By.tagName("settings-ui"))
		 * .getShadowRoot() .findElement(By.cssSelector("#main")) .getShadowRoot()
		 * .findElement(By.cssSelector(".cr-centered-card-container")) .getShadowRoot()
		 * .findElement(By.
		 * cssSelector("#basicPage > settings-section[page-title='Privacy and security'] > settings-privacy-page"
		 * )) .getShadowRoot()
		 * .findElement(By.cssSelector("settings-clear-browsing-data-dialog"))
		 * .getShadowRoot();
		 * 
		 * WebElement basicDropDown = clearDataDialog
		 * .findElement(By.cssSelector("#clearBrowsingDataDialog #clearFromBasic"))
		 * .getShadowRoot() .findElement(By.cssSelector("#dropdownMenu"));
		 * 
		 * Select dropdown = new Select(basicDropDown);
		 * dropdown.selectByVisibleText("All time");
		 * 
		 * WebElement clearDataBtn = clearDataDialog .findElement(By.
		 * cssSelector("#clearBrowsingDataDialog #clearBrowsingDataConfirm"));
		 * 
		 * clearDataBtn.click();
		 */
		
		/*
		 * WebElement shadowHost = driver.findElement (By.id ("shadow_host"));
		 * SearchContext shadowRoot = shadowHost.getShadowRoot (); String text =
		 * shadowRoot.findElement (By.cssSelector ("#shadow_content > span")) .getText
		 * (); System.out.println(text);
		 * 
		 * WebElement nestedShadowRoot =
		 * shadowRoot.findElement(By.cssSelector("#nested_shadow_host")); SearchContext
		 * nestedShadowRootCxt = nestedShadowRoot.getShadowRoot(); String text2 =
		 * nestedShadowRootCxt.findElement(By.cssSelector("#nested_shadow_content > div"
		 * )).getText(); System.out.println(text2);
		 */
		
		
		
		
		WebElement w1 = driver.findElement(By.cssSelector("settings-ui"));
		WebElement w4 = getShadowRootElementJS(
							getShadowRootElementJS(
									getShadowRootElementJS(w1,"#main"),
										".cr-centered-card-container"
												),
				"#basicPage > settings-section[page-title='Privacy and security'] > settings-privacy-page");
		WebElement w5 = getShadowRootElementJS(w4,"settings-clear-browsing-data-dialog");
		
		WebElement w6 = getShadowRootElementJS(w5,"#clearBrowsingDataDialog #clearFromBasic");
		WebElement w7 = getShadowRootElementJS(w6,"#dropdownMenu");
		
		Select dropdown1 = new Select(w7);
		dropdown1.selectByVisibleText("All time");
		
		WebElement w8 = getShadowRootElementJS(w5,"#clearBrowsingDataDialog #clearBrowsingDataConfirm");
		w8.click();
		
	}
	
	public static WebElement getShadowRootElementJS (WebElement element, String cssSelector) {
	       SearchContext shadowRoot = (SearchContext) ((JavascriptExecutor)driver).executeScript (
	           "return arguments[0].shadowRoot", element);
	       return shadowRoot.findElement(By.cssSelector(cssSelector));
	   }
	

	
	
	
}

package selenium;

import utils.AbstractCommands;

public class FrameworkLaunchTest extends AbstractCommands{

	public String skip;

	public void esegui() throws Exception {
		driverGet("http://google.com");
	}
}

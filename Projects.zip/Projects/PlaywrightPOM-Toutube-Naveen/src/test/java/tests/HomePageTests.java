package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseTests;
import constants.ApplicationConsts;

public class HomePageTests extends BaseTests {
	
	
	
	
	@Test
	public void validateHomePageTitle() {
		Assert.assertEquals(home.getHomePageTitle(), ApplicationConsts.HOME_PAGE_TITLE);
	}

	@Test
	public void validateHomePageURL() {
		Assert.assertEquals(home.getHomePageURL(), props.getProperty("url"));
	}

	@Test(dataProvider="searchProductData")
	public void validateSearchProduct(String product) {
		Assert.assertEquals(home.searchProduct(product), "Search - "+product);
	}

	@DataProvider
	public Object[][] searchProductData() {
		return new Object[][] { 
			{ "macbook" }, 
			{ "iphone" },
			{"airpods"} 
			};

	}
	
	
}

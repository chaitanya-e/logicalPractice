package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTests;
import constants.ApplicationConsts;

public class LoginPageTests extends BaseTests {
	
	@Test(priority = 1)
	public void goToLoginPageTest()
	{
		login = home.navigateToLoginPage();
		//Assert.assertTrue(login.isForgotPasswordVisible());
		Assert.assertEquals(login.getLoginPageTitle(), ApplicationConsts.LOGIN_PAGE_TITLE);
	}
	
	@Test(priority = 2)
	public void loginTest()
	{
		myAccount = login.login(props.getProperty("username"), props.getProperty("password"));
		Assert.assertEquals(myAccount.getMyAccountPageTitle(),ApplicationConsts.MY_ACCOUNT_PAGE_TITLE);
	}
	

}

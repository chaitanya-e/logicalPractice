package constants;

public class ApplicationConsts {
	public static final String HOME_PAGE_TITLE = "Your Store";
	public static final String LOGIN_PAGE_TITLE = "Account Login";
	public static final String MY_ACCOUNT_PAGE_TITLE = "My Account";
}

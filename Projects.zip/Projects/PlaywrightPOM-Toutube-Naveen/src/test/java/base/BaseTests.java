package base;

import java.util.Properties;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.microsoft.playwright.Page;

import pages.HomePage;
import pages.LoginPage;
import pages.MyAccountPage;
import playwright_factory.Playwright_Factory_Utilities;

public class BaseTests {
	Playwright_Factory_Utilities pw_factory;
	Page page;
	protected HomePage home;
	protected LoginPage login;
	protected MyAccountPage myAccount;
	protected Properties props;

	
	@BeforeTest
	public void setup() {
		pw_factory = new Playwright_Factory_Utilities();
		props = pw_factory.propertyFileHandler();
		page = pw_factory.launchPlaywrightBrowser(props);
		home = new HomePage(page);
	}
	@AfterTest
	public void tearDown() {
		page.context().browser().close();
	}

}

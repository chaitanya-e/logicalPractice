package playwright_factory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.BrowserType.LaunchOptions;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class Playwright_Factory_Utilities {
	Playwright playwright;
	Browser browser;
	Page page;

	BrowserContext browserContext;

	public Page launchPlaywrightBrowser(Properties props) {
		String browserName = props.getProperty("browser");
		System.out.println("Browser name is - " + browserName);
		playwright = Playwright.create();
		//boolean headless = props.getProperty("headless").equals("false")?false:true;
		//boolean headless = Boolean.valueOf(props.getProperty("headless"));
		boolean headless = Boolean.parseBoolean(props.getProperty("headless"));
		switch (browserName.toLowerCase()) {
		case "chromium":
			browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(headless));
			break;
		case "firefox":
			browser = playwright.firefox().launch(new BrowserType.LaunchOptions().setHeadless(headless));
			break;
		case "chrome":
			browser = playwright.chromium().launch(new LaunchOptions().setChannel("chrome").setHeadless(headless));
			break;
		default:
			System.out.println("No such browser type");
		}

		browserContext = browser.newContext();
		page = browserContext.newPage();
		page.navigate(props.getProperty("url"));
		
		return page;
	}

	public void closePlaywrightBrowser() {
		browserContext.close();
		browser.close();
		System.out.println("Browser closed");
	}
	
	public Properties propertyFileHandler()
	{
		FileInputStream fis = null;
		Properties props = null;
		try {
			fis = new FileInputStream(new File(".\\src\\test\\resources\\properties\\prop.properties"));
			props = new Properties();
			props.load(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return props;
	}
}

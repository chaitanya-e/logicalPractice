package pages;

import com.microsoft.playwright.Page;

public class HomePage {
	private Page page;
	
	private String searchBox = "input[name='search']";
	private String searchBtn = "span.input-group-btn";
	private String searchResultTitle = "div#content h1";
	private String myAccountDropdwn = "//span[contains(text(),'My Account')]";
	private String login = "//ul//a[contains(text(),'Login')]";
	
	
	public HomePage(Page page)
	{
		System.out.println("Home page initialization");
		this.page = page; 
	}
	
	public String getHomePageTitle()
	{
		String title =  page.title();
		System.out.println("Title is : "+title);
		return title;
	}
	
	public String getHomePageURL()
	{
		String url =  page.url();
		System.out.println("URL is : "+url);
		return url;
	}
	
	public String searchProduct(String searchPhrase)
	{
		System.out.println("searching for product : "+searchPhrase);
		page.fill(searchBox, searchPhrase);
		page.click(searchBtn);
		
		String title = page.textContent(searchResultTitle);
		System.out.println("Search result heading is : "+title);
		return title;
	}
	
	public LoginPage navigateToLoginPage()
	{
		page.click(myAccountDropdwn);
		page.click(login);
		System.out.println("Navigating to Login Page from My Account dropdown");
		return new LoginPage(page);
		
	}

	
	
}

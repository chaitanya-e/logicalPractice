package pages;

import com.microsoft.playwright.Page;

public class LoginPage {
	private Page page;
	private String username="input#input-email";
	private String password = "input#input-password";
	private String forgotPasswordLnk = "//div[@class='form-group']//a[contains(text(),'Forgotten Password')]";
	private String loginBtn = "//input[@type='submit']";
	private String logout="//a[@class='list-group-item'][normalize-space()='Logout']";
	
	public LoginPage(Page page)
	{
		
		this.page = page;
	}
	
	public String getLoginPageURL()
	{
		return page.url();
	}
	
	public String getLoginPageTitle()
	{
		String title = page.title();
		System.out.println("Login Page title : "+title);
		return title;
	}
	
	public boolean isForgotPasswordVisible()
	{
		return page.isVisible(forgotPasswordLnk);
	}
	
	public MyAccountPage login(String loginUserName, String loginPassword)
	{
		page.fill(username, loginUserName);
		page.fill(password, loginPassword);
		page.click(loginBtn);
		System.out.println("Entered login Credentials and clicked on login");
		try {
		Thread.sleep(5000);}catch(Exception e) {e.printStackTrace();}
		if(page.isVisible(logout))
		{
			System.out.println("User logged in successfully");
			return new MyAccountPage(page);
		}
		return null;
		
	}
}

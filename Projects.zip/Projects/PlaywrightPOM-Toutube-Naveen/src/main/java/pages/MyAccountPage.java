package pages;

import com.microsoft.playwright.Page;

public class MyAccountPage {
	private Page page;
	private String logout="//a[@class='list-group-item'][normalize-space()='Logout']";
	
	public MyAccountPage(Page page)
	{
		this.page = page;
	}
	
	public String getMyAccountPageTitle()
	{
		String title =  page.title();
		System.out.println("My Account page title : "+title);
		return title;
	}
	

}

package com.utilites;

import java.text.SimpleDateFormat;
import java.util.Date;
import com.google.gson.JsonObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import com.mongodb.util.JSON;

public class GetMongoDb {
	static DBCollection col;

	public void createConnection(String IPAddress, Integer port, String DBname, String CollectionName,
			JsonObject jsonObject) {
		try {
			MongoClient mongo = new MongoClient(IPAddress, port);
			DB db = mongo.getDB("Eb" + DBname);
			if (DBname.equals("Prod")) {
				col = db.getCollection("P" + CollectionName);
			} else if (DBname.equals("Stage")) {
				col = db.getCollection("S" + CollectionName);
			} else if (DBname.equals("Test")) {
				col = db.getCollection("T" + CollectionName);
			}
			SimpleDateFormat sdDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSXXX");
			String date = sdDateFormat.format(new Date());
			jsonObject.addProperty("createdAt", date.toString());
			DBObject doc = (DBObject) JSON.parse(jsonObject.toString());
			WriteResult result = col.insert(doc);
			System.out.println("Successfully saved...");
		} catch (Exception e) {
			System.out.println("Exception! " + e.getMessage());
		}
	}
}

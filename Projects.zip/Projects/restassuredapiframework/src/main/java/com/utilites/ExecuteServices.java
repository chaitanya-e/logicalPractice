package com.utilites;

import java.util.Map;
import com.aventstack.extentreports.Status;
import com.reusables.Prerequisites;
import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ExecuteServices extends Prerequisites {

	public static Response response;

	public static Response actionPerform(String baseURI, String httpmethod, Object requestbody, String endpoint,
			Map<String, String> headers) {
		try {

			System.setProperty("https.proxyHost", "192.168.141.33");
			System.setProperty("https.proxyPort", "3128");
			 
			
			RestAssured.baseURI = baseURI;
			EncoderConfig encoderconfig = new EncoderConfig();
			RequestSpecification request = RestAssured.given().config(RestAssured.config().encoderConfig(encoderconfig.appendDefaultContentCharsetToContentTypeIfUndefined(false)));
			
			extentTest = extentReports.createTest(testname).assignCategory(classname);
			extentTest.log(Status.INFO, "baseURL===" + baseURI);
			extentTest.log(Status.INFO, "Endpoint===" + endpoint);
			extentTest.log(Status.INFO, "Headers===" + headers);
			extentTest.log(Status.INFO, "RequestBody===" + requestbody.toString());
			extentTest.log(Status.INFO, "httpmethod===" + httpmethod);

			switch (httpmethod.toLowerCase()) {
			case "post":
				request.headers(headers);
				request.body(requestbody);
				response = request.post(endpoint);
				break;
			case "post-without-body":
				request.headers(headers);
				response = request.post(endpoint);
				break;
			case "get":
				request.headers(headers);
				response = request.get(endpoint);
				break;
			case "put":
				request.headers(headers);
				request.body(requestbody.toString());
				response = request.put(endpoint);
				break;
			case "delete-without-body":
				request.headers(headers);
				response = request.delete(endpoint);
				break;
			case "delete":
				request.headers(headers);
				request.body(requestbody.toString());
				response = request.delete(endpoint);
				break;
			default:
				break;
			}
			extentTest.log(Status.INFO, "ResponseBody===" + response.getBody().asString());
			return response;

		} catch (Exception e) {
			errorMessage=e.getMessage();
			System.out.println("Error=="+errorMessage);
			extentTest.log(Status.FAIL,"Error=="+errorMessage);
			return null;

		}

	}

}

package com.reusables;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlInclude;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.utilites.GetMongoDb;

public class Prerequisites {

	public static ExtentReports extentReports = new ExtentReports();
	public static ExtentTest extentTest;
	public static String ExtentReportPath;
	public static ITestResult result;
	public static JSONObject testResults;
	public static JSONObject testResultsWithName;
	public static Set<String> moduleNames = new HashSet<String>();
	public static HashMap<String, String> results = new HashMap<String, String>();
	public static String testresults;
	public static HashMap<String, String> failedTestcases = new HashMap<String, String>();
	public static FileInputStream fis = null;
	public static Properties prop = null;
	public static HashMap<String, String> testdata = new HashMap<String, String>();// excel data
	public static String testname = new String();
	public static String classname = new String();
	public static String errorMessage; 

	@BeforeSuite
	public void beforeSuite() throws IOException {

		try {

			// reading properties file
			fis = new FileInputStream("Configuration.properties");
			prop = new Properties();
			prop.load(fis);

			// reading testdata
			readTestdata(prop.getProperty("filename"));
			
			// setting extentreports
			SimpleDateFormat sdf = new SimpleDateFormat("MMddHHmmss");
			String date = sdf.format(new Date());
			ExtentSparkReporter spark = new ExtentSparkReporter(System.getProperty("user.dir") + "//TestReports//Services"+ date + ".html");
			extentReports.attachReporter(spark);
			
			ExtentReportPath="http://"+prop.getProperty("jenkinsip")+"/"+prop.getProperty("jenkinsfoldername")+"/TestReports/Services"+date+".html";

		} catch (Exception e) {
			e.getMessage();
		}

		finally {
			fis.close();
		}

	}

	@AfterSuite
	public void afterSuite() {

		storeResultsToMongoDB();
		generateFailedXML();
		EmailReport.sendEmail();

	}

	public void createJson(ITestResult result) {

		String testname = result.getName();
		String modulename[] = result.getTestClass().getName().split("\\.");
		String status = null;
		String log = null;
		String reportURL = null;

		if (!results.containsKey(modulename[2])) {
			testresults = null;
		}

		if (result.getStatus() == result.SUCCESS) {
			status = "PASS";
			log = "Test case Passed";
		} else if (result.getStatus() == result.FAILURE) {
			status = "FAIL";
			log = errorMessage;

			// for generating failedtestcases xml file start
			String classname = result.getTestClass().getName();

			if (failedTestcases.containsKey(classname)) {
				String temp = failedTestcases.get(classname);
				temp = temp + "|" + testname;
				failedTestcases.put(classname, temp);
			} else {
				failedTestcases.put(classname, testname);
			}

			// for generating failedtestcases xml file end

		}

		reportURL = ExtentReportPath;
		testresults = testresults + testname + "@" + status + "@" + log + "@" + reportURL + "|";
		results.put(modulename[2], testresults.replace("null", ""));

		// getting modulenames for mongodb json
		moduleNames.add(modulename[2]);
	}

	public void storeResultsToMongoDB() {

		JSONObject mongojson = new JSONObject();
		mongojson.put("test", prop.getProperty("testname"));
		JSONObject data = new JSONObject();

		// reports
		JSONArray reportsarr = new JSONArray();
		Iterator<String> modnames = moduleNames.iterator();
		while (modnames.hasNext()) {
			JSONObject reports = new JSONObject();
			reports.put(modnames.next(), ExtentReportPath);
			reportsarr.put(reports);

		}
		data.put("reports", reportsarr);

		// mapping
		JSONArray mapping = new JSONArray();
		for (Map.Entry<String, String> entry : results.entrySet()) {

			JSONArray mappingarr = new JSONArray();
			JSONObject Module = new JSONObject();
			String[] tcdetails = entry.getValue().split("\\|");
			String key = entry.getKey();

			for (String iteration : tcdetails) {

				String result[] = iteration.split("@");
				JSONObject tcresult = new JSONObject();
				JSONObject tcresultwithname = new JSONObject();
				tcresult.put("Status", result[1]);
				tcresult.put("Log", result[2]);
				tcresult.put("reportUrl", result[3]);

				tcresultwithname.put(result[0], tcresult);
				mappingarr.put(tcresultwithname);

			}
			Module.put(key, mappingarr);
			mapping.put(Module);
		}

		data.put("mapping", mapping);

		// modules
		JSONArray modulesarr = new JSONArray();
		modnames = moduleNames.iterator();
		while (modnames.hasNext()) {
			modulesarr.put(modnames.next());
		}
		data.put("modules", modulesarr);

		mongojson.put("data", data);
		mongojson.put("channel", prop.getProperty("channel"));
		mongojson.put("moduleName", prop.getProperty("moduleName"));
		mongojson.put("label", prop.getProperty("label"));
		mongojson.put("env", prop.getProperty("env"));
		mongojson.put("jenkinsRemoteBuildTriggerURL", prop.getProperty("jenkinsRemoteBuildTriggerURL"));

		System.out.println(mongojson);

		String ipAddress = prop.getProperty("ipAddress");
		Integer portNumber = Integer.parseInt(prop.getProperty("portNumber"));
		String env = prop.getProperty("env");
		String label = prop.getProperty("label");

		String jsonAsStringObject = mongojson.toString();
		JsonObject jsonObjectForMongoDb = (JsonObject) JsonParser.parseString(jsonAsStringObject);

		if (prop.getProperty("pushResultstoMongodb").equalsIgnoreCase("true")) {
			GetMongoDb mongoObj = new GetMongoDb();
			mongoObj.createConnection(ipAddress, portNumber, env, label, jsonObjectForMongoDb);
		}

	}

	public static void generateFailedXML() {

		XmlSuite mySuite = new XmlSuite();
		mySuite.setName("Failed Testsuite");

		XmlTest myTest = new XmlTest(mySuite);
		myTest.setName("Failed Tests");

		XmlClass myClass;
		List<XmlInclude> myMethods;

		for (String key : failedTestcases.keySet()) {

			myClass = new XmlClass(key);
			myMethods = new ArrayList<>();
			String testcasenames[] = failedTestcases.get(key).split("\\|");

			for (int i = 0; i < testcasenames.length; i++) {
				myMethods.add(new XmlInclude(testcasenames[i]));
			}
			myClass.setIncludedMethods(myMethods);
			myTest.getClasses().add(myClass);
		}

		mySuite.setThreadCount(1);

		FileWriter writer;
		try {
			writer = new FileWriter(new File("FailedTestcases.xml"));
			writer.write(mySuite.toXml());
			writer.flush();
			writer.close();
			System.out.println(new File("FailedTestcases.xml").getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@BeforeMethod
	public void BeforeMethod(Method method) {

		// testname and classname for extent reports
		testname = method.getName();
		classname = method.getDeclaringClass().getName().split("\\.", 3)[2];

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {

		createJson(result);
		extentReports.flush();

	}

	public static void readTestdata(String fileName) {
		try {

			Fillo fillo = new Fillo();
			Connection connection = fillo.getConnection(System.getProperty("user.dir") + "\\TestInputs\\" + fileName);
			String strQuery = "Select * from Testdata";
			Recordset recordset = connection.executeQuery(strQuery);
			while (recordset.next()) {
				testdata.put(recordset.getField("Name"), recordset.getField("Value"));
			}
			recordset.close();
			connection.close();
		} catch (FilloException e) {
			System.out.println(e.getMessage());

		}

	}

}

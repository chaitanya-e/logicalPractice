package com.reusables;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class EmailReport extends Prerequisites {

	public static void sendEmail() {

		try {

			String tolist[] = prop.getProperty("to").split(",");
			String cclist[] = prop.getProperty("cc").split(",");
			String from = prop.getProperty("from");
			String host = prop.getProperty("emailhost");

			// Get the session object
			Properties properties = System.getProperties();
			properties.setProperty("mail.smtp.host", host);
			Session session = Session.getDefaultInstance(properties);

			// compose the message
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));

			InternetAddress[] mailAddress_TO = new InternetAddress[tolist.length];
			for (int i = 0; i < tolist.length; i++) {
				mailAddress_TO[i] = new InternetAddress(tolist[i]);
			}

			InternetAddress[] mailAddress_CC = new InternetAddress[cclist.length];
			for (int i = 0; i < cclist.length; i++) {
				mailAddress_CC[i] = new InternetAddress(cclist[i]);
			}

			message.addRecipients(Message.RecipientType.TO, mailAddress_TO);
			message.addRecipients(Message.RecipientType.CC, mailAddress_CC);

			SimpleDateFormat sd = new SimpleDateFormat("MM-dd-yy");
			message.setSubject(prop.getProperty("subject") + " " + sd.format(new Date()));

			BodyPart messageBodyPart = new MimeBodyPart();
			String body = "<html><body>Hi Team,<br><br> Please find the Automation execution report <a href="
					+ ExtentReportPath + ">here</a> <br><br>Thanks&Regards,<br>Automation Team</body></html>";
			messageBodyPart.setContent(body, "text/html");

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);

			message.setContent(multipart);

			// Send message
			Transport.send(message);
			System.out.println("Email Sent...");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

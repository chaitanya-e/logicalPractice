package gbs.api.test.definitionSteps.common;

import cucumber.api.java.en.Then;
import gbs.api.test.common.CommonActions;
import gbs.api.test.verify.GenericRestVerify;
import net.thucydides.core.annotations.Steps;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class ResponseDefinitions {

    @Steps
    private GenericRestVerify genericRestVerify;

    @Steps
    private CommonActions commonActions;

    @Then("^I verify the status code (.*) for response$")
    public void iVerifyTheStatusCodeForResponse(int statusCode) {
        genericRestVerify.checkResponseCodeIs(commonActions.getResponseFromTestSession(), statusCode);
    }

    @Then("^I retrieve value of field (.*) from response pojo (.*) and store to SessionKey (.*)$")
    public void iGetValuesInResponse(String fieldName, String pojoFileName, String sessionKey) {
        Object value = genericRestVerify.getValueForEntity(
                commonActions.getResponseFromTestSession(), pojoFileName, fieldName);
        commonActions.rememberValueToSession(value, sessionKey);
    }

    @Then("^I verify field values for the response pojo (.*)$")
    public void iVerifyValuesInResponse(String pojoFileName, List<Map<String, String>> requestValues) {
        requestValues.forEach(requestVal -> genericRestVerify.checkValuesInFieldsForEntity(commonActions.getResponseFromTestSession(), pojoFileName, requestVal));
    }

    @Then("^I verify the size (.*) of list (.*) for the pojo (.*)$")
    public void iVerifyTheSizeOfListForThePojo(int expectedSize, String listFieldName, String pojoName) {
        genericRestVerify.checkSizeOfList(commonActions.getResponseFromTestSession(), pojoName, listFieldName, expectedSize);
    }

    @Then("^I verify the fields for the innerListEntity (.*) for innerPojo (.*) in (.*)$")
    public void iVerifyTheFieldsForTheInnerEntityForInnerPojoInPojo(String listFieldName, String innerPojoName,
                                                                    String pojoName,
                                                                    List<Map<String, String>> expectedValues) {
        genericRestVerify.checkResponseValuesInList(commonActions.getResponseFromTestSession(), pojoName,
                listFieldName, expectedValues);
    }
    @Then("^I verify response key$")
    public void iVerifyResponseKeys(List<Map<String, String>> responseValues) {
        genericRestVerify.verifyResponseKeyList(commonActions.getResponseFromTestSession(), Arrays.asList(responseValues.get(0).get("keys").toString().split(",")));
    }
}

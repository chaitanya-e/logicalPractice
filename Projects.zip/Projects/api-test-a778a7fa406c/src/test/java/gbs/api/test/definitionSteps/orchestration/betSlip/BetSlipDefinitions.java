package gbs.api.test.definitionSteps.orchestration.betSlip;

import cucumber.api.java.en.Given;
import gbs.api.test.steps.orchestration.betSlip.BetSlipSteps;
import gbs.api.test.utils.TestDataReader;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

public class BetSlipDefinitions {

    @Steps
    private BetSlipSteps betSlipSteps;

    @Given("^I get the betSlip for the betType (.*) and betId from testData (.*)$")
    public void iGetTheBetSlipForTheBetTypeAndBetIdFromTestData(String betType, String fileName,
                                                                List<Map<String, String>> requestValues) {
        String betId = TestDataReader.getFieldValueFromTestDataJson(betType.trim(), fileName);
        betSlipSteps.getBetSlipGetRequest(betId, requestValues);
    }

    @Given("^I payout betSlip settled amount for the betType (.*) and betId from testData (.*)$")
    public void iPayoutBetSlipSettledAmountForTheBetTypeAndBetIdFromTestData(String betType, String fileName,
                                                                   List<Map<String, String>> requestValues) {
        String betId = TestDataReader.getFieldValueFromTestDataJson(betType.trim(), fileName);
        betSlipSteps.payoutBetSlipPostRequest(betId, requestValues);
    }
}

package gbs.api.test.definitionSteps.inventory.customerAccount;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import gbs.api.test.common.CommonActions;
import gbs.api.test.steps.inventory.customerAccount.CustomerAccountSteps;
import gbs.api.test.verify.GenericRestVerify;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

public class CustomerAccountDefinitions {

    @Steps
    private CustomerAccountSteps customerAccountSteps;
    @Steps
    private GenericRestVerify genericRestVerify;
    @Steps
    private CommonActions commonActions;

    @Given("^I create a new customer account$")
    @When("^I create a existing customer account$")
    public void iCreateNewCustomerAccount(List<Map<String, String>> requestValues) {
        customerAccountSteps.addCustomerAccountPostRequest(requestValues);
    }

    @Given("^I retrieve the details of all existing customer account$")
    public void iRetrieveCustomerAccountDetails() {
        customerAccountSteps.getCustomerAccountByAllGetRequest();
    }

    @Given("^I retrieve the details of existing customer account by brand name$")
    public void iRetrieveCustomerAccountDetailsByBrandName(List<Map<String, String>> requestValues) {
        customerAccountSteps.getCustomerAccountByBrandGetRequest(requestValues);
    }

    @Given("^I retrieve the details of existing customer account by brand name, terminal id and shop id$")
    public void iRetrieveCustomerAccountDetailsByBrandTerminalAndShopID(List<Map<String, String>> requestValues) {
        customerAccountSteps.getCustomerAccountByBrandTerminalAndShopIdGetRequest(requestValues);
    }

    @Given("^I retrieve the details of existing customer account by brand name and shop id$")
    public void iRetrieveCustomerAccountDetailsByBrandNameAndShopID(List<Map<String, String>> requestValues) {
        customerAccountSteps.getCustomerAccountByBrandAndShopIdGetRequest(requestValues);
    }

    @Given("^I update customer account$")
    @When("^I update the existing customer with no changes$")
    public void iRetrieveCustomerAccountDetails(List<Map<String, String>> requestValues) {
        customerAccountSteps.getCustomerAccountPutRequest(requestValues);
    }

    @Given("^I delete the customer account$")
    public void iDeleteCustomerAccount(List<Map<String, String>> requestValues) {
        customerAccountSteps.deleteCustomerAccountDeleteRequest(requestValues);
    }
}


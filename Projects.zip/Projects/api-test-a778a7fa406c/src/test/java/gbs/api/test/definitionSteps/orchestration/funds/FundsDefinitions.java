package gbs.api.test.definitionSteps.orchestration.funds;

import cucumber.api.java.en.Given;
import gbs.api.test.common.CommonActions;
import gbs.api.test.steps.orchestration.valueTicket.ValueTicketSteps;
import gbs.api.test.utils.SessionKeys;
import gbs.api.test.verify.GenericRestVerify;
import net.thucydides.core.annotations.Steps;
import gbs.api.test.steps.orchestration.funds.FundSteps;

import java.util.List;
import java.util.Map;


public class FundsDefinitions {

    @Steps
    private FundSteps fundSteps;

    @Steps
    private ValueTicketSteps valueTicketSteps;

    @Steps
    private SessionKeys sessionKeys;

    @Steps
    private GenericRestVerify genericRestVerify;

    @Steps
    private CommonActions commonActions;

    private int terminalAmount;

    @Given("^I retrieve terminal details$")
    public void iRetrieveExistingAccount(List<Map<String, String>> requestValues) {
        fundSteps.getFundsGetRequest(requestValues);
    }

    @Given("^I add an amount to the terminal$")
    public void iAddAmountToTerminal(List<Map<String, String>> requestValues) {
        fundSteps.addAmtToTerminalPostRequest(requestValues);
    }

    @Given("^I Generate the valueTicket and verify status code (.*) for cashUp$")
    public void iGenerateValueTicket(int statusCode, List<Map<String, String>> requestValues) {
        terminalAmount = sessionKeys.getData(SessionKeys.DataKeys.TERMINAL_BALANCE);
        if (terminalAmount != 0) {
            valueTicketSteps.PostValueTicketPostRequest(requestValues);
            genericRestVerify.checkResponseCodeIs(commonActions.getResponseFromTestSession(), statusCode);
        }
    }

    @Given("^I perform cashUp for terminal$")
    public void iPerformCashUp(List<Map<String, String>> requestValues) {
        fundSteps.performCashUpToTerminalPostRequest(requestValues);
    }

}

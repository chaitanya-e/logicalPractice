package gbs.api.test.definitionSteps.common;

import cucumber.api.java.en.Then;
import gbs.api.test.common.CommonActions;
import gbs.api.test.utils.TestDataReader;
import net.thucydides.core.annotations.Steps;

public class TestDataDefinitions {

    @Steps
    private CommonActions commonActions;

    @Then("^I get the field (.*) from the testData json file (.*) and store to SessionKey (.*)$")
    public void iGetTheFieldFromTheTestDataJsonFileAndStoreToSessionKey(String fieldName, String fileName,
                                                                        String sessionKey) {
        String data = TestDataReader.getFieldValueFromTestDataJson(fieldName, fileName);
        commonActions.rememberValueToSession(data, sessionKey);
    }
}

package gbs.api.test.definitionSteps.orchestration.reports;

import cucumber.api.java.en.Given;
import gbs.api.test.steps.orchestration.reports.ReportsSteps;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

public class ReportsDefinitions {

    @Steps
    private ReportsSteps reportsSteps;

    @Given("^I verify details of reports$")
    public void iRetrieveReports(List<Map<String, String>> requestValues) {
        reportsSteps.getReportsGetRequest(requestValues);
    }
}

package gbs.api.test.definitionSteps.orchestration.valueTicket;

import cucumber.api.java.en.Given;
import gbs.api.test.steps.orchestration.valueTicket.ValueTicketSteps;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

public class ValueTicketDefinitions {
    @Steps
    private ValueTicketSteps valueTicketSteps;

    @Given("^I retrieve the details of all valueTickets$")
    public void iGetAllValueTickets(List<Map<String, String>> requestValues) {
        valueTicketSteps.getValueTicketGetRequest(requestValues);
    }

    @Given("^I retrieve the details of valueTicket by Id$")
    public void iGetValueTicketById(List<Map<String, String>> requestValues) {
        valueTicketSteps.getValueTicketByIdGetRequest(requestValues);
    }

    @Given("^I Generate the valueTicket$")
    public void iGenerateValueTicket(List<Map<String, String>> requestValues) {
        valueTicketSteps.PostValueTicketPostRequest(requestValues);
    }

    @Given("^I Generate the valueTicket with invalid amount$")
    public void iGenerateVTWithInvalidAmount(List<Map<String, String>> requestValues) {
        valueTicketSteps.PostVTInvalidAmountPostRequest(requestValues);
    }

    @Given("^I Payout the valueTicket$")
    public void iPayoutValueTicket(List<Map<String, String>> requestValues) {
        valueTicketSteps.PayoutVTPostRequest(requestValues);
    }

    @Given("^I Lock the valueTicket$")
    public void iLockValueTicket(List<Map<String, String>> requestValues) {
        valueTicketSteps.LockVTPutRequest(requestValues);
    }

    @Given("^I Lock the valueTicket with invalid VT Id$")
    public void iLockVTWithInvalidId(List<Map<String, String>> requestValues) {
        valueTicketSteps.LockVTPutRequestInvalidId(requestValues);
    }

    @Given("^I UnLock the valueTicket$")
    public void iUnLockValueTicket(List<Map<String, String>> requestValues) {
        valueTicketSteps.UnLockVTPutRequest(requestValues);
    }

}

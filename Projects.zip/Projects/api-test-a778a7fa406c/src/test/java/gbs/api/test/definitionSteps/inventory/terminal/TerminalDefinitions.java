package gbs.api.test.definitionSteps.inventory.terminal;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import gbs.api.test.steps.inventory.terminal.TerminalSteps;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

public class TerminalDefinitions {
    @Steps
    private TerminalSteps terminalSteps;

    @Given("^I create the terminal$")
    public void iCreateTheTerminal(List<Map<String, String>> requestValues) {
        terminalSteps.addTerminalPostRequest(requestValues);
    }

    @When("^I update the terminal$")
    public void iUpdateTheTerminal(List<Map<String, String>> requestValues) {
        terminalSteps.modifyTerminalPutRequest(requestValues);
    }

    @When("^I update the terminal with status$")
    public void iUpdateTheTerminalWithStatus(List<Map<String, String>> requestValues) {
        terminalSteps.modifyTerminalWithStatusPutRequest(requestValues);
    }

    @When("^I delete the terminal$")
    public void iDeleteTheTerminal(List<Map<String, String>> requestValues) {
        terminalSteps.deleteTerminalDeleteRequest(requestValues);
    }

    @When("^I get all terminals for the given brand$")
    public void iGetAllTerminalsForTheGivenBrand(List<Map<String, String>> requestValues) {
        terminalSteps.getAllTerminalsWithBrand(requestValues);
    }

    @When("^I get all terminals for the given mac id$")
    public void iGetAllTerminalsForTheGivenMacId(List<Map<String, String>> requestValues) {
        terminalSteps.getAllTerminalsWithMacId(requestValues);
    }

    @When("^I get all terminals for the given shop id$")
    public void iGetAllTerminalsForTheGivenShopId(List<Map<String, String>> requestValues) {
        terminalSteps.getAllTerminalsWithShopId(requestValues);
    }

    @Given("^I get terminal details for the given shop terminal and brand$")
    public void iGetAllTerminalsForTheGivenShopTerminalAndBrand(List<Map<String, String>> requestValues) {
        terminalSteps.getAllTerminalsWithShopTerminalIdAndBrand(requestValues);
    }

    @When("^I get all terminals with status$")
    public void iGetAllTerminalsForTheGivenStatus(List<Map<String, String>> requestValues) {
        terminalSteps.getAllTerminalsWithStatus(requestValues);
    }

    @When("^I post the terminal status request$")
    public void iPostTheTerminalStatusRequest(List<Map<String, String>> requestValues) {
        terminalSteps.terminalStatusPostRequest(requestValues);
    }
}

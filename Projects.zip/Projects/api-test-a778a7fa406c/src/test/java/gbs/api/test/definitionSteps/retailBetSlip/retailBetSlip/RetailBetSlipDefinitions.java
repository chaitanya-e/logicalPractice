package gbs.api.test.definitionSteps.retailBetSlip.retailBetSlip;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import gbs.api.test.common.CommonActions;
import gbs.api.test.steps.retailBetSlip.retailBetSlip.RetailBetSlipSteps;
import gbs.api.test.utils.TestDataReader;
import gbs.api.test.verify.GenericRestVerify;
import net.thucydides.core.annotations.Steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RetailBetSlipDefinitions {

    @Steps
    private GenericRestVerify genericRestVerify;

    @Steps
    private CommonActions commonActions;

    @Steps
    private RetailBetSlipSteps retailBetSlipSteps;

    @Given("^I retrieve the details of Bet Receipts with page number$")
    public void iGetRBSWithPageNumber(List<Map<String, String>> requestValues) {
        retailBetSlipSteps.getRBSWithPageGetRequest(requestValues);
    }

    @Given("^I retrieve the details of Bet Receipts for (.*) betType from testData (.*)$")
    public void iGetRBS(String betType, String fileName, List<Map<String, String>> requestValues) {
        String betId = TestDataReader.getFieldValueFromTestDataJson(betType.trim(), fileName);
        retailBetSlipSteps.getRBSGetRequest(betId, requestValues);
    }
    @Given("I update the Bet Receipts for (.*) betType from testData (.*)")
    public void iUpdateRBS(String betType, String fileName, List<Map<String, String>> requestValues) {
        String betId = TestDataReader.getFieldValueFromTestDataJson(betType.trim(), fileName);
        retailBetSlipSteps.updateRBSPutRequest(betId, requestValues);
    }
    @And("^I verify the (.*) of (.*) betType from testData (.*) in response pojo (.*)$")
    public void iVerifyTheReceiptIdInResponseForResponse(String fieldName, String betType, String fileName, String pojoFileName) {
        String betId = TestDataReader.getFieldValueFromTestDataJson(betType.trim(), fileName);
        List<Map<String, String>> arrayList = new ArrayList<>();
        Map<String, String> map = new HashMap<>();
        map.put(fieldName, betId);
        arrayList.add(map);
        arrayList.forEach(requestVal -> genericRestVerify.checkValuesInFieldsForEntity(commonActions.getResponseFromTestSession(), pojoFileName, requestVal));
    }
}

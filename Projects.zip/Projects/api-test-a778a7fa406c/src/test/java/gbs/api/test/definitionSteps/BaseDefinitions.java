package gbs.api.test.definitionSteps;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import gbs.api.test.steps.inventory.terminal.TerminalSteps;
import gbs.api.test.utils.TestRailUpdate;
import net.thucydides.core.annotations.Steps;
import gbs.api.test.utils.Configuration;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class BaseDefinitions {

    @Steps
    private TestRailUpdate testrailUpdate;

    @Steps
    private TerminalSteps terminalSteps;

//    @Steps
//    private SessionKeys sessionKeys;

//    @After
//    public void deleteAutomationCreatedShop(Scenario scenario) {
//        String newShops = sessionKeys.getData(SessionKeys.DataKeys.NEW_AUTOMATION_SHOP);
//        if (newShops != null) {
//            String[] newShopsArray = newShops.split(",");
//            for (String newShop : newShopsArray) {
//                Map<String, String> deletePayloadMap = new HashMap<>();
//                deletePayloadMap.put("brandName", "Valid");
//                deletePayloadMap.put("shopId", newShop);
//                deletePayloadMap.put("cascade", "true");
//                List<Map<String, String>> deletePayloadMapsList = new ArrayList<>();
//                deletePayloadMapsList.add(deletePayloadMap);
//                shopSteps.deleteShopDeleteRequest(deletePayloadMapsList);
//            }
//        }
//    }

    @After
    public void deleteAutomationCreatedTerminal(Scenario scenario) {
        if (scenario.isFailed()) {
            String newTerminal = Configuration.get("newlyCreatedTerminalId");
            Map<String, String> deletePayloadMap = new HashMap<>();
            List<Map<String, String>> deletePayloadMapsList = new ArrayList<>();
            deletePayloadMap.put("brandName", "Valid");
            deletePayloadMap.put("shopId", "Valid");
            deletePayloadMap.put("cascade", "true");
            deletePayloadMap.put("terminalId", newTerminal);
            deletePayloadMapsList.add(deletePayloadMap);
            terminalSteps.deleteTerminalDeleteRequest(deletePayloadMapsList);
        }
    }

    @After
    public void updateResultInTestRail(Scenario scenario) {
        if (Configuration.get("testRail.update.status").equals("true")) {
            testrailUpdate.updateResultInTestRail(scenario);
        }
    }
}

package gbs.api.test.definitionSteps.omnia.cashManager.EODCashup;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gbs.api.test.common.CommonActions;

import gbs.api.test.steps.omnia.cashManager.EODCashup.EODCashUpSteps;
import gbs.api.test.steps.omnia.cashManager.cashClearance.CashClearanceSteps;
import net.thucydides.core.annotations.Steps;

import java.util.*;

public class EODCashUpDefinitions {

    @Steps
    private CommonActions commonActions;

    @Steps
    private EODCashUpSteps eodCashUpSteps;

    @Steps
    private CashClearanceSteps cashClearanceSteps;

    @Given("^I add an amount to all the terminals of shop$")
    public void iAddAnAmountToTheTerminalForEodCashUp(List<Map<String, String>> requestValues) {
       eodCashUpSteps.addAmountToAllTerminalsInShop(requestValues);
    }
    @Given("^I generate VT for all the terminals in shop and retrieve value of field (.*) from response pojo (.*) and store to SessionKey (.*)$")
    public void iRetrieveTerminalDetailsForEodCashUp(String fieldName, String pojoFileName, String sessionKey, List<Map<String, String>> requestValues) {
        eodCashUpSteps.generateValueTicketForAllTerminalsInShop(fieldName, pojoFileName, sessionKey, requestValues);
    }
    @When("^I perform cash clearance for all the terminals in shop$")
    public void iPerformCashClearanceForTheTerminalForEodCashUp(List<Map<String, String>> requestValues) {
        eodCashUpSteps.performCashClearanceForAllTerminalsInShop(requestValues);
    }
    @When("^I perform end of the day report for eodCashup endPoint$")
    public void iPerformEndOfTheDayReportForEodCashupEndPoint(List<Map<String, String>> requestValues) {
        eodCashUpSteps.postEODCashUpPostRequest(requestValues);
    }
    @When("^I retrieve the details of all EOD cash up$")
    public void iRetrieveTheDetailsOfEODCashUp(List<Map<String, String>> requestValues) {
        eodCashUpSteps.getEODCashUpGetRequest(requestValues);
    }
    @Then("^I verify the totalCash for innerPojo (.*) in (.*) for EOD cashUp endPoint$")
    public void iVerifyTotalCashInResponse(String innerPojoName, String pojoName) {
        eodCashUpSteps.verifyTotalCash("totalCash", innerPojoName, pojoName);
    }

    @When("^I perform cash clearance for the terminal and retrieve details from list (.*) from pojo (.*) and store details to sessionKey (.*)$")
    public void iPerformCashClearanceAndStoreDetailsToSessionKey(String listName, String pojoName, String sessionKey, List<Map<String, String>> requestValues) {
        eodCashUpSteps.performCashClearanceAndStoreDetailsToSessionKey(listName, pojoName, sessionKey, requestValues);
    }
}

package gbs.api.test.definitionSteps.displayChangesForInventoryServices;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gbs.api.test.DataFactory.displayChangesForInventoryServices.DisplayChangesForInventoryServicesDataFactory;
import gbs.api.test.common.CommonActions;
import gbs.api.test.steps.displayChangesForInventoryServices.DisplayChangesForInventoryServicesSteps;
import gbs.api.test.verify.GenericRestVerify;
import net.thucydides.core.annotations.Steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DisplayChangesForInventoryServicesDefinitions {

    @Steps
    private DisplayChangesForInventoryServicesSteps displayChangesForInventoryServicesSteps;

    @Steps
    private GenericRestVerify genericRestVerify;

    @Steps
    private CommonActions commonActions;

    @Steps
    private DisplayChangesForInventoryServicesDataFactory displayChangesForInventoryServicesDataFactory;

    @When("I add a screenGroup in the database")
    public void iCreateScreenGroup(List<Map<String, String>> requestValues) {
        displayChangesForInventoryServicesSteps.addScreenGroupPostRequest(requestValues.get(0));
    }

    @When("I add a TV Decoder")
    public void iCreateTVDecoder(List<Map<String, String>> requestValues) {
        displayChangesForInventoryServicesSteps.addTVDecoderPostRequest(requestValues.get(0));
    }

    @When("I a add devices")
    public void iAddDevice(List<Map<String, String>> requestValues) {
        displayChangesForInventoryServicesSteps.addDevicePostRequest(requestValues.get(0));
    }

    @When("I add a device to TV Decoder Mapping")
    public void iAddDeviceToDecoderMapping(List<Map<String, String>> requestValues) {
        displayChangesForInventoryServicesSteps.addDeviceToTVDecoderMappingPostRequest(requestValues.get(0));
    }

    @When("I get list of devices of display equipment with given input tvDecoderName ID and IpAdress")
    public void iGetListOfDevicesOfDisplayEquipmentWithValidInput(List<Map<String, String>> requestValues) {
        displayChangesForInventoryServicesSteps.getTVDecoderListGetRequest(requestValues.get(0));
    }

    @When("I retrieves all screen groups for the specific shop")
    public void iGetListOfDevicesOfDisplayEquipmentWithValidShopIdInput(List<Map<String, String>> requestValues) {
        displayChangesForInventoryServicesSteps.getScreenGroupListGetRequest(requestValues.get(0));
    }

    @When("I delete a screen group from inventory DB")
    public void iDeleteAScreenGroupFromInventoryDB(List<Map<String, String>> requestValues) {
        displayChangesForInventoryServicesSteps.deleteScreenGroupDeleteRequest(requestValues.get(0));
    }

    @When("I delete a device from inventory DB")
    public void iDeleteADeviceFromInventoryDB(List<Map<String, String>> requestValues) {
        displayChangesForInventoryServicesSteps.deleteDeviceDeleteRequest(requestValues.get(0));
    }

    @When("I remove a TV decoder in a shop from inventory DB")
    public void iRemoveATVDecoderInAShopFromInventoryDB(List<Map<String, String>> requestValues) {
        displayChangesForInventoryServicesSteps.removeTVDecoderInShopFromDBDeleteRequest(requestValues.get(0));
    }

    @Then("I verify response value with the search key (.*) from tv decoder list")
    public void iVerifyResponseValueUsingSearchKey(String searchKey, List<Map<String, String>> responseValue) {
        Map<String, String> map = new HashMap<>(responseValue.get(0));
        map.put(searchKey, displayChangesForInventoryServicesDataFactory.generateTVDecoderID(responseValue.get(0)));
        map.put("brandName", commonActions.getBrandName(responseValue.get(0).get("brandName")));
        map.put("shopId", commonActions.getShopID(responseValue.get(0).get("shopId")));
        List<Map<String, String>> newResponseValue = new ArrayList<>();
        newResponseValue.add(map);
        genericRestVerify.verifyResponseValues(commonActions.getResponseFromTestSession(), newResponseValue, searchKey);
    }
}

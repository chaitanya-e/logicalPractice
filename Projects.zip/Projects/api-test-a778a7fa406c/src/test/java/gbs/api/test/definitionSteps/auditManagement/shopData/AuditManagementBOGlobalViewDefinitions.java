package gbs.api.test.definitionSteps.auditManagement.shopData;

import cucumber.api.java.en.Given;
import gbs.api.test.steps.auditManagement.shopData.AuditManagementBOGlobalViewSteps;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

public class AuditManagementBOGlobalViewDefinitions {
    @Steps
    private AuditManagementBOGlobalViewSteps auditManagementBOGlobalViewSteps;

    @Given("^I get the bo global view data with filtered values$")
    public void iGetFilteredBOGlobalViewData(List<Map<String, String>> requestValues) {
        auditManagementBOGlobalViewSteps.getFilteredBOGlobalViewData(requestValues);
    }

    @Given("^I get the bo global view type head search data with filtered values$")
    public void iGetFilteredBOGlobalViewTypeHeadSearchData(List<Map<String, String>> requestValues) {
        auditManagementBOGlobalViewSteps.getFilteredBOGlobalViewTypeHeadSearchData(requestValues);
    }

    @Given("^I Validate the Filtered Data$")
    public void iVerifyFilteredData(List<Map<String, String>> requestValues) {
        auditManagementBOGlobalViewSteps.verifyFilteredData(requestValues.get(0));
    }


}

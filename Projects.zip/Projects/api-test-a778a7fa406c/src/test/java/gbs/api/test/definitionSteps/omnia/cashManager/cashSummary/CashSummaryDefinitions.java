package gbs.api.test.definitionSteps.omnia.cashManager.cashSummary;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import gbs.api.test.common.CommonActions;
import gbs.api.test.steps.omnia.cashManager.cashSummary.CashSummarySteps;
import gbs.api.test.utils.SessionKeys;
import gbs.api.test.verify.GenericRestVerify;
import io.restassured.response.Response;
import net.thucydides.core.annotations.Steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CashSummaryDefinitions {
    @Steps
    CommonActions commonActions;

    @Steps
    private CashSummarySteps cashSummarySteps;

    @Steps
    private GenericRestVerify genericRestVerify;

    @Steps
    private SessionKeys sessionKeys;


    @Given("^I retrieve the details of cashSummary endPoint$")
    public void iRetrieveTheDetailsOfTerminalOfTheShop(List<Map<String, String>> requestValues) {
        cashSummarySteps.getCashSummaryDetailsGetRequest(requestValues);
    }

    @And("^I verify the terminalId in response$")
    public void iVerifyTheTerminalIdInResponseForResponse(List<Map<String, String>> responseValues) {
        List<Map<String, String>> arrayList = new ArrayList<>();
        Map<String, String> map = new HashMap<>();
        map.put("terminalId", commonActions.getTerminalID(responseValues.get(0).get("terminalId")));
        arrayList.add(map);
        genericRestVerify.verifyResponseValuesInList(commonActions.getResponseFromTestSession(), arrayList);
    }

    @And("^I retrieve list of terminalId for inner pojo (.*) in (.*) and store to SessionKey (.*)$")
    public void iRetrieveListValueOfFieldTerminalIdFromResponse(String listFieldName, String pojoFileName, String sessionKey) {
        List<Object> value = genericRestVerify.getValuesInListForEntity(commonActions.getResponseFromTestSession(), pojoFileName, listFieldName, "terminalId");
        commonActions.rememberValueToSession(value, sessionKey);
    }

    @And("^I verify list of terminalId in response$")
    public void iVerifyListOfFieldInResponseForResponse() {
        Response response = commonActions.getResponseFromTestSession();
        List<String> expTerminalIDs = sessionKeys.getData(SessionKeys.DataKeys.TERMINAL_IDS);
        List<String> actualTerminalID = new ArrayList<>();
        genericRestVerify.getResponseValuesAsListMap(response).forEach(actualMap -> {
            actualTerminalID.add(actualMap.get("terminalId"));
        });
       genericRestVerify.verifyListValues(expTerminalIDs, actualTerminalID);
    }

}

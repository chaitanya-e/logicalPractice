package gbs.api.test.definitionSteps.auditIngest;

import cucumber.api.java.en.Given;
import gbs.api.test.steps.auditIngest.AuditIngestSteps;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

public class AuditIngestDefinitions {

    @Steps
    private AuditIngestSteps auditIngestSteps;

    @Given("^I update the audit data$")
    public void iUpdateAuditData(List<Map<String, String>> requestValues) {
        auditIngestSteps.iUpdateAuditData(requestValues);
    }

    @Given("^I insert the audit data$")
    public void iInsertAuditData(List<Map<String, String>> requestValues) {
        auditIngestSteps.iInsertAuditData(requestValues);
    }

}



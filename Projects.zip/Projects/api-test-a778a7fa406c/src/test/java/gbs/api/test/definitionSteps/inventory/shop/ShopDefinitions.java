package gbs.api.test.definitionSteps.inventory.shop;
//
//import java.util.List;
//import java.util.Map;
//
//import cucumber.api.java.en.Given;
//import gbs.api.test.steps.inventory.shop.ShopSteps;
//import net.thucydides.core.annotations.Steps;
//
//public class ShopDefinitions  {
//    @Steps
//    private ShopSteps shopSteps;
//
//    @Given("^I create a new shop$")
//    public void iCreateANewShop(List<Map<String, String>> requestValues) {
//        shopSteps.addShopPostRequest(requestValues);
//    }
//
//    @Given("^I modify an existing shop$")
//    public void iCreateAnExistingShop(List<Map<String, String>> requestValues) {
//        shopSteps.modifyShopPutRequest(requestValues);
//    }
//
//    @Given("^I retrieve the details of existing shop by shop ID$")
//    public void iRetrieveAnExistingShopById(List<Map<String, String>> requestValues) {
//        shopSteps.getShopByIdGetRequest(requestValues);
//    }
//
//    @Given("^I retrieve the details of existing shop by brandName$")
//    public void iRetrieveAnExistingShopByBrand(List<Map<String, String>> requestValues) {
//        shopSteps.getShopByBrandGetRequest(requestValues);
//    }
//
//    @Given("^I retrieve the details of existing shop by Shops Endpoint$")
//    public void iRetrieveAnExistingShopByShops() {
//        shopSteps.getShopByShopsGetRequest();
//    }
//
////    @Given("^I Delete the shop$")
////    public void iDeleteTheShop(List<Map<String, String>> requestValues) {
////        shopSteps.deleteShopDeleteRequest(requestValues);
////    }
//
//}

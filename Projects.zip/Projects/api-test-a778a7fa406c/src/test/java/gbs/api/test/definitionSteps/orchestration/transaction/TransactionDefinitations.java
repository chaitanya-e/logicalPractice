package gbs.api.test.definitionSteps.orchestration.transaction;

import cucumber.api.java.en.Given;
import gbs.api.test.steps.orchestration.transaction.TransactionsSteps;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

public class TransactionDefinitations {

    @Steps
    private TransactionsSteps transactionsSteps;

    @Given("^I retrieve the details of transaction$")
    public void iRetrieveExistingExistingAccountSorceAsBO(List<Map<String, String>> requestValues) {
        transactionsSteps.getTransactionsGetRequest(requestValues);
    }
}

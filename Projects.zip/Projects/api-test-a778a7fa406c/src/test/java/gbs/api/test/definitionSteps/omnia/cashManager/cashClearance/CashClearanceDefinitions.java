package gbs.api.test.definitionSteps.omnia.cashManager.cashClearance;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import gbs.api.test.common.CommonActions;
import gbs.api.test.steps.omnia.cashManager.cashClearance.CashClearanceSteps;
import gbs.api.test.utils.SessionKeys;
import gbs.api.test.verify.GenericRestVerify;
import net.thucydides.core.annotations.Steps;

import java.util.*;
import java.util.stream.Collectors;

public class CashClearanceDefinitions {

    @Steps
    private CashClearanceSteps cashClearanceSteps;

    @Steps
    private CommonActions commonActions;

    @Steps
    private GenericRestVerify genericRestVerify;

    @Steps
    private SessionKeys sessionKeys;


    @When("^I retrieve the details for cashClearance endPoint$")
    public void iRetrieveDetailsOfCashClearance(List<Map<String, String>> requestValues) {
        cashClearanceSteps.getCashClearanceDetailsGetRequest(requestValues);
    }

    @And("^I verify list of value fieldName (.*) for list (.*) in pojo (.*)$")
    public void iVerifyListOfValueFieldNameInCashClearanceResponse(String fieldName, String listFieldName, String pojoFileName) {
        cashClearanceSteps.verifyCashClearanceDatetime(commonActions.getResponseFromTestSession(), fieldName, listFieldName, pojoFileName);
    }

    @And("^I verify list of terminalIds for list (.*) in pojo (.*)$")
    public void iVerifyListOfFieldInCashClearance(String listFieldName, String pojoFileName) {
        List<Object> cashClearanceDatetimeList = genericRestVerify.getValuesInListForEntity(commonActions.getResponseFromTestSession(), pojoFileName, listFieldName, "terminalId");
        List<String> terminalIDs = sessionKeys.getData(SessionKeys.DataKeys.TERMINAL_IDS);
        List<String> actualTerminalID = cashClearanceDatetimeList.stream().map(object -> Objects.toString(object, null)).collect(Collectors.toList());
        genericRestVerify.verifyListValues(terminalIDs, actualTerminalID);
    }

    @And("^I verify field terminalId for list (.*) in pojo (.*)$")
    public void iVerifyFieldInCashClearance(String listFieldName, String pojoFileName, List<Map<String, String>> requestValues) {
       cashClearanceSteps.verifyTerminalId(commonActions.getResponseFromTestSession(), listFieldName, pojoFileName, requestValues);
    }

    @When("^I perform cash clearance for the terminal$")
    public void iPerformCashClearance(List<Map<String, String>> requestValues) {
        cashClearanceSteps.postCashClearancePostRequest(requestValues);
    }

    @When("^I perform cash clearance for the terminal for invalid values$")
    public void iPerformCashClearanceForInvalidValue(List<Map<String, String>> requestValues) {
        cashClearanceSteps.postCashClearancePostRequestNotesAndCoinsPassedFromFeature(requestValues);
    }

    @And("^I retrieve list of value fieldName (.*) for list (.*) in (.*) and store to SessionKey (.*)$")
    public void iRetrieveListValueOfFieldTerminalIdFromResponse(String fieldName, String listFieldName, String pojoFileName, String sessionKey) {
        List<Object> value = genericRestVerify.getValuesInListForEntity(commonActions.getResponseFromTestSession(), pojoFileName, listFieldName, fieldName);
        commonActions.rememberValueToSession(value, sessionKey);
    }
}

package gbs.api.test.definitionSteps.auditManagement.shopData;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import gbs.api.test.steps.auditManagement.shopData.AuditManagementShopSteps;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

public class AuditManagementShopDefinitions {

    @Steps
    private AuditManagementShopSteps auditManagementShopSteps;

    @Given("^I get the audit trail data with filtered values$")
    public void iGetFilteredAuditTrailData(List<Map<String, String>> requestValues) {
        auditManagementShopSteps.getFilteredAuditData(requestValues);
    }

    @Given("^I Create a API to provide pagination for Audit Trail filtered data$")
    public void iCreateFilteredAuditTrailData(List<Map<String, String>> requestValues) {
        auditManagementShopSteps.createFilteredAuditData(requestValues);
    }

    @And("^I verify list of values in response$")
    public void iVerifyListOfFieldInResponseForResponse(List<Map<String, String>> expectedValues) {
        auditManagementShopSteps.verifyListOfFieldInResponseForResponse(expectedValues);
    }
}

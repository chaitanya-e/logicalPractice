package gbs.api.test.response;

import com.google.common.collect.ImmutableList;
import gbs.api.test.response.auditIngest.AuditIngestLog;
import gbs.api.test.response.auditManagement.shopData.AuditLog;
import gbs.api.test.response.auditManagement.shopData.AuditManagementBOGlobalViewDataResponse;
import gbs.api.test.response.auditManagement.shopData.AuditManagementShopDataResponse;
import gbs.api.test.response.auditManagement.shopData.BOGlobalViewLog;
import gbs.api.test.response.inventory.terminal.InventoryTerminalResponse;
import gbs.api.test.response.inventory.terminal.TerminalLog;
import gbs.api.test.response.omnia.cashManager.EODCashup.EODCashUpResponse;
import gbs.api.test.response.omnia.cashManager.EODCashup.TerminalOverview;
import gbs.api.test.response.omnia.cashManager.cashClearance.CashClearanceEvents;
import gbs.api.test.response.omnia.cashManager.cashClearance.CashClearanceResponse;
import gbs.api.test.response.omnia.cashManager.cashManager.CashManagerResponse;
import gbs.api.test.response.orchestration.ValueTicket.ValueTicketResponse;
import gbs.api.test.response.orchestration.funds.FundsResponse;
import gbs.api.test.response.retailBetSlip.GetRBSDetailsResponse;
import gbs.api.test.response.testData.BetIds;

import java.util.ArrayList;
import java.util.List;

public class ResponsePojosDictionary {
    private Class<? extends ResponseEntity> clazz;

    static final List<ResponseEntity> POJOS = ImmutableList.of(
            new ResponseEntity("BetIds", BetIds.class),
            new ResponseEntity("GenericResponse", GenericResponse.class),
            new ResponseEntity("GetRBSDetailsResponse", GetRBSDetailsResponse.class),
            new ResponseEntity("Funds", FundsResponse.class),
            new ResponseEntity("ValueTicket", ValueTicketResponse.class),
            new ResponseEntity("AuditManagementShopDataResponse", AuditManagementShopDataResponse.class),
            new ResponseEntity("AuditLog", AuditLog .class),
            new ResponseEntity("TerminalLog", TerminalLog.class),
            new ResponseEntity("InventoryTerminalResponse", InventoryTerminalResponse.class),
            new ResponseEntity("CashClearanceLog", CashClearanceEvents.class),
            new ResponseEntity("CashClearanceResponse", CashClearanceResponse.class),
            new ResponseEntity("CashManagerResponse", CashManagerResponse.class),
            new ResponseEntity("EODCashUpResponse", EODCashUpResponse.class),
            new ResponseEntity("TerminalOverview", TerminalOverview.class),
            new ResponseEntity("AuditManagementBOGlobalViewDataResponse", AuditManagementBOGlobalViewDataResponse.class),
            new ResponseEntity("BOGlobalViewLog", BOGlobalViewLog.class),
            new ResponseEntity("AuditIngestLog", AuditIngestLog.class)

    );

    public static Class<? extends ResponseEntity> getPojoClass(final String pojoName) {
        List<Class<? extends ResponseEntity>> result = new ArrayList<>();
        for (ResponseEntity pojo : POJOS) {
            if (pojo.getPojoName().equals(pojoName)) {
                result.add(pojo.getPojoClassName());
            }
        }
        if (result.isEmpty()) {
            throw new RuntimeException("Pojo " + pojoName + " wasn't found in dictionary");
        }
        if (result.size() > 1) {
            throw new RuntimeException("Pojo " + pojoName + " was found in dictionary more then once");
        }
        return result.get(0);
    }
}

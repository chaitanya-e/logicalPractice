package gbs.api.test.steps.omnia.cashManager.EODCashup;

import gbs.api.test.common.CommonActions;
import gbs.api.test.response.ResponseEntity;
import gbs.api.test.response.ResponsePojosDictionary;
import gbs.api.test.steps.omnia.cashManager.cashClearance.CashClearanceSteps;
import gbs.api.test.steps.omnia.cashManager.cashSummary.CashSummarySteps;
import gbs.api.test.steps.orchestration.funds.FundSteps;
import gbs.api.test.steps.orchestration.valueTicket.ValueTicketSteps;
import gbs.api.test.utils.Configuration;
import gbs.api.test.utils.SessionKeys;
import gbs.api.test.verify.ComparableMap;
import gbs.api.test.verify.GenericRestVerify;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class EODCashUpSteps extends CommonActions {

    @Steps
    private CashSummarySteps cashSummarySteps;

    @Steps
    private CashClearanceSteps cashClearanceSteps;

    @Steps
    private ValueTicketSteps valueTicketSteps;

    @Steps
    private FundSteps fundSteps;

    @Steps
    private GenericRestVerify genericRestVerify;

    @Steps
    private SessionKeys sessionKeys;

    private String eodSource;
    public Map<String, String> EODCashUpHeaders(Map<String, String> requestValues) {
        Map<String, String> headersMap = new HashMap<String, String>();

        if (requestValues.containsKey("transactionID")) {
            headersMap.put("id", getRandomNumber(8));
        }

        if (requestValues.containsKey("eodSource")) {
            headersMap.put("source", requestValues.get("eodSource"));
        }
        if (requestValues.containsKey("userName")) {
            headersMap.put("userName", Configuration.get("userName"));
        }

        return headersMap;
    }

    public void postEODCashUpPostRequest(List<Map<String, String>> requestValues) {

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(setUserIdHeader(requestValues.get(0)))
                .headers(EODCashUpHeaders(requestValues.get(0)))
                .post(getApiUrl() + CASH_MANAGER + EOD_CASH_UP);
        storeResponseToTestSession(response);
    }

    public void getEODCashUpGetRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(EODCashUpHeaders(requestValues.get(0)))
                .get(getApiUrl() + CASH_MANAGER + EOD_CASH_UP);
        storeResponseToTestSession(response);
        eodSource = requestValues.get(0).get("eodSource");
    }

    public void addAmountToAllTerminalsInShop(List<Map<String, String>> requestValues) {
        List<String> terminalIDs = sessionKeys.getData(SessionKeys.DataKeys.TERMINAL_IDS);
        String shopID = getShopID(requestValues.get(0).get("shopId"));
        Map<String, String> map = new HashMap<>();
        map.put("errorCode", "null");
        Map<String, String> newMap;

        for (String terminalID : terminalIDs) {
            List<Map<String, String>> newRequestValues = new ArrayList<>();
            newMap = new HashMap<>(requestValues.get(0));
            newMap.put("terminalId", terminalID);
            newMap.put("accountName", generateAccountName(shopID, terminalID));
            newRequestValues.add(newMap);
            fundSteps.addAmtToTerminalPostRequest(newRequestValues);
            genericRestVerify.checkResponseCodeIs(getResponseFromTestSession(), 201);
            genericRestVerify.checkValuesInFieldsForEntity(getResponseFromTestSession(), "GenericResponse", map);
        }
    }

    public void generateValueTicketForAllTerminalsInShop(String fieldName, String pojoFileName, String sessionKey, List<Map<String, String>> requestValues) {
        List<String> terminalIDs = sessionKeys.getData(SessionKeys.DataKeys.TERMINAL_IDS);
        String shopID = getShopID(requestValues.get(0).get("shopId"));
        Map<String, String> newMap;
        Map<String, String> map = new HashMap<>();
        map.put("errorCode", "null");
        for (String terminalID : terminalIDs) {
            List<Map<String, String>> newRequestValues = new ArrayList<>();
            newMap = new HashMap<>(requestValues.get(0));
            newMap.put("terminalId", terminalID);
            newMap.put("accountName", generateAccountName(shopID, terminalID));
            newMap.put("source", "Backoffice");
            newRequestValues.add(newMap);

            //get total balance of terminal
            fundSteps.getFundsGetRequest(newRequestValues);
            genericRestVerify.checkResponseCodeIs(getResponseFromTestSession(), 200);
            Object value = genericRestVerify.getValueForEntity(getResponseFromTestSession(), pojoFileName, fieldName);
            rememberValueToSession(value, sessionKey);

            //generate value ticket
            newMap.put("source", "Terminal");
            valueTicketSteps.PostValueTicketPostRequest(newRequestValues);
            genericRestVerify.checkResponseCodeIs(getResponseFromTestSession(), 200);
            genericRestVerify.checkValuesInFieldsForEntity(getResponseFromTestSession(), "GenericResponse", map);
        }
    }
    public void performCashClearanceForAllTerminalsInShop(List<Map<String, String>> requestValues) {
        List<String> terminalIDs = sessionKeys.getData(SessionKeys.DataKeys.TERMINAL_IDS);
        Map<String, String> newMap;
        for (String terminalID : terminalIDs) {
            List<Map<String, String>> newRequestValues = new ArrayList<>();
            newMap = new HashMap<>(requestValues.get(0));
            newMap.put("terminalId", terminalID);
            newRequestValues.add(newMap);
            cashClearanceSteps.postCashClearancePostRequest(newRequestValues);
            genericRestVerify.checkResponseCodeIs(getResponseFromTestSession(), 200);
        }
    }
    public void verifyTotalCash(String fieldName, String innerPojoName, String pojoName) {
        List<Map<String, String>> expectedValues = sessionKeys.getData(SessionKeys.DataKeys.EOD_TOTAL_CASH);
        List<?> terminalTotalCash = genericRestVerify.getValuesInListForEntity(getResponseFromTestSession(), pojoName, innerPojoName, fieldName);
        Response response = getResponseFromTestSession();
        if ("GBS".equalsIgnoreCase(eodSource)) {
            genericRestVerify.checkResponseValuesInList(response, pojoName, innerPojoName, expectedValues);
        } else {
            terminalTotalCash.forEach(totalCash -> assertThat(totalCash, equalTo(String.valueOf(ZERO_NUM))));
        }
    }

    public void performCashClearanceAndStoreDetailsToSessionKey(String listName, String pojoName, String sessionKey, List<Map<String, String>> requestValues) {
        Integer expectedAmountCoins = 0;
        Integer expectedAmountNotes = 0;
        Integer totalCash;

        String terminalID = getTerminalID(requestValues.get(0).get("terminalId"));
        getEODCashUpGetRequest(requestValues);

        //get eod cashUp details
        genericRestVerify.checkResponseCodeIs(getResponseFromTestSession(), 200);
        Class<? extends ResponseEntity> clazzName = ResponsePojosDictionary.getPojoClass(pojoName);
        List<?> actualListEntity = genericRestVerify.getResponseEntityAsJsonObject(getResponseFromTestSession(), clazzName).getList(listName);
        List<ComparableMap> comparableMaps = genericRestVerify.getComparableMapsFromEntities(actualListEntity);

        //get terminal details
        cashSummarySteps.getCashSummaryDetailsGetRequest(requestValues);
        genericRestVerify.checkResponseCodeIs(getResponseFromTestSession(), 200);
        List<Map<String, String>> responseListMap = genericRestVerify.getResponseValuesAsListMap(getResponseFromTestSession());
        List<Map<String, String>> newArrayList = new ArrayList<>();
        for (ComparableMap actualMap : comparableMaps) {
            Map<String, String> newHashMap = new HashMap<>();
            totalCash = 0;
                if (actualMap.get("terminalId").equalsIgnoreCase(terminalID)) {
                    expectedAmountCoins = Integer.valueOf(responseListMap.get(0).get("totalCoins"));
                    expectedAmountNotes = Integer.valueOf(responseListMap.get(0).get("totalNotes"));
                    totalCash = totalCash + expectedAmountCoins + expectedAmountNotes;
                }
            newHashMap.put("terminalId", actualMap.get("terminalId"));
            newHashMap.put("totalCash", String.valueOf(totalCash));
            newArrayList.add(newHashMap);
        }
        rememberValueToSession(newArrayList, sessionKey);
        cashClearanceSteps.postCashClearancePostRequest(requestValues);
    }
}

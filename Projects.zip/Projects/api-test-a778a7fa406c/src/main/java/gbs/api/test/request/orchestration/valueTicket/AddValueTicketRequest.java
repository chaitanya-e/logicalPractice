package gbs.api.test.request.orchestration.valueTicket;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)

public class AddValueTicketRequest {

    private int amount;
    private String anonymousPlayerSessionId;
    private String currency;
    private String description;
    private String reqRefId;
    private long transactionDateAtOrigin;
    private String agentName;
    private String comments;
    private String decisionStatusAML;
    private String lockingReasonAML;
    private long timestampAMLlocking;
    @JsonProperty(value = "isManualTicketLocking") public boolean manualticketLocking;
    private String amlAgentName;
    private String shopAgentName;
    private long decisionTimestampAML;
    private boolean isManualTicketLocking;
}

package gbs.api.test.request.inventory.shop;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddShopRequest {

    private String brandName;
    private String businessUnit;
    private String country;
    private String currencyCode;
    private String defaultGateway;
    private String locale;
    private String regionAreaCode;
    private String regionCode;
    private String shopId;
    private String subRegionCode;
    private String timeZone;
    private Object validated;

}

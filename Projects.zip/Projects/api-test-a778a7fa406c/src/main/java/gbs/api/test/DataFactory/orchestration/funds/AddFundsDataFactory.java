package gbs.api.test.DataFactory.orchestration.funds;

import gbs.api.test.common.CommonActions;
import gbs.api.test.request.orchestration.funds.AddEODRequest;
import gbs.api.test.request.orchestration.funds.AddFundsRequest;
import gbs.api.test.utils.Constants;
import gbs.api.test.utils.SessionKeys;
import net.thucydides.core.annotations.Steps;
import java.util.Map;

public class AddFundsDataFactory {

    @Steps
    private CommonActions commonActions;

    @Steps
    private SessionKeys sessionKeys;

    private String anonymousPlayerSessionId;
    private String reqRefId;
    private String reqId;
    private Object totalCashAmt;
    private String currency;

    public AddFundsRequest generateAddAmountPayload(Map<String, String> requestValues) {
        anonymousPlayerSessionId = requestValues.get("anonymousPlayerSessionId");
        reqRefId = requestValues.get("reqRefId");
        currency = commonActions.getCurrency(requestValues.get("currency"));

        if ("valid".equalsIgnoreCase(anonymousPlayerSessionId)) {
            anonymousPlayerSessionId = String.valueOf(Constants.ZERO_NUM);
        }

        if ("valid".equalsIgnoreCase(reqRefId) || "random".equalsIgnoreCase(reqRefId)) {
            reqRefId = commonActions.generateRandomAlphaNumericNumber(20);
        }

        return AddFundsRequest.builder()
                .agentName(requestValues.get("agentName"))
                .amount(Integer.parseInt(requestValues.get("amount")))
                .anonymousPlayerSessionId(Integer.parseInt(anonymousPlayerSessionId))
                .currency(currency)
                .description(Constants.STRING_CONSTANT)
                .paymentDtls(Constants.STRING_CONSTANT)
                .paymentMode(Constants.STRING_CONSTANT)
                .reqRefId(reqRefId)
                .subTxnType(requestValues.get("subTxnType"))
                .transactionDateAtOrigin(commonActions.generateTimeStamp())
                .txnType(requestValues.get("txnType"))
                .build();
    }
    public AddEODRequest postCashUpPayload(Map<String, String> requestValues) {

        reqId = requestValues.get("reqId");

        if ("valid".equalsIgnoreCase(reqId)) {
            reqId = commonActions.generateRandomAlphaNumericNumber(20);
        }

        if ("valid".equalsIgnoreCase(requestValues.get("totalCash"))) {
            totalCashAmt = sessionKeys.getData(SessionKeys.DataKeys.TERMINAL_BALANCE);
        } else {
            totalCashAmt = requestValues.get("totalCash");
        }

        return AddEODRequest.builder()
                .accountName(commonActions.getAccountName(requestValues.get("accountName")))
                .agentName(requestValues.get("agentName"))
                .currency(commonActions.getCurrency(requestValues.get("currency")))
                .reqId(reqId)
                .totalCash(Integer.parseInt(String.valueOf(totalCashAmt)))
                .build();
    }

}

package gbs.api.test.request.auditManagement.shopData;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)

public class ShopDataRequest {

    private AmountRangeRequest amountRange;
    private DateRangeRequest dateRange;
    private String id;
    private String shopId;
    private List<String> status;
    private String terminalId;
    private List<String> transactionType;
    private String userName;

}

package gbs.api.test.request.orchestration.betSlip;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)

public class PayoutBetSlipRequest {

    private String agentName;
    private String currency;
    private String description;
    private String reqRefId;
    private Long transactionDateAtOrigin;
    private Integer voidReturns;
    private Integer amount;
    private Integer winReturns;
    private Boolean isFundsAvailableAtWallet;
    private Boolean isManualCancelled;
}

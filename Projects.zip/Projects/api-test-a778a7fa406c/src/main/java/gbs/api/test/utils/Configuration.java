package gbs.api.test.utils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;

public class Configuration {

    private static final Logger LOGGER = LoggerFactory.getLogger(Configuration.class);
    private static Properties configuration = new Properties();

    static {
        initConfig();
    }

    private Configuration() {
        super();
    }

    public static String get(String propertyName) {
        String data = configuration.getProperty(propertyName);
        if (data != null) {
            return data;
        } else {
            throw new RuntimeException("Test Data Resource Path not specified in the "
                    + "properties file for the Key: " + propertyName);
        }
    }

    public static void initConfig() {
        String environmentName = "properties/" + getEnvironmentFromMasterProperties();
        LOGGER.info(environmentName);
        Properties environmentProperties = new Properties();
        loadProperties(environmentProperties, getClassPathResourceStream(environmentName));
        copyPropertiesToConfiguration(environmentProperties);
        addSystemPropertiesToConfiguration();
        @SuppressWarnings("unchecked")
        Enumeration<String> e = (Enumeration<String>) configuration.propertyNames();
        while (e.hasMoreElements()) {
            String key = e.nextElement();
            LOGGER.debug("Property loaded '" + key + "' value '" + configuration.get(key) + "'");
        }
        LOGGER.info("Environment '" + configuration.get("test.env") + "'");
    }

    private static void addSystemPropertiesToConfiguration() {
        Enumeration<?> e = System.getProperties().propertyNames();
        while (e.hasMoreElements()) {
            String key = (String) e.nextElement();
            configuration.put(key, System.getProperties().getProperty(key).trim());
        }
    }


    private static void copyPropertiesToConfiguration(Properties props) {
        Enumeration<?> e = props.propertyNames();
        while (e.hasMoreElements()) {
            String key = (String) e.nextElement();
            if (!System.getProperties().containsKey(key) && !configuration.containsKey(key)) {
                configuration.put(key, props.getProperty(key));
            }
        }
    }


    private static String getEnvironmentFromMasterProperties() {
        if (!StringUtils.isEmpty(System.getProperty("test.env"))) {
            return System.getProperty("test.env") + ".properties";
        } else {
            return "test.properties";
        }
    }

    private static void loadProperties(Properties props, InputStream inputStream) {
        try {
            props.load(inputStream);
        } catch (IOException e) {
            LOGGER.error("Could not load properties", e);
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException ioe) {
                LOGGER.error(ioe.getMessage(), ioe);
            }
        }
    }

    public static InputStream getClassPathResourceStream(String classpathResourceLoc) {
        return Thread.currentThread().getContextClassLoader().getResourceAsStream(classpathResourceLoc);
    }
}

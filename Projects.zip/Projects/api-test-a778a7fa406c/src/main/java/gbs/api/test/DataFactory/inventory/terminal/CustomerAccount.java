package gbs.api.test.DataFactory.inventory.terminal;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerAccount {

    private String accountName;
    private String brandName;
    private Integer customerId;
    private String shopId;
    private String terminalId;

}

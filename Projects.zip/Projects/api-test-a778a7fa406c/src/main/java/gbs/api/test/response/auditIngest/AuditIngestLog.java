package gbs.api.test.response.auditIngest;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)

public class AuditIngestLog extends ResponseEntity {

    private String migrationMessage;
    private String fetchedDataCount;
    private String ingestedDataCount;
    private String httpStatus;
}

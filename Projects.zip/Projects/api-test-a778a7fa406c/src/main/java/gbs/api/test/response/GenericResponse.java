package gbs.api.test.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GenericResponse extends ResponseEntity {

    private String status;
    private String accountName;
    private Integer statusCode;
    private Integer requestValues;
    private Integer accountBalance;
    private String success;
    private String errorCode;

    private String errorMessage;
}

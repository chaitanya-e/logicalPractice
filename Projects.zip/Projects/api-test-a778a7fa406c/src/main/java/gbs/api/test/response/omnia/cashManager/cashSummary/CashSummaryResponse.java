package gbs.api.test.response.omnia.cashManager.cashSummary;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CashSummaryResponse extends ResponseEntity {
    private String terminalId;
    private Integer totalCash;
    private Integer totalCoins;
    private Integer totalNotes;
    private Integer balance;
    private String status;
    private String currency;
}

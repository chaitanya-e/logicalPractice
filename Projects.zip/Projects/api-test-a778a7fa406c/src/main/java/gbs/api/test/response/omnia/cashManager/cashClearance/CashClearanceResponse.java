package gbs.api.test.response.omnia.cashManager.cashClearance;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CashClearanceResponse extends ResponseEntity {
    private List<CashClearanceEvents> cashClearanceEvents;
    private String shopId;
    private Integer totalCashInShop;
}

package gbs.api.test.steps.retailBetSlip.retailBetSlip;

import gbs.api.test.DataFactory.retailBetSlip.retailBetSlip.UpdateRetailBetSlipDataFactory;
import gbs.api.test.common.CommonActions;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.*;

public class RetailBetSlipSteps extends CommonActions {

    @Steps
    private UpdateRetailBetSlipDataFactory updateRetailBetSlipDataFactory;
    private Map<String, String> setBrandShopIdHeaders(Map<String, String> values) {
        Map<String, String> headersMap = new HashMap<String, String>();
        headersMap.put("brand", getBrandName(values.get("brand")));
        headersMap.put("shopId", getShopID(values.get("shopId")));
        return headersMap;
    }

    public void getRBSWithPageGetRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .when()
                .queryParam(PAGE, requestValues.get(0).get("pages"))
                .queryParam(SIZE, requestValues.get(0).get("size"))
                .get(getApiUrl() +  BET_SLIP + BET_RECEIPTS);
        storeResponseToTestSession(response);
    }

    public void getRBSGetRequest(String betId, List<Map<String, String>> requestValues) {

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setBrandShopIdHeaders(requestValues.get(0)))
                .headers(setAccountNameSourceHeaders(requestValues.get(0)))
                .when()
                .get(getApiUrl() +  BET_SLIP + BET_RECEIPTS + VERSION_3 + betId);
        storeResponseToTestSession(response);
    }

    public void updateRBSPutRequest(String betId, List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(setAccountNameSourceHeaders(requestValues.get(0)))
                .body(updateRetailBetSlipDataFactory.updateRBSPayload(requestValues.get(0)))
                .when()
                .put(getApiUrl() +  BET_SLIP + BET_RECEIPTS + LOCK + betId);
        storeResponseToTestSession(response);
    }
}

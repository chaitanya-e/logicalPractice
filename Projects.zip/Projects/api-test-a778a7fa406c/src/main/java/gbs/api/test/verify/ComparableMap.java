package gbs.api.test.verify;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.TreeMap;


/**
 * This class is used for assertions for entities of different types.
 */
public class ComparableMap extends TreeMap<String, String> {
    private static final String NULL_STRING = "null";

    public ComparableMap() {
        super();
    }

    public ComparableMap(final Map<String, String> initMap) {
        super(initMap);
        super.replaceAll((key, value) -> handleNull(value));
    }

    public ComparableMap(final Object obj) {
        for (Field field : obj.getClass().getDeclaredFields()) {
            try {
                field.setAccessible(true);
                add(field.getName(), String.valueOf(field.get(obj)));
            } catch (final IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
    }


    public final ComparableMap add(final String key, final String value) {
        put(key, value);
        return this;
    }

    public ComparableMap include(final String key, final String values) {
        put(key, values);
        return this;
    }

    private String handleNull(final String value) {
        if (value == null) {
            return NULL_STRING;
        }
        return value;
    }
}


package gbs.api.test.DataFactory.inventory.terminal;

import gbs.api.test.common.CommonActions;
import gbs.api.test.request.inventory.terminal.AddTerminalRequest;
import gbs.api.test.utils.SessionKeys;
import net.thucydides.core.annotations.Steps;

import java.util.Map;

public class AddTerminalDataFactory {

    @Steps
    private CommonActions commonActions;

    @Steps
    private SessionKeys sessionKeys;

    public String getMacID(String featureFileMacIDValue) {
        switch (featureFileMacIDValue.toLowerCase().trim()) {
            case "random":
                String macID = commonActions.getRandomMacId(4);
                sessionKeys.setData(SessionKeys.DataKeys.MAC_ID, macID);
                return macID;
            case "existing":
                return sessionKeys.getData(SessionKeys.DataKeys.MAC_ID);
            default:
                return featureFileMacIDValue;
        }
    }


    public AddTerminalRequest generateAddTerminalPayload(Map<String, String> requestValues, String terminalID) {
        String shopID = commonActions.getShopID(requestValues.get("shopId"));
        String brandName = commonActions.getBrandName(requestValues.get("brandName"));
        //String terminalID = commonActions.getTerminalID(requestValues.get("terminalId"));
        String macID = getMacID(requestValues.get("macId"));

        return AddTerminalRequest.builder()
                .brandName(brandName)
                .ipAddress(requestValues.get("ipAddress"))
                .lockStatus(requestValues.get("lockStatus"))
                .macId(macID)
                .resolution(requestValues.get("resolution"))
                .shopId(shopID)
                .terminalId(terminalID)
                .terminalCategory("GBS")
                .terminalStatus(requestValues.get("terminalStatus"))
                .terminalType(requestValues.get("terminalType") + "_Automation")
                .volume(Integer.valueOf(requestValues.get("volume")))
                .build();
    }

    public AddTerminalRequest generateAddTerminalStatusPayload(String lockStatus) {
        return AddTerminalRequest.builder()
                .lockReason("GBS_TEST_AUTOMATION")
                .lockType("Temporary")
                .lockStatus(lockStatus)
                .reqRefId(commonActions.generateRandomAlphaNumericNumber(20))
                .sessionType("ANONYMOUS")
                .transactionDateAtOrigin(commonActions.generateTimeStamp())
                .user(commonActions.getUserName())
                .build();
    }

    public AddTerminalRequest generateUpdateTerminalPayload(Map<String, String> requestValues) {
        String macID = getMacID(requestValues.get("macId"));
        return AddTerminalRequest.builder()
                .macId(macID)
                .resolution(requestValues.get("resolution"))
                .terminalStatus(requestValues.get("terminalStatus"))
                .terminalType(requestValues.get("terminalType"))
                .volume(Integer.valueOf(requestValues.get("volume")))
                .build();
    }

    public AddTerminalRequest generateUpdateTerminalStatusPayload(Map<String, String> requestValues) {
        return AddTerminalRequest.builder()
                .lockReason(requestValues.get("lockReason"))
                .lockStatus(requestValues.get("lockStatus"))
                .lockType(requestValues.get("lockType"))
                .reqRefId(commonActions.generateRandomAlphaNumericNumber(20))
                .sessionType(requestValues.get("sessionType"))
                .source(requestValues.get("source"))
                .transactionDateAtOrigin(commonActions.generateTimeStamp())
                .user(commonActions.getUserId(requestValues.get("user")))
                .build();
    }
}

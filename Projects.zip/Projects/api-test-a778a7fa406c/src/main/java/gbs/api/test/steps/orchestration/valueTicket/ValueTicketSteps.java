package gbs.api.test.steps.orchestration.valueTicket;

import gbs.api.test.common.CommonActions;
import gbs.api.test.DataFactory.orchestration.valueTicket.AddValueTicketDataFactory;
import gbs.api.test.utils.SessionKeys;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.*;

public class ValueTicketSteps extends CommonActions {

    @Steps
    private AddValueTicketDataFactory addValueTicketDataFactory;

    @Steps
    private SessionKeys sessionKeys;

    private String agentName;

    private Map<String, String> valueTicketTokenHeaders(Map<String, String> requestValues) {
        Map<String, String> headersMap = new HashMap<String, String>();
        if (requestValues.containsKey("accountName")) {
            headersMap.put("accountName", getAccountName(requestValues.get("accountName")));
        }
        if (requestValues.containsKey("agentName")) {
            headersMap.put("agentName", requestValues.get("agentName"));
        }

        if (requestValues.containsKey("ssoToken")) {
            String token = setSSOTokenHeaders(requestValues).get("sessionKey");
            headersMap.put("sessionKey", token);
        }
        if (requestValues.containsKey("valueTicketId")) {
            headersMap.put("valueTicketId", sessionKeys.getData(SessionKeys.DataKeys.VALUE_TICKET));
        }
        return headersMap;
    }

    private Map<String, String> valueTicketSourceHeaders(Map<String, String> requestValues) {
        Map<String, String> headersMap = new HashMap<String, String>();
        if (requestValues.containsKey("source")) {
            headersMap.put("source", requestValues.get("source"));
        }
        if (requestValues.containsKey("currentShopId")) {
            headersMap.put("currentShopId", getShopID(requestValues.get("shopId")));
        }
        return headersMap;
    }

    public void getValueTicketGetRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(valueTicketTokenHeaders(requestValues.get(0)))
                .headers(valueTicketSourceHeaders(requestValues.get(0)))
                .when()
                .get(getApiUrl() + ORCHESTRATOR + VALUE_TICKET);
        storeResponseToTestSession(response);
    }

    public void getValueTicketByIdGetRequest(List<Map<String, String>> requestValues) {
        agentName = requestValues.get(0).get("agentName");
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(valueTicketTokenHeaders(requestValues.get(0)))
                .headers(valueTicketSourceHeaders(requestValues.get(0)))
                .when()
                .get(getApiUrl() + ORCHESTRATOR + VALUE_TICKETS
                        + sessionKeys.getData(SessionKeys.DataKeys.VALUE_TICKET)
                        + AGENT_NAME + agentName);
        storeResponseToTestSession(response);
    }

    public void PostValueTicketPostRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(valueTicketTokenHeaders(requestValues.get(0)))
                .headers(valueTicketSourceHeaders(requestValues.get(0)))
                .body(addValueTicketDataFactory.generateAddValueTicketPayload(requestValues.get(0)))
                .when()
                .post(getApiUrl() + ORCHESTRATOR + VALUE_TICKET);
        storeResponseToTestSession(response);
    }

    public void PostVTInvalidAmountPostRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(valueTicketTokenHeaders(requestValues.get(0)))
                .headers(valueTicketSourceHeaders(requestValues.get(0)))
                .body(addValueTicketDataFactory.generateVTPayloadWithInvalidAmount(requestValues.get(0)))
                .when()
                .post(getApiUrl() + ORCHESTRATOR + VALUE_TICKET);
        storeResponseToTestSession(response);
    }

    public void PayoutVTPostRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(valueTicketTokenHeaders(requestValues.get(0)))
                .headers(valueTicketSourceHeaders(requestValues.get(0)))
                .body(addValueTicketDataFactory.payoutVTPayload(requestValues.get(0)))
                .when()
                .post(getApiUrl() + ORCHESTRATOR + VALUE_TICKETS + PAYOUT
                        + sessionKeys.getData(SessionKeys.DataKeys.VALUE_TICKET));
        storeResponseToTestSession(response);
    }

    public void LockVTPutRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(valueTicketTokenHeaders(requestValues.get(0)))
                .headers(valueTicketSourceHeaders(requestValues.get(0)))
                .body(addValueTicketDataFactory.lockVTPayload(requestValues.get(0)))
                .when()
                .put(getApiUrl() + ORCHESTRATOR + VALUE_TICKETS + LOCK
                        + sessionKeys.getData(SessionKeys.DataKeys.VALUE_TICKET));
        storeResponseToTestSession(response);
    }

    public void LockVTPutRequestInvalidId(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(valueTicketTokenHeaders(requestValues.get(0)))
                .headers(valueTicketSourceHeaders(requestValues.get(0)))
                .body(addValueTicketDataFactory.lockVTPayload(requestValues.get(0)))
                .when()
                .put(getApiUrl() + ORCHESTRATOR + VALUE_TICKETS + LOCK
                        + INVALID_VT);
        storeResponseToTestSession(response);
    }

    public void UnLockVTPutRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(valueTicketTokenHeaders(requestValues.get(0)))
                .headers(valueTicketSourceHeaders(requestValues.get(0)))
                .body(addValueTicketDataFactory.unLockVTPayload(requestValues.get(0)))
                .when()
                .put(getApiUrl() + ORCHESTRATOR + VALUE_TICKETS + UNLOCK
                        + sessionKeys.getData(SessionKeys.DataKeys.VALUE_TICKET));
        storeResponseToTestSession(response);
    }
}

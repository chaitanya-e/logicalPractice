package gbs.api.test.request.displayChangesForInventoryServices;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder

public class AddDeviceDecoderMappingRequest {
    private String brand;
    private String deviceId;
    private String shopId;
    private String tvDecoderId;
}

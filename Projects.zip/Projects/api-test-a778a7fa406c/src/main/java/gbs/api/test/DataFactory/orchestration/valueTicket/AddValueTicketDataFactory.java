package gbs.api.test.DataFactory.orchestration.valueTicket;

import gbs.api.test.common.CommonActions;
import gbs.api.test.request.orchestration.valueTicket.AddValueTicketRequest;
import static gbs.api.test.utils.Constants.*;

import gbs.api.test.utils.SessionKeys;
import net.thucydides.core.annotations.Steps;

import java.util.Map;

public class AddValueTicketDataFactory {
    @Steps
    private CommonActions commonActions;

    @Steps
    private SessionKeys sessionKeys;

    public String getReferenceId(String featureFileReferenceIdValue) {
        switch (featureFileReferenceIdValue.toLowerCase()) {
            case "random":
                String referenceId = commonActions.generateRandomAlphaNumericNumber(20);
                sessionKeys.setData(SessionKeys.DataKeys.REFERENCE_ID, referenceId);
                return referenceId;
            case "existing":
                return sessionKeys.getData(SessionKeys.DataKeys.REFERENCE_ID);
            case "invalid":
                return "";
            default:
                return featureFileReferenceIdValue;
        }
    }

    public String getPlayerSessionId(String featureFileReferenceIdValue) {
        switch (featureFileReferenceIdValue.toLowerCase()) {
            case "valid":
                return commonActions.getRandomNumber(10);
            case "invalid":
                return "";
            default:
                return featureFileReferenceIdValue;
        }
    }

    public String getAgentName(String featureFileReferenceIdValue) {
        switch (featureFileReferenceIdValue.toLowerCase()) {
            case "valid":
                return STRING_CONSTANT;
            case "invalid":
                return "";
            default:
                return featureFileReferenceIdValue;
        }
    }

    public AddValueTicketRequest generateAddValueTicketPayload(Map<String, String> requestValues) {
        String currencyValue = commonActions.getCurrency(requestValues.get("currency"));
        int terminalAmount = sessionKeys.getData(SessionKeys.DataKeys.TERMINAL_BALANCE);
        String playerSessionId = getPlayerSessionId(requestValues.get("anonymousPlayerSessionId"));
        String referenceId = getReferenceId(requestValues.get("reqRefId"));

        return AddValueTicketRequest.builder()
                .amount(terminalAmount)
                .anonymousPlayerSessionId(playerSessionId)
                .currency(currencyValue)
                .description(STRING_CONSTANT)
                .reqRefId(referenceId)
                .transactionDateAtOrigin(commonActions.generateTimeStamp())
                .build();
    }

    public AddValueTicketRequest generateVTPayloadWithInvalidAmount(Map<String, String> requestValues) {
        String currency = commonActions.getCurrency(requestValues.get("currency"));
        String playerSessionId = getPlayerSessionId(requestValues.get("anonymousPlayerSessionId"));
        String referenceId = getReferenceId(requestValues.get("reqRefId"));

        return AddValueTicketRequest.builder()
                .amount(ZERO_NUM)
                .anonymousPlayerSessionId(playerSessionId)
                .currency(currency)
                .description(STRING_CONSTANT)
                .reqRefId(referenceId)
                .transactionDateAtOrigin(commonActions.generateTimeStamp())
                .build();
    }

    public AddValueTicketRequest payoutVTPayload(Map<String, String> requestValues) {
        String referenceId = getReferenceId(requestValues.get("reqRefId"));

        return AddValueTicketRequest.builder()
                .agentName(STRING_CONSTANT)
                .description(STRING_CONSTANT)
                .reqRefId(referenceId)
                .transactionDateAtOrigin(commonActions.generateTimeStamp())
                .build();
    }

    public AddValueTicketRequest lockVTPayload(Map<String, String> requestValues) {
        String referenceId = getReferenceId(requestValues.get("reqRefId"));
        String getAMLStatus = requestValues.get("decisionStatusAML");

        return AddValueTicketRequest.builder()
                .agentName(STRING_CONSTANT)
                .comments(STRING_CONSTANT)
                .decisionStatusAML(getAMLStatus)
                .manualticketLocking(true)
                .lockingReasonAML(STRING_CONSTANT)
                .reqRefId(referenceId)
                .timestampAMLlocking(commonActions.generateTimeStamp())
                .build();
    }

    public AddValueTicketRequest unLockVTPayload(Map<String, String> requestValues) {
        String referenceId = getReferenceId(requestValues.get("reqRefId"));
        String agentName = getAgentName(requestValues.get("amlAgentName"));
        String getAMLStatus = requestValues.get("decisionStatusAML");

        return AddValueTicketRequest.builder()
                .decisionStatusAML(getAMLStatus)
                .lockingReasonAML(STRING_CONSTANT)
                .comments(STRING_CONSTANT)
                .timestampAMLlocking(commonActions.generateTimeStamp())
                .decisionTimestampAML(commonActions.generateTimeStamp())
                .agentName(agentName)
                .amlAgentName(agentName)
                .isManualTicketLocking(Boolean.parseBoolean(requestValues.get("isManualTicketLocking")))
                .reqRefId(referenceId)
                .build();
    }
}

package gbs.api.test.request.displayChangesForInventoryServices;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder

public class AddScreenGroupRequest {
    private String brand;
    private Integer screenCount;
    private String screenGroupName;
    private String shopId;
}

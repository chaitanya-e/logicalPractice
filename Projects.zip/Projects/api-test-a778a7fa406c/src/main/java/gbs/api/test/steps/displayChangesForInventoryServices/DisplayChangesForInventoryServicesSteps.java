package gbs.api.test.steps.displayChangesForInventoryServices;

import gbs.api.test.DataFactory.displayChangesForInventoryServices.DisplayChangesForInventoryServicesDataFactory;
import gbs.api.test.common.CommonActions;
import gbs.api.test.utils.Configuration;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import java.util.Map;

import static gbs.api.test.utils.Constants.*;

public class DisplayChangesForInventoryServicesSteps extends CommonActions {

    @Steps
    private DisplayChangesForInventoryServicesDataFactory displayChangesForInventoryServicesDataFactory;

    public void addDevicePostRequest(Map<String, String> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .body(displayChangesForInventoryServicesDataFactory.generateAddDevicePayload(requestValues))
                .when()
                .post(getApiUrl() + INVENTORY + DEVICE);
        storeResponseToTestSession(response);
    }

    public void addDeviceToTVDecoderMappingPostRequest(Map<String, String> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .body(displayChangesForInventoryServicesDataFactory.generateDeviceDecoderMappingPayload(requestValues))
                .when()
                .post(getApiUrl() + INVENTORY + DEVICE_DECODER_MAPPING);
        storeResponseToTestSession(response);

    }

    public void addScreenGroupPostRequest(Map<String, String> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .body(displayChangesForInventoryServicesDataFactory.generateScreenGroupPayload(requestValues))
                .when()
                .post(getApiUrl() + INVENTORY + SCREEN_GROUP);
        storeResponseToTestSession(response);
    }

    public void addTVDecoderPostRequest(Map<String, String> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .body(displayChangesForInventoryServicesDataFactory.generateAddTVDecoderPayload(requestValues))
                .when()
                .post(getApiUrl() + INVENTORY + TV_DECODER);
        storeResponseToTestSession(response);
    }

    public void getScreenGroupListGetRequest(Map<String, String> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .get(getApiUrl() + INVENTORY + SCREEN_GROUPS + "/" + getShopID(requestValues.get("shopId")));
        storeResponseToTestSession(response);

    }

    public void getTVDecoderListGetRequest(Map<String, String> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .get(getApiUrl() + INVENTORY + TV_DECODER + "/" + getBrandName(requestValues.get("brand")) + "/" + getShopID(requestValues.get("shopId")));
        storeResponseToTestSession(response);

    }
    public void deleteScreenGroupDeleteRequest(Map<String, String> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .delete(getApiUrl() + INVENTORY + SCREEN_GROUPS + "/" + getBrandName(requestValues.get("brandName")) + "/" + getShopID(requestValues.get("shopId")));
        storeResponseToTestSession(response);
    }

    public void deleteDeviceDeleteRequest(Map<String, String> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .delete(getApiUrl() + INVENTORY + DEVICE + "/" + getBrandName(requestValues.get("brandName")) + "/" + getShopID(requestValues.get("shopId"))
                        + "/" + Configuration.get("deviceId"));
        storeResponseToTestSession(response);
    }

    public void removeTVDecoderInShopFromDBDeleteRequest(Map<String, String> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .delete(getApiUrl() + INVENTORY + TV_DECODER + "/" + getShopID(requestValues.get("shopId")) + "/" + getBrandName(requestValues.get("brandName"))
                        + "/" + requestValues.get("decoderIP"));
        storeResponseToTestSession(response);
    }

}

package gbs.api.test.DataFactory.ominia.cashManager.cashClearance;

import gbs.api.test.common.CommonActions;
import gbs.api.test.request.omnia.cashManager.cashClearance.CashClearanceRequest;
import gbs.api.test.steps.omnia.cashManager.cashSummary.CashSummarySteps;
import net.thucydides.core.annotations.Steps;

import java.util.Map;

public class CashClearanceDataFactory {

    @Steps
    private CommonActions commonActions;

    @Steps
    private CashSummarySteps cashSummarySteps;

    private String currency;
    private String cashClearanceId;

    public CashClearanceRequest generateCashClearancePayload(Map<String, String> requestValues) {

        currency = commonActions.getCurrency(requestValues.get("currency"));
        cashClearanceId = requestValues.get("cashClearanceId");

        if ("random".equalsIgnoreCase(cashClearanceId)) {
            cashClearanceId = commonActions.getRandomMacId(8);
        }
        return CashClearanceRequest.builder()
                .cashClearanceId(cashClearanceId)
                .countedAmountCoins(Integer.valueOf(requestValues.get("countedAmountCoins")))
                .countedAmountNotes(Integer.valueOf(requestValues.get("countedAmountNotes")))
                .currency(currency)
                .expectedAmountCoins(Integer.valueOf(requestValues.get("expectedAmountCoins")))
                .expectedAmountNotes(Integer.valueOf(requestValues.get("expectedAmountNotes")))
                .build();
    }
}

package gbs.api.test.response.omnia.cashManager.cashClearance;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CashClearanceEvents extends ResponseEntity {
    private Integer countedAmountCoins;
    private Integer countedAmountNotes;
    private Integer countedAmountTotal;
    private Integer cashclearanceDatetime;
    private Integer endOfDayFrom;
    private Integer endOfDayTo;
    private Integer expectedAmountCoins;
    private Integer expectedAmountNotes;
    private Integer expectedAmountTotal;
    private String id;
    private String shopId;
    private String terminalId;
    private String userId;
    private String userName;
    private Integer variance;
    private String currency;
}

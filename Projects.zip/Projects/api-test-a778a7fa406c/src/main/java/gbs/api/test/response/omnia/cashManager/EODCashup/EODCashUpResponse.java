package gbs.api.test.response.omnia.cashManager.EODCashup;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EODCashUpResponse  extends ResponseEntity {
    private Integer unclaimedPayments;
    private Integer countedCash;
    private Integer eodEndTime;
    private Integer expectedCash;
    private String shopId;
    private Integer eodStartTime;
    private List<TerminalOverview> terminalOverview;
    private Integer totalPayout;
    private Integer totalStakes;
    private Integer valueTicketsIssued;
    private Integer valueTicketsRedeemed;
    private String userName;
    private String userid;
}

package gbs.api.test.request.orchestration.funds;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)

public class AddFundsRequest {

    private String agentName;
    private String currency;
    private String description;
    private String paymentDtls;
    private String paymentMode;
    private String reqRefId;
    private String subTxnType;
    private String txnType;
    private long transactionDateAtOrigin;
    private int amount;
    private int anonymousPlayerSessionId;
}

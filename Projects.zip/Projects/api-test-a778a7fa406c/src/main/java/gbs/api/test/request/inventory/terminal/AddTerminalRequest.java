package gbs.api.test.request.inventory.terminal;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.DataFactory.inventory.terminal.CustomerAccount;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddTerminalRequest {

    private String brandName;
    private CustomerAccount customerAccount;
    private String ipAddress;
    private String lockStatus;
    private String macId;
    private String resolution;
    private String shopId;
    private String terminalId;
    private String terminalCategory;
    private String terminalStatus;
    private String terminalType;
    private Integer volume;

    private String transactionId;
    private String userId;
    private String userName;

    private String lockReason;
    private String lockType;
    private String reqRefId;
    private String sessionType;
    private Long transactionDateAtOrigin;
    private String user;
    private String source;


}

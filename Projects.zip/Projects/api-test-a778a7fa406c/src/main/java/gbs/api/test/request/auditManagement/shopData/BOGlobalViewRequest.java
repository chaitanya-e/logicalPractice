package gbs.api.test.request.auditManagement.shopData;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import java.util.List;

@Setter
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)

public class BOGlobalViewRequest {

    private AmountRangeRequest amountRange;
    private GlobalViewDateRangeRequest dateRange;
    public List<String> brand;
    public List<String> country;
    public List<String> currency;
    public List<String> id;
    public List<String> regionAreaCode;
    public List<String> regionCode;
    public List<String> shopId;
    public List<String> status;
    public String terminalId;
    public List<String> transactionType;
    public List<String> userName;
}

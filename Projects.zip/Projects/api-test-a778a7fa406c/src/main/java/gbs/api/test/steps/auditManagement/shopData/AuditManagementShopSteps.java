package gbs.api.test.steps.auditManagement.shopData;

import gbs.api.test.DataFactory.auditManagement.shopData.ShopDataFactory;
import gbs.api.test.common.CommonActions;
import gbs.api.test.verify.GenericRestVerify;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static gbs.api.test.utils.Constants.*;
import static org.assertj.core.api.Assertions.assertThat;

public class AuditManagementShopSteps extends CommonActions {

    @Steps
    private ShopDataFactory shopDataFactory;

    @Steps
    private CommonActions commonActions;

    @Steps
    private GenericRestVerify genericRestVerify;

    private String shopId;

    public Map<String, String> setPageAndSizeHeaders(Map<String, String> requestValues) {
        Map<String, String> headersMap = new HashMap<String, String>();
        if (requestValues.containsKey("size")) {
            headersMap.put("size", requestValues.get("size"));
        }
        if (requestValues.containsKey("page")) {
            headersMap.put("page", requestValues.get("page"));
        }
        return headersMap;
    }


    public void getFilteredAuditData(List<Map<String, String>> requestValues) {
        String shopId = commonActions.getShopID(requestValues.get(0).get("shopId"));

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setAcceptHeader())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(setPageAndSizeHeaders(requestValues.get(0)))
                .body(shopDataFactory.getFilteredAuditData(requestValues.get(0)))
                .queryParam("brand", getBrandName(requestValues.get(0).get("brand")))
                .queryParam("size", requestValues.get(0).get("size"))
                .when()
                .post(getApiUrl() + AUDIT + VIEW + shopId);

        storeResponseToTestSession(response);
    }

    public void createFilteredAuditData(List<Map<String, String>> requestValues) {

        shopId = commonActions.getShopID(requestValues.get(0).get("shopId"));
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setAcceptHeader())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(setPageAndSizeHeaders(requestValues.get(0)))
                .body(shopDataFactory.getFilteredAuditData(requestValues.get(0)))
                .queryParam("brand", getBrandName(requestValues.get(0).get("brand")))
                .queryParam("page", requestValues.get(0).get("page"))
                .queryParam("size", requestValues.get(0).get("size"))
                .when()
                .post(getApiUrl() + AUDIT + VIEW_DATA + shopId);

        storeResponseToTestSession(response);
    }

    public void verifyListOfFieldInResponseForResponse(List<Map<String, String>> expectedValues) {
        Response response = commonActions.getResponseFromTestSession();
        String jsonString = genericRestVerify.getResponseAsRawString(response);
        jsonString = jsonString.replaceAll("/", "");

        if (expectedValues.get(0).containsKey("country")) {
            List<String> actualValues = new ArrayList<>();
            Pattern p = Pattern.compile("\\\"country\\\"" + ":" + "\\\"(\\w+?)\\\"");
            Matcher m = p.matcher(jsonString);
            List<String> expValues = commonActions.getCountries();
            while (m.find()) {
                actualValues.add(m.group(1));
            }
            assertThat(actualValues).containsAnyElementsOf(expValues);
        }
        if (expectedValues.get(0).containsKey("regionCode")) {
            List<String> actualValues = new ArrayList<>();
            List<String> expValues = commonActions.getRegions();
            Pattern p = Pattern.compile("\\\"regionCode\\\"" + ":" + "\\\"(\\w+?)\\\"");
            Matcher m = p.matcher(jsonString);
            while (m.find()) {
                actualValues.add(m.group(1));
            }
            assertThat(actualValues).containsAnyElementsOf(expValues);
        }
        if (expectedValues.get(0).containsKey("regionAreaCode")) {
            List<String> actualValues = new ArrayList<>();
            List<String> expValues = commonActions.getRegionAreaCodes();
            Pattern p = Pattern.compile("\\\"regionAreaCode\\\"" + ":" + "\\\"(\\w+?)\\\"");
            Matcher m = p.matcher(jsonString);
            while (m.find()) {
                actualValues.add(m.group(1));
            }
            assertThat(actualValues).containsAnyElementsOf(expValues);
        }
    }
}

package gbs.api.test.request.displayChangesForInventoryServices;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder

public class AddTVDecoderRequest {
    private String brandName;
    private String ipAddress;
    private String name;
    private String shopId;
    private String tvDecoderId;
}

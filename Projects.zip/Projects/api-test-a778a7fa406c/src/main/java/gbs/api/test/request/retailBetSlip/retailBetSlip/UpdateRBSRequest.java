package gbs.api.test.request.retailBetSlip.retailBetSlip;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)

public class UpdateRBSRequest {

    private String amlDecisionStatus;
    private String comments;
    private String lockingReason;
    private String timestamp;
    private String transactionId;
    private String userId;
    private String userName;
}

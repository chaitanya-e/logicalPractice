package gbs.api.test.utils;


public class Constants {

    //Json Headers
    public static final String APPLICATION_JSON = "application/json";

    //Status Codes
    public static final Integer STATUS_CODE_200I = 200;

    // Inventory API Endpoints
    public static final String INVENTORY = "inventory/";
    public static final String ADD_SHOP = "shop";
    public static final String SHOP = "shop/";
    public static final String GET_SHOP = "shops";
    public static final String GET_SHOPS = "shops/";
    public static final String BRAND = "brand/";
    public static final String ADD_TERMINAL = "terminal";
    public static final String TERMINAL = "terminal/";
    public static final String CUSTOMER_ACCOUNT = "customerAccount/";
    public static final String ALL = "all";
    public static final String STATUS = "status/";
    public static final String TERMINAL_STATUS = "terminalstatus/";

    // Orchestration API Endpoints
    public static final String ORCHESTRATOR = "orchestrator/";
    public static final String BET_SLIP = "betslip/";
    public static final String VALUE_TICKETS = "valuetickets/";
    public static final String VALUE_TICKET = "valuetickets";
    public static final String FUNDS = "funds";
    public static final String AGENT_NAME = "?agentName=";
    public static final String TRANSACTIONS = "transactions/";
    public static final String TOTAL_CASH = "totalCash";
    public static final String PAYOUT = "payout/";
    public static final String LOCK = "lock/";
    public static final String UNLOCK = "unlock/";
    public static final String REPORTS = "reports/";
    public static final String HIGH_MLC = "highMLC";
    public static final String CASH_UP = "cashup";

    //RBS API Endpoints
    public static final String BET_RECEIPTS = "betreceipts/";
    public static final String PAGE = "page";
    public static final String SIZE = "size";
    public static final String VERSION_3 = "3.0/";

    //Audit Management API Endpoints
    public static final String AUDIT = "audit/";
    public static final String VIEW = "view/";
    public static final String VIEW_DATA = "viewdata/";
    public static final String GLOBAL_VIEW = "globalview/";
    public static final String TYPE_HEAD_SEARCH = "typeheadSearch/";
    public static final String VIEW_AUDIT_DATA = "viewauditdata/";

    //Audit Ingest API Endpoints
    public static final String AUDIT_INGEST = "auditingest/";
    public static final String AUDIT_INGEST_BULK_UPDATE = "bulkupdate/";
    public static final String AUDIT_INGEST_BULK_INSERT = "bulkinsert/";

    // Constant value
    public static final String STRING_CONSTANT = "string";
    public static final int ZERO_NUM = 0;
    public static final int TEN_NUM = 10;
    public static final String INVALID_VT = "abc";

    // Omnia- Cash Manager
    public static final String CASH_MANAGER = "cashmanager/";
    public static final String CASH_SUMMARY = "cashsummary";
    public static final String CASH_CLEARANCE = "cashclearance";
    public static final String EOD_CASH_UP = "eodcashup";

    //Display changes in inventory services
    public static final String SCREEN_GROUP = "screenGroup";
    public static final String SCREEN_GROUPS = "screenGroups";
    public static final String TV_DECODER = "tvDecoder";
    public static final String DEVICE = "device";
    public static final String DEVICE_DECODER_MAPPING = "deviceDecoderMapping";

}

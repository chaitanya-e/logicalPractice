package gbs.api.test.response.orchestration.funds;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)

public class FundsResponse extends ResponseEntity {
    private String status;
    private String accountName;
    private Integer statusCode;
    private Integer requestValues;
    private Integer accountBalance;
}

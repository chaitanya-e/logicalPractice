package gbs.api.test.utils;

import io.restassured.response.Response;
import lombok.Getter;
import net.serenitybdd.core.Serenity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class SessionKeys {
    private static final Logger LOGGER = LoggerFactory.getLogger(SessionKeys.class);
    public <T> void setData(DataKeys keys, T value) {
        Serenity.setSessionVariable(keys).to(value);
    }

    public <T> T getData(DataKeys key) {
        if (keyExist(key)) {
            return Serenity.sessionVariableCalled(key);
        } else {
            LOGGER.info(key + " Session variable is not present in serenity session");
//            throw new RuntimeException(key + " Session variable is not present in serenity session");
            return null;
        }
    }

    private boolean keyExist(DataKeys key) {
        return Serenity.hasASessionVariableCalled(key);
    }

    public enum DataKeys {
        SHOP_ID(String.class),
        MAC_ID(String.class),
        TERMINAL_ID(String.class),
        NEW_TERMINAL_CREATED(String.class),
        CUSTOMER_ID(String.class),
        NEW_CUSTOMER_ID_CREATED(String.class),
        RESPONSE(Response.class),
        BET_ID(String.class),
        VALUE_TICKET(String.class),
        TERMINAL_BALANCE(Integer.class),
        TERMINAL_IDS(List.class),
        REFERENCE_ID(String.class),
        EOD_SOURCE(String.class),
        NEW_AUTOMATION_SHOP(String.class),
        NEW_SHOP_CREATED(String.class),
        EOD_TOTAL_CASH(List.class);

        @Getter
        private Class<?> type;

        DataKeys(Class<?> type) {
            this.type = type;
        }
    }
}

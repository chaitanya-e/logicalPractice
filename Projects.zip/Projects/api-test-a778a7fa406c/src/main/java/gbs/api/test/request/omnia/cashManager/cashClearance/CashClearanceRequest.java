package gbs.api.test.request.omnia.cashManager.cashClearance;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CashClearanceRequest {
    private String cashClearanceId;
    private Integer countedAmountCoins;
    private Integer countedAmountNotes;
    private String currency;
    private Integer expectedAmountCoins;
    private Integer expectedAmountNotes;
}

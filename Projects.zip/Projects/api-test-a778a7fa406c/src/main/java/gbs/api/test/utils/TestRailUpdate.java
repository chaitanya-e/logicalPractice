package gbs.api.test.utils;

import cucumber.api.Scenario;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import gbs.api.test.common.CommonActions;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.SoftAssertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.STATUS_CODE_200I;

public class TestRailUpdate extends CommonActions {
    private static final String URI_ADD_RESULT_FOR_CASEID = "index.php?/api/v2/add_result_for_case/";
    private static final String URI_GET_RESULT_FOR_CASEID = "index.php?/api/v2/get_results_for_case/";
    private static final Logger LOGGER = LoggerFactory.getLogger(TestRailUpdate.class);

    private String getTestRailStatusForCaseID(String runID, String caseID) {
        Response response = SerenityRest.given()
                .baseUri(Configuration.get("testRail.url"))
                .headers(setContentTypeHeader())
                .auth().preemptive().basic(Configuration.get("testRail.username"), Configuration.get("testRail.password"))
                .when()
                .get(URI_GET_RESULT_FOR_CASEID + runID + "/" + caseID);
        if (response.statusCode() == STATUS_CODE_200I) {
            int size = response.then().extract().response().path("size");
            if (size == 0) {
                //TestRail status 3:Untested
                return "3";
            } else {
                List<Integer> allResultStatus = response.then()
                        .extract().response().path("results.status_id");
                return String.valueOf(allResultStatus.get(0));
            }
        } else {
            return "Field :case_id is not a valid test case.";
        }
    }


    private  Map<String, Integer> getPostPayload(int statusID) {
        Map<String, Integer> result = new HashMap<>();
        result.put("status_id", statusID);
        return result;
    }

    private Response postTestRailStatusForCaseID(String runID, String caseID, int actualStatusID) {
        return SerenityRest.given()
                .baseUri(Configuration.get("testRail.url"))
                .headers(setContentTypeHeader())
                .auth().preemptive().basic(Configuration.get("testRail.username"), Configuration.get("testRail.password"))
                .body(getPostPayload(actualStatusID))
                .when()
                .post(URI_ADD_RESULT_FOR_CASEID + runID + "/" + caseID);
    }

    public void updateResultInTestRail(Scenario scenario) {
        /*status_id:
        1:Passed
        2:Blocked
        3:Untested(can not update this status, request will fail)
        4:Retest
        5:failed*/
        int actualStatusID;
        if (scenario.isFailed()) {
            actualStatusID = 4;
        } else {
            actualStatusID = 1;
        }

        //Fetching CaseIds from tags
        ArrayList<String> caseIds = new ArrayList<String>();
        for (String tags : scenario.getSourceTagNames()) {
            if (tags.matches("^@C\\d+$")) {
                caseIds.add(StringUtils.trim(tags.replace("@C", "")));
            }
        }

        //update TestRail for each tag of the scenario only when its not passed already
        String runID = Configuration.get("testRail.runId");
        SoftAssertions softAssert = new SoftAssertions();
        for (String caseId : caseIds) {
            String currentStatus = getTestRailStatusForCaseID(runID, caseId);
            if (!"1".equals(currentStatus)) {
                Response postResponse = postTestRailStatusForCaseID(runID, caseId, actualStatusID);
                if (postResponse.statusCode() == STATUS_CODE_200I) {
                    int postResponseStatusID = postResponse.then().extract().path("status_id");
                    if (postResponseStatusID == actualStatusID) {
                        LOGGER.info("TestRail successfully updated for caseID:" + caseId);
                    } else {
                        LOGGER.error("TestRail status wrongly updated for caseID:" + caseId);
                    }
                } else {
                    LOGGER.error("TestRail update failed for caseID:" + caseId + " status code: "
                            + postResponse.statusCode());
                }
            }
        }
        softAssert.assertAll();
    }
}

package gbs.api.test.common;

import gbs.api.test.utils.Constants;
import gbs.api.test.utils.SSOToken;
import gbs.api.test.utils.SessionKeys;
import gbs.api.test.utils.TestDataReader;

import gbs.api.test.verify.GenericRestVerify;
import net.thucydides.core.annotations.Steps;
import gbs.api.test.utils.Configuration;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;

import io.restassured.response.Response;

public class CommonActions {

    @Steps
    private SessionKeys sessionKeys;

    @Steps
    private GenericRestVerify genericRestVerify;

    public String getApiUrl() {
        return Configuration.get("api.url");
    }

    public String getRandomNumber(int numOfDigits) {
        int number = (int) Math.pow(10, numOfDigits - 1);
        return String.valueOf(number + new Random().nextInt(9 * number));
    }

    //mac id format: 101.121.130.112
    public String getRandomMacId(int numOfDigits) {
        return getRandomNumber(3) + "."
                + getRandomNumber(3) + "."
                + getRandomNumber(3) + "."
                + getRandomNumber(3);
    }

    public Map<String, String> setContentTypeHeader() {
        Map<String, String> headersMap = new HashMap<String, String>();
        headersMap.put("Content-Type", Constants.APPLICATION_JSON);
        return headersMap;
    }

    public Map<String, String> setAcceptHeader() {
        Map<String, String> headersMap = new HashMap<String, String>();
        headersMap.put("accept", Constants.APPLICATION_JSON);
        return headersMap;
    }

    public Map<String, String> setApiKeyAndBearerTokenHeaders() {
        Map<String, String> headersMap = new HashMap<String, String>();
        headersMap.put("apiKey", Configuration.get("apiKey"));
        headersMap.put("Authorization", "Bearer " + Configuration.get("bearerToken"));
        return headersMap;
    }

    public Map<String, String> setShopIdTerminalIdBrandHeaders(Map<String, String> requestValues) {
        Map<String, String> headersMap = new HashMap<String, String>();
        if (requestValues.containsKey("shopId")) {
            headersMap.put("shopId", getShopID(requestValues.get("shopId")));
        }
        if (requestValues.containsKey("terminalId")) {
            headersMap.put("terminalId", getTerminalID(requestValues.get("terminalId")));
        }
        if (requestValues.containsKey("brandId")) {
            headersMap.put("brandId", getBrandName(requestValues.get("brandId")));
        } else if (requestValues.containsKey("brand")) {
            headersMap.put("brand", getBrandName(requestValues.get("brand")));
        } else {
            headersMap.put("brandName", getBrandName(requestValues.get("brandName")));
        }
        return headersMap;
    }

    public Map<String, String> setPageAndSizeHeaders(Map<String, String> requestValues) {
        Map<String, String> headersMap = new HashMap<String, String>();
        if (requestValues.containsKey("size")) {
            headersMap.put("size", requestValues.get("size"));
        }
        if (requestValues.containsKey("page")) {
            headersMap.put("page", requestValues.get("page"));
        }
        return headersMap;
    }

    public Map<String, String> setAccountNameSourceHeaders(Map<String, String> requestValues) {
        Map<String, String> headersMap = new HashMap<String, String>();
        headersMap.put("accountName", getAccountName(requestValues.get("accountName")));
        headersMap.put("source", requestValues.get("source"));
        return headersMap;
    }

    public Map<String, String> setSSOTokenHeaders(Map<String, String> requestValues) {
        Map<String, String> headersMap = new HashMap<String, String>();
        String shopId;
        String terminalId;
        if (requestValues.containsKey("shopId") && requestValues.containsKey("terminalId")) {
            shopId = getShopID(requestValues.get("shopId"));
            terminalId = getTerminalID(requestValues.get("terminalId"));
        } else {
            shopId = this.getShopID("Invalid");
            terminalId = this.getTerminalID("Invalid");
        }
        String ssoToken = requestValues.get("ssoToken");
        if ((!shopId.equals(requestValues.get("valid")) || !terminalId.equals(getTerminalID("valid")))
                && "valid".equalsIgnoreCase(ssoToken)) {
            headersMap.put("sessionKey", generateSSOTokenForShop(shopId, terminalId));
        } else {
            headersMap.put("sessionKey", getSessionToken(ssoToken));
        }
        return headersMap;
    }

    public Map<String, String> setUserIdHeader(Map<String, String> requestvalues) {
        Map<String, String> headersMap = new HashMap<>();
        headersMap.put("userId", getUserId(requestvalues.get("userId")));
        return headersMap;
    }

    public String getUserName() {
        return Configuration.get("userName");
    }

    public List<String> getDoNotDeleteShops() {
        List<String> doNotDeleteShopIds = new ArrayList<>(
                Arrays.asList(Configuration.get("doNotDeleteShops").split(",")))
                .stream().map(shop -> shop.trim()).collect(Collectors.toList());
        return doNotDeleteShopIds;
    }

    public List<String> getDoNotDeleteTerminals() {
        List<String> doNotDeleteTerminalIds = new ArrayList<>(
                Arrays.asList(Configuration.get("doNotDeleteTerminals").split(",")))
                .stream().map(shop -> shop.trim()).collect(Collectors.toList());
        return doNotDeleteTerminalIds;
    }

    public List<String> getCountries() {
        List<String> countries = new ArrayList<>(
                Arrays.asList(Configuration.get("countries").split(",")))
                .stream().map(shop -> shop.trim()).collect(Collectors.toList());
        return countries;
    }
    public List<String> getRegionAreaCodes() {
        List<String> regionAreaCodes = new ArrayList<>(
                Arrays.asList(Configuration.get("regionAreaCodes").split(",")))
                .stream().map(shop -> shop.trim()).collect(Collectors.toList());
        return regionAreaCodes;
    }
    public List<String> getRegions() {
        List<String> regions = new ArrayList<>(
                Arrays.asList(Configuration.get("regions").split(",")))
                .stream().map(shop -> shop.trim()).collect(Collectors.toList());
        return regions;
    }

    public String getShopID(String featureFileShopIDValue) {
        switch (featureFileShopIDValue.toLowerCase()) {
            case "valid":
                return Configuration.get("shopId").trim();
            case "noShopsBrandName":
                return Configuration.get("noShopsBrandName");
            case "invalid3":
                return getRandomNumber(3);
            case "invalid":
                return getRandomNumber(4);
            case "invalid5":
                return getRandomNumber(5);
            case "random":
                String shopID = getRandomNumber(4);
                sessionKeys.setData(SessionKeys.DataKeys.SHOP_ID, shopID);
                return shopID;
            case "existing":
                return sessionKeys.getData(SessionKeys.DataKeys.NEW_SHOP_CREATED);
            default:
                return featureFileShopIDValue;

        }
    }

    public String getBrandName(String featureFileBrandValue) {
        switch (featureFileBrandValue.toLowerCase()) {
            case "valid":
                return Configuration.get("brandName").trim();
            case "invalid":
                return "LADABCDE";
            case "noshopsbrandname":
                return Configuration.get("noShopsBrandName");
            default:
                return featureFileBrandValue;
        }
    }

    public String getCurrency(String featureFileCurrencyValue) {
        switch (featureFileCurrencyValue.toLowerCase()) {
            case "valid":
                return Configuration.get("currency").trim();
            case "europeancountrycurrency":
                return Configuration.get("europeanCountryCurrency").trim();
            case "invalid":
                return "INRR";
            default:
                return featureFileCurrencyValue;
        }
    }

    public String getTerminalID(String featureFileTerminalIDValue) {
        switch (featureFileTerminalIDValue.toLowerCase()) {
            case "valid":
                return Configuration.get("terminalId").trim();
            case "crossterminalid":
                return Configuration.get("crossTerminalID").trim();
            case "invalid":
                return getRandomNumber(1);
            case "terminalWithSymbols":
                return "@1";
            case "terminalStartingWithZero":
                return "0" + getRandomNumber(1);
            case "invalid3":
                return getRandomNumber(3);
            case "random":
                String terminalID = getRandomNumber(2);
                sessionKeys.setData(SessionKeys.DataKeys.TERMINAL_ID, terminalID);
                return terminalID;
            case "existing":
                return sessionKeys.getData(SessionKeys.DataKeys.NEW_TERMINAL_CREATED);
            case "newlycreatedterminalid":
                return Configuration.get("newlyCreatedTerminalId");
            default:
                return featureFileTerminalIDValue;
        }
    }

    public String getAccountName(String featureFileAccountNameValue) {
        switch (featureFileAccountNameValue.toLowerCase()) {
            case "valid":
                return Configuration.get("accountName");
            case "crossaccountname":
                return Configuration.get("crossAccountName");
            case "invalid":
                return "GBS_Back";
            default:
                return featureFileAccountNameValue;
        }
    }

    public void storeResponseToTestSession(Response response) {
        sessionKeys.setData(SessionKeys.DataKeys.RESPONSE, response);
    }

    public Response getResponseFromTestSession() {
        return sessionKeys.getData(SessionKeys.DataKeys.RESPONSE);
    }

    public void rememberResponseEntityValueToSession(Response response, String pojoName,
                                                     String fieldName, String sessionKey) {
        Object value = genericRestVerify.getValueForEntity(response, pojoName, fieldName);
        sessionKeys.setData(SessionKeys.DataKeys.valueOf(sessionKey), value);
    }

    public void rememberValueToSession(Object value, String sessionKey) {
        sessionKeys.setData(SessionKeys.DataKeys.valueOf(sessionKey), value);
    }

    public String getSessionToken(String featureFileSSOValue) {

        switch (featureFileSSOValue.toLowerCase().trim()) {
            case "valid":
                return generateSSOTokenForShop(Configuration.get("shopId"), Configuration.get("terminalId"));
            case "expired":
                return TestDataReader.getFieldValueFromTestDataJson("expiredSSOToken".trim(), "BetIds");
            case "invalid":
                return getRandomMacId(7);
            default:
                return featureFileSSOValue;
        }
    }

    public String generateSSOTokenForShop(String shopId, String terminalId) {
        if (shopId.length() == 4 && terminalId.length() == 2) {
            return SSOToken.tokenInstance(shopId, terminalId).getToken();
        } else {
            return this.getSessionToken("Invalid");
        }
    }

    public String generateAccountName(String shopID, String terminalID) {
        String prefixAccountName = Configuration.get("prefixAccountName");
        return prefixAccountName + shopID + "_" + terminalID;
    }

    public String getUserId(String featureUserId) {
        switch (featureUserId.trim().toLowerCase()) {
            case "valid":
                return Configuration.get("userId");
            case "invalid":
                return "user123";
            default:
                return featureUserId;
        }
    }

    public long generateTimeStamp() {
        return LocalDateTime.now(ZoneOffset.UTC).toEpochSecond(ZoneOffset.UTC);
    }

    public String generateRandomAlphaNumericNumber(int count) {
        SecureRandom secureRandom = new SecureRandom();
        byte[] token = new byte[count];
        secureRandom.nextBytes(token);
        return new BigInteger(1, token).toString(16); // Hexadecimal encoding
    }

    public String getCurrentDateInUTC() {
        Date today = new Date();
        SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:sssZ");
        formatDate.setTimeZone(TimeZone.getTimeZone("UTC"));
        return formatDate.format(today);
    }

}

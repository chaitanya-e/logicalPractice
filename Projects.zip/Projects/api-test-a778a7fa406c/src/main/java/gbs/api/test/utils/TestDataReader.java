package gbs.api.test.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import gbs.api.test.response.ResponseEntity;
import gbs.api.test.response.ResponsePojosDictionary;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestDataReader {

    private static ResponseEntity readJsonFile(String fileName) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        BufferedReader bufferReader = null;
        String filePath = Configuration.get("testDataFilesPath") + fileName + ".json";
        Class<? extends ResponseEntity> clazz =
                ResponsePojosDictionary.getPojoClass(fileName);
        try {
            bufferReader = new BufferedReader(new FileReader(filePath));
            return gson.fromJson(bufferReader, clazz);
        } catch (FileNotFoundException e) {
            throw new RuntimeException("Test Data Json file not found");
        } finally {
            try {
                if (bufferReader != null) {
                    bufferReader.close();
                }
            } catch (IOException ignore) { }
        }
    }

    public static String  getFieldValueFromTestDataJson(String fieldName, String fileName) {
        Object data = readJsonFile(fileName).getValue(fieldName);
        return String.valueOf(data).trim();
    }
}

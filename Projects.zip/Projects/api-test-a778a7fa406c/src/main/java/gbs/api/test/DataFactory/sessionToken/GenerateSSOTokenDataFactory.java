package gbs.api.test.DataFactory.sessionToken;

import gbs.api.test.request.sessionToken.SSOTokenRequest;
import gbs.api.test.utils.Configuration;

public class GenerateSSOTokenDataFactory {

    public static SSOTokenRequest sessionTokenPayload(String shopId, String terminalId) {
        String userName = "shop_" + shopId + "_" + terminalId;

        return SSOTokenRequest.builder()
                .username(userName)
                .password(Configuration.get("sessionToken.password"))
                .language("EN")
                .loginType("anonymous")
                .build();
    }
}

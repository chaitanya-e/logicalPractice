package gbs.api.test.steps.orchestration.funds;

import gbs.api.test.DataFactory.orchestration.funds.AddFundsDataFactory;
import gbs.api.test.common.CommonActions;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.*;

public class FundSteps extends CommonActions {

    @Steps
    private AddFundsDataFactory addFundsDataFactory;

    public void getFundsGetRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(setAccountNameSourceHeaders(requestValues.get(0)))
                .headers(setSSOTokenHeaders(requestValues.get(0)))
                .when()
                .get(getApiUrl() + ORCHESTRATOR + FUNDS);
        storeResponseToTestSession(response);
    }

    public void addAmtToTerminalPostRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(setAccountNameSourceHeaders(requestValues.get(0)))
                .headers(setSSOTokenHeaders(requestValues.get(0)))
                .body(addFundsDataFactory.generateAddAmountPayload(requestValues.get(0)))
                .when()
                .post(getApiUrl() + ORCHESTRATOR + FUNDS);
        storeResponseToTestSession(response);
    }

    public void performCashUpToTerminalPostRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setAcceptHeader())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .body(addFundsDataFactory.postCashUpPayload(requestValues.get(0)))
                .when()
                .post(getApiUrl() + ORCHESTRATOR + FUNDS + "/" + CASH_UP);
        storeResponseToTestSession(response);
    }
}

package gbs.api.test.utils;


import gbs.api.test.DataFactory.sessionToken.GenerateSSOTokenDataFactory;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

public class SSOToken {

    private static List<SSOToken> ssoTokensList = new ArrayList<>();
    public static List<SSOToken> requiredToken;
    public String shopId;
    public String terminalId;
    public String token;

    private SSOToken(String shopId, String terminalId, String token) {
        this.shopId = shopId;
        this.terminalId = terminalId;
        this.token = token;
    }

    public static SSOToken tokenInstance(String shopId, String terminalId) {
        if (isRequiredInstanceExistsInList(shopId, terminalId)) {
            return requiredToken.get(requiredToken.size() - 1);
        } else {
            SSOToken ssoToken = new SSOToken(shopId, terminalId, generateToken(shopId, terminalId));
            ssoTokensList.add(ssoToken);
            return ssoToken;
        }

    }

    public String getToken() {
        return this.token;
    }

    private static boolean isRequiredInstanceExistsInList(String newShopId, String newTerminalId) {
        if (ssoTokensList.size() > 0) {
            requiredToken = ssoTokensList.stream().filter(existingInstance ->
                existingInstance.shopId.equals(newShopId) && existingInstance.terminalId.equals(newTerminalId)
            ).collect(Collectors.toList());

            return requiredToken.size() > 0;
        }
        return false;
    }

    private static String generateToken(String shopId, String terminalId) {
        Response response = SerenityRest.given()
                .headers(setSessionTokenHeaders())
                .body(GenerateSSOTokenDataFactory.sessionTokenPayload(shopId, terminalId))
                .when()
                .post(getSessionTokenApiUrl());

        assertThat(response.statusCode())
                .as("Session token request is not successful")
                .isEqualTo(200);

        return response.then().extract().path("ssoToken");
    }

    private static String getSessionTokenApiUrl() {
        return Configuration.get("sessionToken.api.url");
    }

    private static Map<String, String> setSessionTokenHeaders() {
        Map<String, String> headersMap = new HashMap<String, String>();
        headersMap.put("x-bwin-accessId", Configuration.get("x.bwin.accessId"));
        headersMap.put("Content-Type", Constants.APPLICATION_JSON);
        headersMap.put("Accept", Constants.APPLICATION_JSON);
        return headersMap;
    }

}

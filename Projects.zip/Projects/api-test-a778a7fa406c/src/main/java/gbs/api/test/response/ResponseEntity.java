package gbs.api.test.response;

import java.lang.reflect.Field;
import java.util.List;
import org.slf4j.LoggerFactory;

public class ResponseEntity {

    private String pojoName;
    private Class<? extends ResponseEntity> clazz;

    public ResponseEntity() { }

    public ResponseEntity(final String pojoName, final Class<? extends ResponseEntity> clazz) {
        this.pojoName = pojoName;
        this.clazz = clazz;
    }

    public String getPojoName() {
        return pojoName;
    }

    public Class<? extends ResponseEntity> getPojoClassName() {
        return clazz;
    }

    public Object getValue(final String elementName) {
        return getValueFromElement(elementName, Object.class);
    }

    @SuppressWarnings("unchecked")
    public <T> List<T> getList(final String elementName) {
        return getValueFromElement(elementName, List.class);
    }

    public <T> T getValueFromElement(final String entity, final Class<T> elementType) {
        Class<?> clazz = this.getClass();
        try {
            if (elementType.isAssignableFrom(clazz.getDeclaredField(entity).getType())) {
                Field requestedField = clazz.getDeclaredField(entity);
                return getEntityFromField(requestedField);
            } else {
                throw new RuntimeException(
                        String.format("Field %s has incorrect type (expected type is %s or child type(s))", entity,
                                elementType.getName()));
            }
        } catch (final NoSuchFieldException e) {
            LoggerFactory.getLogger(ResponseEntity.class).debug("Required field not found", e);
            throw new RuntimeException(String.format("Element with name '%s' was not found for entity %s", entity,
                    this.getClass().getName()));
        }
    }

    @SuppressWarnings("unchecked")
    public <T> T getEntityFromField(final Field requestedField) {
        requestedField.setAccessible(true);
        try {
            return (T) requestedField.get(this);
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Requested field not found ");
        }
    }
}

package gbs.api.test.DataFactory.inventory.shop;

import gbs.api.test.common.CommonActions;
import gbs.api.test.request.inventory.shop.AddShopRequest;
import gbs.api.test.utils.Configuration;
import net.thucydides.core.annotations.Steps;

import java.util.Map;

public class AddShopDataFactory {

    @Steps
    private CommonActions commonActions;

    public AddShopRequest generateAddShopPayload(Map<String, String> requestValues, String shopID) {
        String brandName = commonActions.getBrandName(requestValues.get("brandName"));
        String currency = commonActions.getCurrency(requestValues.get("currencyCode"));
        String country = requestValues.get("country");
        Object validated = requestValues.get("validated");
        String regionCode = requestValues.get("regionCode");

        if ("true".equalsIgnoreCase(requestValues.get("validated")) || "false".equalsIgnoreCase(requestValues.get("validated"))) {
            validated = Boolean.parseBoolean(requestValues.get("validated"));
        }

        if ("valid".equalsIgnoreCase(requestValues.get("country"))) {
            country = Configuration.get("country").trim();
        }

        if ("ERRegionCode".equalsIgnoreCase(regionCode)) {
            regionCode = Configuration.get("ERRegionCode").trim();
        } else if ("LNRegionCode".equalsIgnoreCase(regionCode)) {
            regionCode = Configuration.get("LNRegionCode").trim();
        }

        return AddShopRequest.builder()
                .brandName(brandName)
                .businessUnit(requestValues.get("businessUnit"))
                .country(country)
                .currencyCode(currency)
                .defaultGateway(requestValues.get("defaultGateway") + "_Automation")
                .locale(requestValues.get("locale"))
                .regionAreaCode(requestValues.get("regionAreaCode"))
                .regionCode(regionCode)
                .shopId(shopID)
                .subRegionCode(requestValues.get("subRegionCode"))
                .timeZone(requestValues.get("timeZone"))
                .validated(validated)
                .build();
    }
}

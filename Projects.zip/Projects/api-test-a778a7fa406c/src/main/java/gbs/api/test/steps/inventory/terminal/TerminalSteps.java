package gbs.api.test.steps.inventory.terminal;

import gbs.api.test.DataFactory.inventory.terminal.AddTerminalDataFactory;
import gbs.api.test.common.CommonActions;
import gbs.api.test.utils.SessionKeys;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.*;

public class TerminalSteps extends CommonActions {

    private static final Logger LOGGER = LoggerFactory.getLogger(TerminalSteps.class);

    @Steps
    private AddTerminalDataFactory addTerminalDataFactory;

    @Steps
    private SessionKeys sessionKeys;

    public void addTerminalPostRequest(List<Map<String, String>> requestValues) {
        String terminalID = getTerminalID(requestValues.get(0).get("terminalId"));
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .body(addTerminalDataFactory.generateAddTerminalPayload(requestValues.get(0), terminalID))
                .when()
                .post(getApiUrl() + INVENTORY + ADD_TERMINAL);
        storeResponseToTestSession(response);
        if (response.statusCode() == 201) {
            sessionKeys.setData(SessionKeys.DataKeys.NEW_TERMINAL_CREATED, terminalID);
            LOGGER.info("Created the Terminal: " + terminalID + " for the shopId: "
                    + getShopID(requestValues.get(0).get("shopId")));
        }
    }

    public void terminalStatusPostRequest(List<Map<String, String>> requestValues) {
        String terminalID = getTerminalID(requestValues.get(0).get("terminalId"));
        String shopID = getShopID(requestValues.get(0).get("shopId")) + "/";
        String brand = getBrandName(requestValues.get(0).get("brand")) + "/";
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .body(addTerminalDataFactory.generateAddTerminalStatusPayload(requestValues.get(0).get("lockStatus")))
                .when()
                .post(getApiUrl() + TERMINAL_STATUS + STATUS + brand + shopID + terminalID);
        storeResponseToTestSession(response);
    }

    public void modifyTerminalPutRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .body(addTerminalDataFactory.generateUpdateTerminalPayload(requestValues.get(0)))
                .when()
                .put(getApiUrl() + INVENTORY + TERMINAL
                        + getShopID(requestValues.get(0).get("shopId")) + "/"
                        + getTerminalID(requestValues.get(0).get("terminalId")) + "/"
                        + getBrandName(requestValues.get(0).get("brandName")));
        storeResponseToTestSession(response);
    }

    public void modifyTerminalWithStatusPutRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .body(addTerminalDataFactory.generateUpdateTerminalStatusPayload(requestValues.get(0)))
                .when()
                .post(getApiUrl()  + TERMINAL_STATUS + STATUS
                        + getBrandName(requestValues.get(0).get("brandName")) + "/"
                        + getShopID(requestValues.get(0).get("shopId")) + "/"
                        + getTerminalID(requestValues.get(0).get("terminalId")));

        storeResponseToTestSession(response);
    }

    public void deleteTerminalDeleteRequest(List<Map<String, String>> requestValues) {

//        List<String> doNotDeleteShopIds = getDoNotDeleteShops();
//        if (shopID.equals(getShopID("valid")) || doNotDeleteShopIds.contains(shopID)) {
//            throw new RuntimeException("We cannot delete automation Terminal. "
//                    + "For testing purpose create a new shop and Terminal then delete ");
//        }

        String shopID = getShopID(requestValues.get(0).get("shopId"));
        String terminalID = getTerminalID(requestValues.get(0).get("terminalId"));
        List<String> doNotDeleteTerminalIds = getDoNotDeleteTerminals();
        if (terminalID.equals(getTerminalID("valid")) || doNotDeleteTerminalIds.contains(terminalID)) {
            throw new RuntimeException("We cannot delete automation customer account. create a new customer "
                    + "for new shop and delete for testing");
        }


        boolean cascade = Boolean.parseBoolean(requestValues.get(0).get("cascade"));
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .delete(getApiUrl() + INVENTORY + TERMINAL
                        + shopID + "/"
                        + terminalID + "/"
                        + getBrandName(requestValues.get(0).get("brandName")) + "/"
                        + cascade);
        storeResponseToTestSession(response);
        if (response.statusCode() == 200) {
            LOGGER.info("Deleted the Terminal: " + terminalID + " for the shopId: " + shopID);
        }
    }

    public void getAllTerminalsWithBrand(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .get(getApiUrl() + INVENTORY + TERMINAL + BRAND
                        + getBrandName(requestValues.get(0).get("brandName")));
        storeResponseToTestSession(response);
    }

    public void getAllTerminalsWithStatus(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .get(getApiUrl() + INVENTORY + TERMINAL + STATUS
                        + getShopID(requestValues.get(0).get("shopId")) + "/"
                        + getBrandName(requestValues.get(0).get("brandName")));
        storeResponseToTestSession(response);
    }

    public void getAllTerminalsWithMacId(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .get(getApiUrl() + INVENTORY + TERMINAL
                        + addTerminalDataFactory.getMacID(requestValues.get(0).get("macId")));
        storeResponseToTestSession(response);
    }

    public void getAllTerminalsWithShopId(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .get(getApiUrl() + INVENTORY + TERMINAL
                        + getShopID(requestValues.get(0).get("shopId")) + "/"
                        + getBrandName(requestValues.get(0).get("brandName")));
        storeResponseToTestSession(response);
    }

    public void getAllTerminalsWithShopTerminalIdAndBrand(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .get(getApiUrl() + INVENTORY + TERMINAL
                        + getShopID(requestValues.get(0).get("shopId")) + "/"
                        + getTerminalID(requestValues.get(0).get("terminalId")) + "/"
                        + getBrandName(requestValues.get(0).get("brandName")));
        storeResponseToTestSession(response);
    }
}


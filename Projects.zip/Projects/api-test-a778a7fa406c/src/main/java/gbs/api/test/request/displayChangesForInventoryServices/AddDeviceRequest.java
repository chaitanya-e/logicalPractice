package gbs.api.test.request.displayChangesForInventoryServices;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder

public class AddDeviceRequest {
    private String brandName;
    private String deviceId;
    private String deviceName;
    private String hostname;
    private Integer outputCount;
    private String screenGroupName;
    private String shopId;
}

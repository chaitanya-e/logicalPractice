package gbs.api.test.steps.auditManagement.shopData;

import gbs.api.test.DataFactory.auditManagement.shopData.BOGloblaViewDataFactory;
import gbs.api.test.common.CommonActions;
import gbs.api.test.verify.GenericRestVerify;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.*;
import static org.assertj.core.api.Assertions.assertThat;

public class AuditManagementBOGlobalViewSteps extends CommonActions {
    @Steps
    private CommonActions commonActions;
    @Steps
    private BOGloblaViewDataFactory bOGloblaViewDataFactory;
    @Steps
    private GenericRestVerify genericRestVerify;

    public void getFilteredBOGlobalViewData(List<Map<String, String>> requestValues) {
        Response response;
        if (requestValues.get(0).get("response").equalsIgnoreCase("valid")) {
            response = SerenityRest.given()
                    .headers(setApiKeyAndBearerTokenHeaders())
                    .headers(setContentTypeHeader())
                    .headers(setAcceptHeader())
                    .body(bOGloblaViewDataFactory.getFilteredBOGlobalViewData(requestValues.get(0)))
                    .when()
                    .post(getApiUrl() + AUDIT + GLOBAL_VIEW + VIEW_AUDIT_DATA);
        } else {
            response = SerenityRest.given()
                    .headers(setContentTypeHeader())
                    .headers(setAcceptHeader())
                    .body(bOGloblaViewDataFactory.getFilteredBOGlobalViewData(requestValues.get(0)))
                    .when()
                    .post(getApiUrl() + AUDIT + GLOBAL_VIEW + VIEW_AUDIT_DATA);
        }
        storeResponseToTestSession(response);
    }

    public void verifyFilteredData(Map<String, String> requestValues) {
        String filteredData = genericRestVerify.getResponseAsRawString(commonActions.getResponseFromTestSession());
        String brand = commonActions.getBrandName(requestValues.get("brand"));
        String coral = "\"brand\":\"CORAL\"";
        String ladBrokes = "\"brand\":\"LADBROKEUK\"";
        if ("CORAL".equalsIgnoreCase(brand)) {
            assertThat(filteredData).containsIgnoringCase(coral);
            assertThat(filteredData).doesNotContain(ladBrokes);
        } else {
            assertThat(filteredData).containsIgnoringCase(ladBrokes);
            assertThat(filteredData).doesNotContain(coral);
        }
    }

    public void getFilteredBOGlobalViewTypeHeadSearchData(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setContentTypeHeader())
                .headers(setAcceptHeader())
                .queryParam("searchKey", requestValues.get(0).get("searchKey"))
                .queryParam("searchValue", requestValues.get(0).get("searchValue"))
                .queryParam("size", requestValues.get(0).get("size"))
                .when()
                .get(getApiUrl() + AUDIT + GLOBAL_VIEW + TYPE_HEAD_SEARCH);

        storeResponseToTestSession(response);
    }

}

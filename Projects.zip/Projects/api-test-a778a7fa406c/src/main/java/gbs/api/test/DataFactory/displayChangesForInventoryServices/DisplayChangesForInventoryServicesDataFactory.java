package gbs.api.test.DataFactory.displayChangesForInventoryServices;

import gbs.api.test.common.CommonActions;
import gbs.api.test.request.displayChangesForInventoryServices.AddDeviceDecoderMappingRequest;
import gbs.api.test.request.displayChangesForInventoryServices.AddDeviceRequest;
import gbs.api.test.request.displayChangesForInventoryServices.AddScreenGroupRequest;
import gbs.api.test.request.displayChangesForInventoryServices.AddTVDecoderRequest;
import gbs.api.test.utils.Configuration;
import net.thucydides.core.annotations.Steps;

import java.util.Map;

public class DisplayChangesForInventoryServicesDataFactory {

    @Steps
    private CommonActions commonActions;

    private String screenGroupName = "";

    public String generateScreenGroupName(Map<String, String> requestValues) {
        if ("valid" .equalsIgnoreCase(requestValues.get("screenGroupName"))) {
            return commonActions.getBrandName(requestValues.get("brandName")) + "_" + commonActions.getShopID(requestValues.get("shopId")) + "_ScreenGroup_02";
        } else {
            return requestValues.get("screenGroupName");
        }
    }

    public String generateTVDecoderID(Map<String, String> requestValues) {
        if ("valid" .equalsIgnoreCase(requestValues.get("tvDecoderId"))) {
            return commonActions.getBrandName(requestValues.get("brandName")) + "_" + commonActions.getShopID(requestValues.get("shopId")) + "_tvDecoderId_02";
        } else {
            return requestValues.get("generateTVDecoderID");
        }
    }

    public String getDeviceID(Map<String, String> requestValues) {
        if ("valid" .equalsIgnoreCase(requestValues.get("deviceId"))) {
            return Configuration.get("deviceId");
        } else {
            return requestValues.get("deviceId");
        }
    }

    public AddDeviceRequest generateAddDevicePayload(Map<String, String> requestValues) {
        return AddDeviceRequest.builder()
                .brandName(commonActions.getBrandName(requestValues.get("brandName")))
                .deviceId(getDeviceID(requestValues))
                .deviceName(requestValues.get("deviceName"))
                .hostname(requestValues.get("hostName"))
                .outputCount(Integer.valueOf(requestValues.get("outputCount")))
                .screenGroupName(generateScreenGroupName(requestValues))
                .shopId(commonActions.getShopID(requestValues.get("shopId")))
                .build();
    }

    public AddDeviceDecoderMappingRequest generateDeviceDecoderMappingPayload(Map<String, String> requestValues) {
        return AddDeviceDecoderMappingRequest.builder()
                .brand(commonActions.getBrandName(requestValues.get("brandName")))
                .deviceId(getDeviceID(requestValues))
                .shopId(commonActions.getShopID(requestValues.get("shopId")))
                .tvDecoderId(generateTVDecoderID(requestValues))
                .build();
    }

    public AddScreenGroupRequest generateScreenGroupPayload(Map<String, String> requestValues) {
        return AddScreenGroupRequest.builder()
                .brand(commonActions.getBrandName(requestValues.get("brandName")))
                .screenCount(Integer.valueOf(requestValues.get("screenCount")))
                .screenGroupName(generateScreenGroupName(requestValues))
                .shopId(commonActions.getShopID(requestValues.get("shopId")))
                .build();
    }

    public AddTVDecoderRequest generateAddTVDecoderPayload(Map<String, String> requestValues) {
        return AddTVDecoderRequest.builder()
                .brandName(commonActions.getBrandName(requestValues.get("brandName")))
                .ipAddress(requestValues.get("ipAddress"))
                .name(requestValues.get("name"))
                .shopId(commonActions.getShopID(requestValues.get("shopId")))
                .tvDecoderId(generateTVDecoderID(requestValues))
                .build();
    }
}

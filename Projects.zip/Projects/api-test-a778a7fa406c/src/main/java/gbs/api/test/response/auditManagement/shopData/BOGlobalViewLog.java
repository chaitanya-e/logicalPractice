package gbs.api.test.response.auditManagement.shopData;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)


public class BOGlobalViewLog extends ResponseEntity {

    private String message;
    private String category;
    private String timestamp;
    private String transactionType;
    private String operation;
    private String status;
    private String id;
    private String currency;
    private String value;
    private String shopId;
    private String terminalId;
    private String brand;
    private String userId;
    private String userName;
    private String level;
    private String transactionId;
    private String source;
    private String betSlipType;
    private String betSlipStatus;
    private String betSlipPayoutStatus;
    private String ticketType;
    private String amlDecisionStatus;
    private String errorCode;
    private String errorMessage;
    private String errorDescription;
    private String backendProcessingTime;
    private String totalProcessingTime;
    private String country;
    private String regionCode;
    private String regionAreaCode;

}

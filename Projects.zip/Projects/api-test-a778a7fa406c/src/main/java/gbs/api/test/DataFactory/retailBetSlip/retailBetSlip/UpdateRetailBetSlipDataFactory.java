package gbs.api.test.DataFactory.retailBetSlip.retailBetSlip;

import gbs.api.test.common.CommonActions;
import gbs.api.test.request.retailBetSlip.retailBetSlip.UpdateRBSRequest;
import net.thucydides.core.annotations.Steps;

import java.util.Map;

public class UpdateRetailBetSlipDataFactory {

    @Steps
    private CommonActions commonActions;
    private String transactionId;

    public UpdateRBSRequest updateRBSPayload(Map<String, String> requestValues) {

        transactionId = requestValues.get("transactionId");

        if ("valid".equalsIgnoreCase(transactionId)) {
            transactionId = commonActions.getRandomNumber(8);
        }

        return UpdateRBSRequest.builder()
                .amlDecisionStatus(requestValues.get("amlDecisionStatus"))
                .comments(requestValues.get("comments"))
                .lockingReason("lockingReason")
                .timestamp(requestValues.get("timeStamp"))
                .transactionId(transactionId)
                .userId(requestValues.get("userId"))
                .userName(requestValues.get("userName"))
                .build();
    }

}

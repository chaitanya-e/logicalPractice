package gbs.api.test.response.retailBetSlip;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetRBSDetailsResponse extends ResponseEntity {

    public String receiptNumber;
    public String slipType;
    public String status;
    public Integer betPlacedOn;
    public Integer noOfSelections;
    public String currencyCode;
    public Integer totalStake;
    public Integer maxRegularReturn;
    public Integer settledReturn;
    public Boolean isEarlyPayout;
    public Object totalOdds;
    public Integer customerId;
    public String accountName;
    public Integer winReturns;
    public Integer voidReturns;
    public String systemType;
    public Object freeBetInformation;
    public String transactionType;
    public Object subTransactionType;
    public Integer value;
    public Object userName;
    public String brand;
    public Integer winPaid;
    public Integer voidPaid;
    public Object payoutTimeStamp;
    public Object payoutShopId;
    public Object payoutTerminalId;
    public Object payoutBrand;
    public Object userNamePayout;
    public Object userIdPayout;
    public String payoutStatus;
    public String placementShopId;
    public String placementTerminalId;
    public String retailReceiptNo;
    public Object amlResponse;
    public Object crmPromoToken;
}

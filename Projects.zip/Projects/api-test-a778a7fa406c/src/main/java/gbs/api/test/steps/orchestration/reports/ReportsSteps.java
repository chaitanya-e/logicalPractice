package gbs.api.test.steps.orchestration.reports;

import gbs.api.test.common.CommonActions;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;

import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.*;

public class ReportsSteps extends CommonActions {

    public void getReportsGetRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .when()
                .get(getApiUrl() + ORCHESTRATOR + REPORTS + HIGH_MLC);
        storeResponseToTestSession(response);
    }
}

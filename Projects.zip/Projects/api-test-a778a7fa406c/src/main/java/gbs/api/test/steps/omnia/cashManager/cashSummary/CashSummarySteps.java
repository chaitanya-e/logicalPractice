package gbs.api.test.steps.omnia.cashManager.cashSummary;

import gbs.api.test.common.CommonActions;
import gbs.api.test.utils.SessionKeys;
import gbs.api.test.verify.GenericRestVerify;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.*;

public class CashSummarySteps extends CommonActions {

    @Steps
    private SessionKeys sessionKeys;

    @Steps
    private GenericRestVerify genericRestVerify;

    private String terminalId;

    public void getCashSummaryDetailsGetRequest(List<Map<String, String>> requestValues) {

        if (requestValues.get(0).containsKey("terminalId")) {
            terminalId = getTerminalID(requestValues.get(0).get("terminalId"));
        }
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .get(getApiUrl() + CASH_MANAGER + CASH_SUMMARY);
        storeResponseToTestSession(response);
    }
}

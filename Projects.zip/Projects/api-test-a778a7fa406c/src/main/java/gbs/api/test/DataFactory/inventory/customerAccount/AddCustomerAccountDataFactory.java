package gbs.api.test.DataFactory.inventory.customerAccount;

import gbs.api.test.common.CommonActions;
import gbs.api.test.request.inventory.customerAccount.AddCustomerAccountRequest;
import gbs.api.test.utils.Configuration;
import net.thucydides.core.annotations.Steps;

import java.util.Map;

public class AddCustomerAccountDataFactory {
    @Steps
    private CommonActions commonActions;

    public AddCustomerAccountRequest generateAddCustomerAccountPayload(String customerID, Map<String, String> requestValues) {
        String shopID = commonActions.getShopID(requestValues.get("shopId"));
        String terminalID = commonActions.getTerminalID(requestValues.get("terminalId"));
        String prefixAccountName = Configuration.get("prefixAccountName");

        return AddCustomerAccountRequest.builder()
                .accountName(prefixAccountName + shopID + "_" + terminalID)
                .customerId(customerID)
                .build();
    }
}

package gbs.api.test.DataFactory.auditManagement.shopData;


import gbs.api.test.common.CommonActions;
import gbs.api.test.request.auditManagement.shopData.AmountRangeRequest;
import gbs.api.test.request.auditManagement.shopData.BOGlobalViewRequest;
import gbs.api.test.request.auditManagement.shopData.GlobalViewDateRangeRequest;
import gbs.api.test.utils.TestDataReader;
import net.thucydides.core.annotations.Steps;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

public class BOGloblaViewDataFactory {
    @Steps
    private ShopDataFactory shopDataFactory;
    @Steps
    private CommonActions commonActions;

    public BOGlobalViewRequest getFilteredBOGlobalViewData(Map<String, String> requestValues) {
        List<String> shopId = new ArrayList<>();
        String terminalId;
        List<String> id = new ArrayList<>();
        List<String> brand = new ArrayList<>();
        List<String> country = new ArrayList<>();
        List<String> currency = new ArrayList<>();
        List<String> regionAreaCode = new ArrayList<>();
        List<String> regionCode = new ArrayList<>();
        List<String> userName = new ArrayList<>();
        List<String> dateRange = new ArrayList<>();

        String shop = commonActions.getShopID(requestValues.get("shopId"));
        shopId.add(shop);
        terminalId = commonActions.getTerminalID(requestValues.get("terminalId"));
        brand.add(commonActions.getBrandName(requestValues.get("brand")));
        country.add("");
        regionAreaCode.add("");
        regionCode.add("");
        currency.add(commonActions.getCurrency(requestValues.get("currency")));
        userName.add("");
        dateRange.add("");
        dateRange.add("");
        if (requestValues.get("status").contains("BET")) {
            id.add(TestDataReader.getFieldValueFromTestDataJson("auditFilterBetId".trim(), "BetIds"));
        } else if (requestValues.get("status").contains("VT")) {
            id.add(TestDataReader.getFieldValueFromTestDataJson("valueTicket".trim(), "BetIds"));
        } else {
            id.add("");
        }

        return BOGlobalViewRequest.builder()
                .amountRange(getAmountRange(requestValues))
                .brand(brand)
                .country(country)
                .currency(currency)
                .dateRange(getDateRange(Integer.valueOf(requestValues.get("dateRange"))))
                .id(id)
                .regionAreaCode(regionAreaCode)
                .regionCode(regionCode)
                .shopId(shopId)
                .status(id)
                .terminalId(terminalId)
                .transactionType(shopDataFactory.getTransactionType(requestValues))
                .userName(userName)
                .build();
    }

    public GlobalViewDateRangeRequest getDateRange(int days) {
        String minDateRange = "";
        String maxDateRange = "";
        if (days > 0) {
            LocalDateTime pastDateTime = LocalDateTime.now(ZoneOffset.UTC).minusDays(days);
            minDateRange = String.valueOf(pastDateTime.toEpochSecond(ZoneOffset.UTC));
            maxDateRange = String.valueOf(Instant.now().getEpochSecond());
        }
        return GlobalViewDateRangeRequest.builder()
                .maxValue(maxDateRange)
                .minValue(minDateRange)
                .build();
    }

    public AmountRangeRequest getAmountRange(Map<String, String> requestValues) {
        if (requestValues.get("amountMaxValue").equals("String") && requestValues.get("amountMinValue").equals("String")) {
            return AmountRangeRequest.builder()
                    .maxValue("")
                    .minValue("")
                    .build();
        }
        return AmountRangeRequest.builder()
                .maxValue(requestValues.get("amountMaxValue"))
                .minValue(requestValues.get("amountMinValue"))
                .build();
    }
}

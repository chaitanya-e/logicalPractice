package gbs.api.test.response.auditManagement.shopData;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)


public class AuditLog extends ResponseEntity {

    private String amlDecisionStatus;
    private String brand;
    private String category;
    private String id;
    private String level;
    private String message;
    private String operation;
    private String shopId;
    private String source;
    private String status;
    private String terminalId;
    private String timestamp;
    private String transactionId;
    private String transactionType;
    private String userId;
    private String userName;
    private String value;
    private String ticketType;
    private String country;
    private String regionCode;
    private String regionAreaCode;

}

package gbs.api.test.steps.omnia.cashManager.cashClearance;

import gbs.api.test.DataFactory.ominia.cashManager.cashClearance.CashClearanceDataFactory;
import gbs.api.test.common.CommonActions;
import gbs.api.test.steps.omnia.cashManager.cashSummary.CashSummarySteps;
import gbs.api.test.utils.SessionKeys;
import gbs.api.test.verify.GenericRestVerify;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import static org.hamcrest.MatcherAssert.assertThat;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

import static gbs.api.test.utils.Constants.CASH_CLEARANCE;
import static gbs.api.test.utils.Constants.CASH_MANAGER;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.lessThanOrEqualTo;


public class CashClearanceSteps extends CommonActions {

    @Steps
    private GenericRestVerify genericRestVerify;

    @Steps
    private SessionKeys sessionKeys;

    @Steps
    private CashClearanceDataFactory cashClearanceDataFactory;

    @Steps
    private CashSummarySteps cashSummarySteps;

    private String terminalId;


    private long fromDate;
    private long toDate;

    public void getCashClearanceDetailsGetRequest(List<Map<String, String>> requestValues) {
        if (requestValues.get(0).containsKey("terminalId")) {
            terminalId = getTerminalID(requestValues.get(0).get("terminalId"));
        }

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(setFromAndToDate(requestValues.get(0)))
                .get(getApiUrl() + CASH_MANAGER + CASH_CLEARANCE);
        storeResponseToTestSession(response);
    }

    public Map<String, Long> setFromAndToDate(Map<String, String> requestValues) {
        Map<String, Long> headersMap = new HashMap<>();
        toDate = LocalDateTime.now(ZoneOffset.UTC).toEpochSecond(ZoneOffset.UTC);

        if (requestValues.containsKey("defaultHour")) {
            fromDate = LocalDateTime.now(ZoneOffset.UTC).minusHours(Integer.parseInt(requestValues.get("defaultHour"))).toEpochSecond(ZoneOffset.UTC);
        }
        if (requestValues.containsKey("fromDate")) {
            headersMap.put("from", setFromDate(requestValues.get("fromDate")));
        }
        if (requestValues.containsKey("toDate")) {
            headersMap.put("to", setToDate(requestValues.get("toDate")));
        }
        return headersMap;
    }

    public void verifyCashClearanceDatetime(Response response, String fieldName, String listFieldName, String pojoFileName) {
        List<Object> cashClearanceDatetimeList = genericRestVerify.getValuesInListForEntity(response, pojoFileName, listFieldName, fieldName);
        for (Object cashClearanceDatetime : cashClearanceDatetimeList) {
            assertThat(Long.parseLong((String) cashClearanceDatetime), greaterThanOrEqualTo(fromDate));
            assertThat(Long.parseLong((String) cashClearanceDatetime), lessThanOrEqualTo(toDate));
        }
    }

    public void postCashClearancePostRequest(List<Map<String, String>> requestValues) {
        List<Map<String, String>> newRequestValues = cashClearancePayloadDetails(requestValues);
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(newRequestValues.get(0)))
                .headers(setUserIdHeader(newRequestValues.get(0)))
                .headers("UserName", getUserName())
                .body(cashClearanceDataFactory.generateCashClearancePayload(newRequestValues.get(0)))
                .post(getApiUrl() + CASH_MANAGER + CASH_CLEARANCE);
        storeResponseToTestSession(response);
    }


    public void postCashClearancePostRequestNotesAndCoinsPassedFromFeature(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(setUserIdHeader(requestValues.get(0)))
                .headers("UserName", getUserName())
                .body(cashClearanceDataFactory.generateCashClearancePayload(requestValues.get(0)))
                .post(getApiUrl() + CASH_MANAGER + CASH_CLEARANCE);
        storeResponseToTestSession(response);
    }


    public List<Map<String, String>> cashClearancePayloadDetails(List<Map<String, String>> requestValues) {
        cashSummarySteps.getCashSummaryDetailsGetRequest(requestValues);
        Response response = getResponseFromTestSession();
        genericRestVerify.checkResponseCodeIs(response, 200);
        String totalCoins = genericRestVerify.getResponseValuesAsListMap(response).get(0).get("totalCoins");
        String totalNotes = genericRestVerify.getResponseValuesAsListMap(response).get(0).get("totalNotes");
        List<Map<String, String>> newRequestValues = new ArrayList<>();
        Map<String, String> map = new HashMap<>(requestValues.get(0));
        map.put("expectedAmountCoins", totalCoins);
        map.put("expectedAmountNotes", totalNotes);
        map.put("countedAmountCoins", totalCoins);
        map.put("countedAmountNotes", totalNotes);
        newRequestValues.add(map);
        return newRequestValues;
    }

    public long setFromDate(String featureFromDate) {
        if ("sysDate".equalsIgnoreCase(featureFromDate.trim())) {
            fromDate = LocalDateTime.now(ZoneOffset.UTC).toEpochSecond(ZoneOffset.UTC);
        } else if (featureFromDate.trim().contains("-")) {
            fromDate = LocalDateTime.now(ZoneOffset.UTC).minusHours(Integer.parseInt(featureFromDate.split("-")[1].trim())).toEpochSecond(ZoneOffset.UTC);
        }
        return fromDate;
    }

    public long setToDate(String featureToDate) {
        if ("sysDate".equalsIgnoreCase(featureToDate.trim())) {
            toDate = LocalDateTime.now(ZoneOffset.UTC).toEpochSecond(ZoneOffset.UTC);
        } else if (featureToDate.trim().contains("-")) {
            toDate = LocalDateTime.now(ZoneOffset.UTC).minusHours(Integer.parseInt(featureToDate.split("-")[1].trim())).toEpochSecond(ZoneOffset.UTC);
        }
        return toDate;
    }

    public void verifyTerminalId(Response response, String listFieldName, String pojoFileName, List<Map<String, String>> requestValues) {
        String terminalID = getTerminalID(requestValues.get(0).get("terminalId"));
        List<Map<String, String>> newRequestValues = new ArrayList<>();
        Map<String, String> newMap = new HashMap<>(requestValues.get(0));
        newMap.put("terminalId", terminalID);
        newRequestValues.add(newMap);
        genericRestVerify.checkResponseValuesInList(response, pojoFileName, listFieldName, newRequestValues);
    }
}

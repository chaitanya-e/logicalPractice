package gbs.api.test.response.auditManagement.shopData;


import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)

public class AuditManagementBOGlobalViewDataResponse extends ResponseEntity {

    private List<BOGlobalViewLog> bOGlobalViewList;
    private Integer totalCount;

}

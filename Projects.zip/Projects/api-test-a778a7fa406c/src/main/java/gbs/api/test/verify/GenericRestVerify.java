package gbs.api.test.verify;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import gbs.api.test.response.ResponseEntity;
import gbs.api.test.response.ResponsePojosDictionary;
import io.restassured.response.Response;
import org.assertj.core.api.SoftAssertions;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

public class GenericRestVerify {
    private static Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public String getResponseAsRawString(Response response) {
        return response.asString();
    }

    public <T> T getResponseAsJsonObject(Response response, Class<T> className) {
        return gson.fromJson(getResponseAsRawString(response), className);
    }

    public <T extends ResponseEntity> T getResponseEntityAsJsonObject(Response response, Class<T> className) {
        return getResponseAsJsonObject(response, className);
    }

    public void checkResponseCodeIs(Response response, final int responseCode) {
        assertThat(response.statusCode())
                .as("Mismatch status code!")
                .isEqualTo(responseCode);
    }

    public void checkValuesInFieldsForEntity(Response response, String pojoName,
                                             Map<String, String> data) {
        Class<? extends ResponseEntity> clazzName = ResponsePojosDictionary.getPojoClass(pojoName);
        SoftAssertions softAssert = new SoftAssertions();
        data.forEach((key, value) -> {
            Object actualValue = getResponseEntityAsJsonObject(response, clazzName).getValue(key);
            softAssert.assertThat(actualValue == null ? "null" : actualValue.toString().trim())
                    .as(key + " actual value is not matched").isEqualTo(data.get(key));
        });
        softAssert.assertAll();
    }

    public Object getValueForEntity(Response response, String pojoName, String fieldName) {
        Class<? extends ResponseEntity> clazz = ResponsePojosDictionary.getPojoClass(pojoName);
        return getResponseEntityAsJsonObject(response, clazz).getValue(fieldName);
    }

    public List<Object> getListForEntity(Response response, String pojoName, String fieldName) {
        Class<? extends ResponseEntity> clazz = ResponsePojosDictionary.getPojoClass(pojoName);
        return getResponseEntityAsJsonObject(response, clazz).getList(fieldName);
    }

    public void checkValueForEntity(Response response, String pojoName, String fieldName,
                                    Object expectedValue) {
        Class<? extends ResponseEntity> clazz = ResponsePojosDictionary.getPojoClass(pojoName);
        Object actualValue = getResponseEntityAsJsonObject(response, clazz).getValue(fieldName);
        actualValue = String.valueOf(actualValue).trim();
        assertThat(actualValue).as(actualValue + " actual value is not matched")
                .isEqualTo(String.valueOf(expectedValue));
    }

    public void checkSizeOfList(Response response, String pojoName, String listFieldName, int expectedSize) {
        List<?> actualListEntity = getListForEntity(response, pojoName, listFieldName);
        assertThat(actualListEntity.size()).as(actualListEntity.size() + " actual value is not matched")
                .isEqualTo(expectedSize);
    }

    public void checkResponseValuesInList(Response response, String pojoName, final String listName,
                                          final List<Map<String, String>> expectedValues) {
        Class<? extends ResponseEntity> clazzName = ResponsePojosDictionary.getPojoClass(pojoName);
        List<?> actualListEntity = getResponseEntityAsJsonObject(response, clazzName).getList(listName);
        List<ComparableMap> actual = getComparableMapsFromEntities(actualListEntity);
        SoftAssertions softAssert = new SoftAssertions();
        for (int index = 0; index < expectedValues.size(); index++) {
            ComparableMap actualMap = actual.get(index);
            Map<String, String> expectedMap = expectedValues.get(index);
            for (String key : expectedMap.keySet()) {
                softAssert.assertThat(expectedMap.get(key))
                        .as("values are not matching! for the key: " + key)
                        .isEqualTo(actualMap.get(key));
            }
        }
        softAssert.assertAll();
    }

    public List<ComparableMap> getComparableMapsFromEntities(final List<?> objects) {
        return objects.stream().map(ComparableMap::new).collect(Collectors.toList());
    }

    public List<Object> getValuesInListForEntity(Response response, String pojoName, final String listName, final String fieldName) {
        Class<? extends ResponseEntity> clazzName = ResponsePojosDictionary.getPojoClass(pojoName);
        List<?> actualListEntity = getResponseEntityAsJsonObject(response, clazzName).getList(listName);
        List<ComparableMap> actualListMap = getComparableMapsFromEntities(actualListEntity);
        return actualListMap.stream().map(actualMap -> actualMap.get(fieldName)).collect(Collectors.toList());
    }

    public void verifyListValues(List<String> list1, List<String> list2) {
        List<String> list1Value = list1.stream().distinct().collect(Collectors.toList());
        List<String> list2Value = list2.stream().distinct().collect(Collectors.toList());
        assertThat(list1Value).containsExactlyInAnyOrderElementsOf(list2Value);
    }

    /* applicable for
   [
     {
       "terminalId": "01",
       "totalCash": 1000,
       "totalCoins": 0,
       "totalNotes": 1000,
       "balance": 0,
       "status": "UNLOCKED",
       "currency": "GBP"
     },
     {
       "terminalId": "02",
       "totalCash": 0,
       "totalCoins": 0,
       "totalNotes": 0,
       "balance": 0,
       "status": "UNLOCKED",
       "currency": "GBP"
     }
   ]
   */

    public List<Map<String, String>> getResponseValuesAsListMap(Response response) {
        String jsonString = getResponseAsRawString(response);
        return new Gson().fromJson(jsonString, new TypeToken<List<Map<String, String>>>() {
        }.getType());
    }

    public void verifyResponseValuesInList(Response response, final List<Map<String, String>> expectedValues) {
        List<Map<String, String>> actual = getResponseValuesAsListMap(response);
        SoftAssertions softAssert = new SoftAssertions();
        for (int index = 0; index < expectedValues.size(); index++) {
            Map<String, String> actualMap = actual.get(index);
            Map<String, String> expectedMap = expectedValues.get(index);
            for (String key : expectedMap.keySet()) {
                softAssert.assertThat(expectedMap.get(key))
                        .as("values are not matching! for the key: " + key)
                        .isEqualTo(actualMap.get(key));
            }
        }
        softAssert.assertAll();
    }

    public void verifyResponseKeyList(Response response, List<String> expectedResponseKey) {
        List<Map<String, String>> actual = getResponseValuesAsListMap(response);
        SoftAssertions softAssert = new SoftAssertions();
        for (int index = 0; index < actual.size(); index++) {
            Set<String> keySet = getResponseValuesAsListMap(response).get(index).keySet();
            int count = 0;
            for (String key : keySet) {
                softAssert.assertThat(key).as("actual key are not matching! for the expected key" + key)
                        .isEqualTo(expectedResponseKey.get(count).trim());
                count++;
            }
        }
        softAssert.assertAll();
    }

    public void verifyResponseValues(Response response, final List<Map<String, String>> expectedValues, String object) {
        List<Map<String, String>> actual = getResponseValuesAsListMap(response);
        Map<String, String> expectedMap = expectedValues.get(0);
        SoftAssertions softAssert = new SoftAssertions();
        for (int index = 0; index < actual.size(); index++) {
            Map<String, String> actualMap = actual.get(index);
            if (actualMap.get(object).equalsIgnoreCase(expectedMap.get(object))) {
                Set<String> keySet = expectedValues.get(0).keySet();

                for (String key : keySet) {
                    softAssert.assertThat(expectedMap.get(key)).as("values are not matching! for the key: tvDecoderIpAddress")
                            .isEqualTo(actualMap.get(key).trim());
                }
            }
            softAssert.assertAll();
        }
    }
}



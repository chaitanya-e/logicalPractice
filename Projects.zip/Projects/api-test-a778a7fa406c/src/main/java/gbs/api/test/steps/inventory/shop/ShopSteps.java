package gbs.api.test.steps.inventory.shop;
//
//import gbs.api.test.DataFactory.inventory.shop.AddShopDataFactory;
//import gbs.api.test.utils.SessionKeys;
//import io.restassured.response.Response;
//import net.serenitybdd.rest.SerenityRest;
//import net.thucydides.core.annotations.Steps;
//import gbs.api.test.common.CommonActions;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.util.List;
//import java.util.Map;
//
//import static gbs.api.test.utils.Constants.*;
//
//public class ShopSteps extends CommonActions {
//
//    private static final Logger LOGGER = LoggerFactory.getLogger(ShopSteps.class);
//
//    @Steps
//    private AddShopDataFactory addShopDataFactory;
//
//    @Steps
//    private SessionKeys sessionKeys;
//
//    public void addShopPostRequest(List<Map<String, String>> requestValues) {
//        String shopID = getShopID(requestValues.get(0).get("shopId"));
//        Response response = SerenityRest.given()
//                .headers(setContentTypeHeader())
//                .headers(setApiKeyAndBearerTokenHeaders())
//                .body(addShopDataFactory.generateAddShopPayload(requestValues.get(0), shopID))
//                .when()
//                .post(getApiUrl() + INVENTORY + ADD_SHOP);
//        storeResponseToTestSession(response);
//        if (response.statusCode() == 201) {
//            sessionKeys.setData(SessionKeys.DataKeys.NEW_SHOP_CREATED, shopID);
//            String newShops = sessionKeys.getData(SessionKeys.DataKeys.NEW_AUTOMATION_SHOP);
//            if (newShops != null) {
//                newShops = newShops + "," + shopID;
//                sessionKeys.setData(SessionKeys.DataKeys.NEW_AUTOMATION_SHOP, newShops);
//            } else {
//                sessionKeys.setData(SessionKeys.DataKeys.NEW_AUTOMATION_SHOP, shopID);
//            }
//
//            LOGGER.info("Created the Shop ID: " + shopID);
//        }
//    }
//
//    public void modifyShopPutRequest(List<Map<String, String>> requestValues) {
//        String shopID = getShopID(requestValues.get(0).get("shopId"));
//        Response response = SerenityRest.given()
//                .headers(setContentTypeHeader())
//                .headers(setApiKeyAndBearerTokenHeaders())
//                .body(addShopDataFactory.generateAddShopPayload(requestValues.get(0), shopID))
//                .when()
//                .put(getApiUrl() + INVENTORY + ADD_SHOP);
//        storeResponseToTestSession(response);
//    }
//
//    public void getShopByIdGetRequest(List<Map<String, String>> requestValues) {
//        Response response = SerenityRest.given()
//                .headers(setContentTypeHeader())
//                .headers(setApiKeyAndBearerTokenHeaders())
//                .when()
//                .get(getApiUrl() + INVENTORY + SHOP
//                        + getShopID(requestValues.get(0).get("shopId")) + "/"
//                        + getBrandName(requestValues.get(0).get("brandName")));
//        storeResponseToTestSession(response);
//    }
//
//    public void getShopByBrandGetRequest(List<Map<String, String>> requestValues) {
//        Response response = SerenityRest.given()
//                .headers(setContentTypeHeader())
//                .headers(setApiKeyAndBearerTokenHeaders())
//                .when()
//                .get(getApiUrl() + INVENTORY + GET_SHOPS + BRAND
//                        + getBrandName(requestValues.get(0).get("brandName")));
//        storeResponseToTestSession(response);
//    }
//
//    public void getShopByShopsGetRequest() {
//        Response response = SerenityRest.given()
//                .headers(setContentTypeHeader())
//                .headers(setApiKeyAndBearerTokenHeaders())
//                .when()
//                .get(getApiUrl() + INVENTORY + GET_SHOP);
//        storeResponseToTestSession(response);
//    }

//    public void deleteShopDeleteRequest(List<Map<String, String>> requestValues) {
//        List<String> doNotDeleteShopIds = getDoNotDeleteShops();
//        String shopID = getShopID(requestValues.get(0).get("shopId"));
//
//        if (shopID.equalsIgnoreCase(getShopID("valid")) || doNotDeleteShopIds.contains(shopID)) {
//            throw new RuntimeException("We cannot delete automation shop id. create a new shop and delete for testing");
//        }
//        boolean cascade = Boolean.parseBoolean(requestValues.get(0).get("cascade"));
//        Response response = SerenityRest.given()
//                .headers(setContentTypeHeader())
//                .headers(setApiKeyAndBearerTokenHeaders())
//                .when()
//                .delete(getApiUrl() + INVENTORY + SHOP
//                        + shopID + "/"
//                        + getBrandName(requestValues.get(0).get("brandName")) + "/"
//                        + cascade);
//        storeResponseToTestSession(response);
//
//        if (response.statusCode() == 200) {
//            LOGGER.info("Deleted the Shop ID: " + shopID);
//        }
//    }
//
//}


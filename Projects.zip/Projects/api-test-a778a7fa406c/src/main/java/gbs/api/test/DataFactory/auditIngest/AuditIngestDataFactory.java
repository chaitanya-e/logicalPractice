package gbs.api.test.DataFactory.auditIngest;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class AuditIngestDataFactory {

    public Map<String, String> setDateRange(Map<String, String> requestValues) {
        Map<String, String> headersMap = new HashMap<String, String>();
        if (requestValues.get("validDate").equalsIgnoreCase("true")) {
            LocalDateTime futureDateTime = LocalDateTime.now().plusDays(Long.parseLong(requestValues.get("dateRange")));
            headersMap.put("fromTimestamp", String.valueOf(Instant.now()));
            headersMap.put("toTimestamp", String.valueOf(futureDateTime) + 'Z');
        } else {
            headersMap.put("fromTimestamp", requestValues.get("validDate"));
            headersMap.put("toTimestamp", requestValues.get("validDate"));
        }
        return headersMap;
    }

}

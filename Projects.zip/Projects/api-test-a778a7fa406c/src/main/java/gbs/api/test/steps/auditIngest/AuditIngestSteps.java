package gbs.api.test.steps.auditIngest;

import gbs.api.test.DataFactory.auditIngest.AuditIngestDataFactory;
import gbs.api.test.common.CommonActions;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.*;

public class AuditIngestSteps extends CommonActions {

    @Steps
    private AuditIngestDataFactory auditIngestDataFactory;

    public void iUpdateAuditData(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setContentTypeHeader())
                .headers(setAcceptHeader())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(auditIngestDataFactory.setDateRange(requestValues.get(0)))
                .when()
                .put(getApiUrl() + AUDIT_INGEST + AUDIT_INGEST_BULK_UPDATE);

        storeResponseToTestSession(response);
    }

    public void iInsertAuditData(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setContentTypeHeader())
                .headers(setAcceptHeader())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(auditIngestDataFactory.setDateRange(requestValues.get(0)))
                .when()
                .post(getApiUrl() + AUDIT_INGEST + AUDIT_INGEST_BULK_INSERT);

        storeResponseToTestSession(response);
    }

}

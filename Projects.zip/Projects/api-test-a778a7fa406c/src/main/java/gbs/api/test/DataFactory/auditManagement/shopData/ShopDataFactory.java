package gbs.api.test.DataFactory.auditManagement.shopData;

import gbs.api.test.common.CommonActions;
import gbs.api.test.request.auditManagement.shopData.AmountRangeRequest;
import gbs.api.test.request.auditManagement.shopData.DateRangeRequest;
import gbs.api.test.request.auditManagement.shopData.ShopDataRequest;
import gbs.api.test.utils.TestDataReader;
import net.thucydides.core.annotations.Steps;


import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;

public class ShopDataFactory {

    @Steps
    private CommonActions commonActions;

    private String shopId;
    private String terminalId;
    private String id;

    public ShopDataRequest getFilteredAuditData(Map<String, String> requestValues) {
        shopId = commonActions.getShopID(requestValues.get("shopId"));
        terminalId = commonActions.getTerminalID(requestValues.get("terminalId"));
        if (requestValues.get("status").contains("BET")) {
            id =  TestDataReader.getFieldValueFromTestDataJson("auditFilterBetId".trim(), "BetIds");
        } else if (requestValues.get("status").contains("VT")) {
            id =  TestDataReader.getFieldValueFromTestDataJson("valueTicket".trim(), "BetIds");
        } else {
            id = "";
        }

        return ShopDataRequest.builder()
                .amountRange(getAmountRange(requestValues))
                .dateRange(getDateRange())
                .id(id)
                .shopId(shopId)
                .status(getStatus(requestValues))
                .terminalId(terminalId)
                .transactionType(getTransactionType(requestValues))
                .userName(requestValues.get("userName"))
                .build();
    }

    public AmountRangeRequest getAmountRange(Map<String, String> requestValues) {
        return AmountRangeRequest.builder()
                .maxValue(requestValues.get("amountMaxValue"))
                .minValue(requestValues.get("amountMinValue"))
                .build();
    }

    public DateRangeRequest getDateRange() {

        LocalDateTime pastDateTime = LocalDateTime.now(ZoneOffset.UTC).minusMonths(1);
        long minDateRange = pastDateTime.toEpochSecond(ZoneOffset.UTC);
        long maxDateRange = Instant.now().getEpochSecond();

        return DateRangeRequest.builder()
                .maxValue(maxDateRange)
                .minValue(minDateRange)
                .build();
    }

    public List<String> getStatus(Map<String, String> requestValues) {

        List<String> status = new ArrayList<>();
        status.add(requestValues.get("status"));
        return status;

    }

    public List<String> getTransactionType(Map<String, String> requestValues) {

        List<String> transactionType = new ArrayList<>();
        transactionType.add(requestValues.get("transactionType"));
        return transactionType;

    }

}

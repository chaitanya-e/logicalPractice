package gbs.api.test.response.inventory.terminal;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)

public class TerminalLog extends ResponseEntity {
    private String shopId;
    private String brandName;
    private String terminalId;
    private String terminalType;
    private String ipAddress;
    private String macId;
    private Integer volume;
    private String terminalStatus;
    private String resolution;
    private String lockStatus;
}

package gbs.api.test.response.inventory.terminal;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)

public class InventoryTerminalResponse extends ResponseEntity {
    private List<TerminalLog> data;
    private Object status;
}

package gbs.api.test.steps.inventory.customerAccount;

import gbs.api.test.DataFactory.inventory.customerAccount.AddCustomerAccountDataFactory;
import gbs.api.test.common.CommonActions;
import gbs.api.test.utils.Configuration;
import gbs.api.test.utils.SessionKeys;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import static gbs.api.test.utils.Constants.*;

public class CustomerAccountSteps extends CommonActions {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomerAccountSteps.class);

    @Steps
    private AddCustomerAccountDataFactory addCustomerAccountDataFactory;

    @Steps
    private SessionKeys sessionKeys;

    private String brandName;
    private String shopId;
    private String terminalId;
    private String customerId;

    public String getCustomerId(String featureFileCustomerIDValue) {
        switch (featureFileCustomerIDValue.toLowerCase()) {
            case "valid":
                List<Map<String, String>> requestValues = new ArrayList<>();
                Map<String, String> values = new HashMap<>();
                values.put("shopId", "valid");
                values.put("brandName", "valid");
                values.put("terminalId", "valid");
                requestValues.add(values);
                getCustomerAccountByBrandTerminalAndShopIdGetRequest(requestValues);
                Response getCustomerIdResponse = getResponseFromTestSession();
                if (getCustomerIdResponse.statusCode() == STATUS_CODE_200I) {
                    return getCustomerIdResponse.then().extract().path("data.customerId");
                } else {
                    return "0";
                }
            case "random":
                String customerID = getRandomNumber(5);
                sessionKeys.setData(SessionKeys.DataKeys.CUSTOMER_ID, customerID);
                return customerID;
            case "existing":
                return sessionKeys.getData(SessionKeys.DataKeys.NEW_CUSTOMER_ID_CREATED);
            default:
                return featureFileCustomerIDValue;
        }
    }

    public void addCustomerAccountPostRequest(List<Map<String, String>> requestValues) {
        brandName = getBrandName(requestValues.get(0).get("brandName"));
        shopId = getShopID(requestValues.get(0).get("shopId"));
        terminalId = getTerminalID(requestValues.get(0).get("terminalId"));
        customerId = getCustomerId(requestValues.get(0).get("customerId"));

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .body(addCustomerAccountDataFactory.generateAddCustomerAccountPayload(customerId, requestValues.get(0)))
                .when()
                .post(getApiUrl() + INVENTORY + CUSTOMER_ACCOUNT + brandName + "/" + shopId + "/" + terminalId);
        storeResponseToTestSession(response);
        if (response.statusCode() == 201) {
            sessionKeys.setData(SessionKeys.DataKeys.NEW_CUSTOMER_ID_CREATED, customerId);
            LOGGER.info("Created the Customer Account: "
                    + Configuration.get("prefixAccountName") + shopId + "_" + terminalId + " with customer ID: " + customerId);
        }
    }

    public void deleteCustomerAccountDeleteRequest(List<Map<String, String>> requestValues) {
        brandName = getBrandName(requestValues.get(0).get("brandName"));
        terminalId = getTerminalID(requestValues.get(0).get("terminalId"));
        shopId = getShopID(requestValues.get(0).get("shopId"));

//        List<String> doNotDeleteShopIds = getDoNotDeleteShops();
//        if (shopId.equals(getShopID("valid")) || doNotDeleteShopIds.contains(shopId)) {
//            throw new RuntimeException("We cannot delete automation customer account. create a new customer "
//                    + "for new shop and delete for testing");
//        }

        List<String> doNotDeleteTerminalIds = getDoNotDeleteTerminals();
        if (terminalId.equals(getTerminalID("valid")) || doNotDeleteTerminalIds.contains(terminalId)) {
            throw new RuntimeException("We cannot delete automation customer account. create a new customer "
                    + "for new shop and delete for testing");
        }

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .delete(getApiUrl() + INVENTORY + CUSTOMER_ACCOUNT + brandName + "/" + shopId + "/" + terminalId);
        storeResponseToTestSession(response);

        if (response.statusCode() == 200) {
            LOGGER.info("Deleted the Customer Account: "
                    + Configuration.get("prefixAccountName") + "_" + shopId + "_" + terminalId);
        }
    }

    public void getCustomerAccountByAllGetRequest() {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .get(getApiUrl() + INVENTORY + CUSTOMER_ACCOUNT + ALL);
        storeResponseToTestSession(response);
    }

    public void getCustomerAccountByBrandGetRequest(List<Map<String, String>> requestValues) {
        brandName = getBrandName(requestValues.get(0).get("brandName"));

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .get(getApiUrl() + INVENTORY + CUSTOMER_ACCOUNT + brandName);
        storeResponseToTestSession(response);
    }

    public void getCustomerAccountByBrandAndShopIdGetRequest(List<Map<String, String>> requestValues) {
        brandName = getBrandName(requestValues.get(0).get("brandName"));
        shopId = getShopID(requestValues.get(0).get("shopId"));

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .get(getApiUrl() + INVENTORY + CUSTOMER_ACCOUNT + brandName + "/" + shopId);
        storeResponseToTestSession(response);
    }

    public void getCustomerAccountByBrandTerminalAndShopIdGetRequest(List<Map<String, String>> requestValues) {
        String brandName = getBrandName(requestValues.get(0).get("brandName"));
        String shopId = getShopID(requestValues.get(0).get("shopId"));
        String terminalId = getTerminalID(requestValues.get(0).get("terminalId"));

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .get(getApiUrl() + INVENTORY + CUSTOMER_ACCOUNT + brandName + "/" + shopId + "/" + terminalId);
        storeResponseToTestSession(response);
    }

    public void getCustomerAccountPutRequest(List<Map<String, String>> requestValues) {
        brandName = getBrandName(requestValues.get(0).get("brandName"));
        shopId = getShopID(requestValues.get(0).get("shopId"));
        terminalId = getTerminalID(requestValues.get(0).get("terminalId"));
        customerId = getCustomerId(requestValues.get(0).get("customerId"));

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .body(addCustomerAccountDataFactory.generateAddCustomerAccountPayload(customerId, requestValues.get(0)))
                .when()
                .put(getApiUrl() + INVENTORY + CUSTOMER_ACCOUNT + brandName + "/" + shopId + "/" + terminalId);
        storeResponseToTestSession(response);
    }
}

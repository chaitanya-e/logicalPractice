package gbs.api.test.response.testData;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BetIds extends ResponseEntity {

    private String invalidBetId;
    private String anyValidBet;
    private String auditFilterBetId;
    private String singles;
    private String doubles;
    private String trebles;
    private String accumulator;
    private String doublePermutation;
    private String treblePermutation;
    private String multiSingles;
    private String folds5;
    private String folds19;
    private String patent;
    private String trixie;
    private String yankee;
    private String heinz;
    private String superHeinz;
    private String canadian;
    private String goliath;
    private String lucky15;
    private String lucky31;
    private String lucky63;
    private String valueTicket;
    private String expiredSSOToken;
    private String paidOutValueTicket;
    private String inValidValueTicket;
}

package gbs.api.test.response.omnia.cashManager.EODCashup;

import com.fasterxml.jackson.annotation.JsonInclude;
import gbs.api.test.response.ResponseEntity;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)

public class TerminalOverview extends ResponseEntity {
    private String terminalId;
    private Integer totalCash;
    private Integer totalCoins;
    private Integer totalNotes;
    private Integer balance;
    private String status;
}

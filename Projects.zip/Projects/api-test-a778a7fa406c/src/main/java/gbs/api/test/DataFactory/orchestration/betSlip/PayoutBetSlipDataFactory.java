package gbs.api.test.DataFactory.orchestration.betSlip;

import gbs.api.test.common.CommonActions;
import gbs.api.test.request.orchestration.betSlip.PayoutBetSlipRequest;
import net.thucydides.core.annotations.Steps;

import java.util.Map;

import static gbs.api.test.utils.Constants.*;

public class PayoutBetSlipDataFactory {

    @Steps
    private CommonActions commonActions;

    public PayoutBetSlipRequest betPayoutWithSettledAmount(Map<String, String> requestValues) {

        Long currentUnixTime  = System.currentTimeMillis() / 1000L;

        String reqRefId = requestValues.get("reqRefId");
        Boolean isFundsAvailableAtWallet = true;
        Boolean isManualCancelled = true;

        if ("valid".equalsIgnoreCase(reqRefId)) {
            reqRefId = commonActions.getRandomNumber(10);
        }

        if (requestValues.containsKey("isFundsAvailableAtWallet")) {
            isFundsAvailableAtWallet = Boolean.valueOf(requestValues.get("isFundsAvailableAtWallet"));
        }

        if (requestValues.containsKey("isManualCancelled")) {
            isManualCancelled = Boolean.valueOf(requestValues.get("isManualCancelled"));
        }

        return PayoutBetSlipRequest.builder()
                .agentName(requestValues.get("agentName"))
                .amount(Integer.parseInt(requestValues.get("amount")))
                .currency(commonActions.getCurrency(requestValues.get("currency")))
                .description(STRING_CONSTANT)
                .isFundsAvailableAtWallet(isFundsAvailableAtWallet)
                .isManualCancelled(isManualCancelled)
                .reqRefId(reqRefId)
                .transactionDateAtOrigin(currentUnixTime)
                .voidReturns(Integer.parseInt(requestValues.get("voidReturns")))
                .winReturns(Integer.parseInt(requestValues.get("winReturns")))
                .build();
    }
}

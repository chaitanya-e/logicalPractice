package gbs.api.test.steps.orchestration.transaction;

import gbs.api.test.common.CommonActions;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;

import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.*;

public class TransactionsSteps extends CommonActions {

    public void getTransactionsGetRequest(List<Map<String, String>> requestValues) {
        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setApiKeyAndBearerTokenHeaders())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(setAccountNameSourceHeaders(requestValues.get(0)))
                .when()
                .get(getApiUrl() + ORCHESTRATOR + TRANSACTIONS + TOTAL_CASH);
        storeResponseToTestSession(response);
    }
}

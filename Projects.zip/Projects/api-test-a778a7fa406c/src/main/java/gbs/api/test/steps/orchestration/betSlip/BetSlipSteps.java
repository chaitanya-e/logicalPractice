package gbs.api.test.steps.orchestration.betSlip;

import gbs.api.test.DataFactory.orchestration.betSlip.PayoutBetSlipDataFactory;
import gbs.api.test.common.CommonActions;
import gbs.api.test.steps.retailBetSlip.retailBetSlip.RetailBetSlipSteps;
import gbs.api.test.verify.GenericRestVerify;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static gbs.api.test.utils.Constants.*;

public class BetSlipSteps extends CommonActions {

    @Steps
    private PayoutBetSlipDataFactory payoutBetSlipDataFactory;

    @Steps
    private RetailBetSlipSteps retailBetSlipSteps;

    @Steps
    private GenericRestVerify genericRestVerify;

    private Map<String, String> setSourceAndAgentHeaders(Map<String, String> values) {
        Map<String, String> headersMap = new HashMap<String, String>();
        headersMap.put("agentName", values.get("agentName"));
        headersMap.put("source", values.get("source"));
        return headersMap;
    }

    private Map<String, String> setBrandIdShopIdHeaders(Map<String, String> values) {
        Map<String, String> headersMap = new HashMap<String, String>();
        headersMap.put("brandId", getBrandName(values.get("brandId")));
        headersMap.put("shopId", getShopID(values.get("shopId")));
        return headersMap;
    }

    public void getBetSlipGetRequest(String betId, List<Map<String, String>> requestValues) {

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setAcceptHeader())
                .headers(setShopIdTerminalIdBrandHeaders(requestValues.get(0)))
                .headers(setSourceAndAgentHeaders(requestValues.get(0)))
                .headers(setApiKeyAndBearerTokenHeaders())
                .when()
                .get(getApiUrl() + ORCHESTRATOR + BET_SLIP + betId);

        storeResponseToTestSession(response);
    }

    public void payoutBetSlipPostRequest(String betId, List<Map<String, String>> requestValues) {
        Map<String, String> values = new HashMap<>(requestValues.get(0));
        if (!values.containsKey("amount")) {
            values.putAll(getSettledReturnForBet(betId));
        }

        Response response = SerenityRest.given()
                .headers(setContentTypeHeader())
                .headers(setAcceptHeader())
                .headers(setBrandIdShopIdHeaders(values))
                .headers(setAccountNameSourceHeaders(values))
                .headers(setApiKeyAndBearerTokenHeaders())
                .body(payoutBetSlipDataFactory.betPayoutWithSettledAmount(values))
                .when()
                .post(getApiUrl() + ORCHESTRATOR + BET_SLIP + PAYOUT + betId);

        storeResponseToTestSession(response);
    }

    private Map<String, String> getSettledReturnForBet(String betId) {
        List<Map<String, String>> requestValues = new ArrayList<>();
        Map<String, String> values = new HashMap<>();
        values.put("shopId", "valid");
        values.put("accountName", "valid");
        values.put("brand", "valid");
        values.put("source", "BackOffice");
        requestValues.add(values);
        retailBetSlipSteps.getRBSGetRequest(betId, requestValues);
        Response getSlipDetailsResponse = getResponseFromTestSession();
        Map<String, String> returnAmounts = new HashMap<>();
        if (getSlipDetailsResponse.statusCode() == STATUS_CODE_200I) {
            String winReturns =  String.valueOf(genericRestVerify.getValueForEntity(
                    getSlipDetailsResponse, "GetRBSDetailsResponse", "winReturns"));
            String voidReturns = String.valueOf(genericRestVerify.getValueForEntity(
                    getSlipDetailsResponse, "GetRBSDetailsResponse", "voidReturns"));
            returnAmounts.put("winReturns", winReturns);
            returnAmounts.put("voidReturns", voidReturns);
            returnAmounts.put("amount", String.valueOf(Integer.valueOf(winReturns) + Integer.valueOf(voidReturns)));
        } else {
            returnAmounts.put("winReturns", "0");
            returnAmounts.put("voidReturns", "0");
            returnAmounts.put("amount", "0");
        }

        return returnAmounts;
    }

}


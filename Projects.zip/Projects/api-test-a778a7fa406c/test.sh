mvn clean verify \
  -Dtest.env="$1" \
  -Dcucumber.options="--tags ~@defect"

mvn serenity:aggregate

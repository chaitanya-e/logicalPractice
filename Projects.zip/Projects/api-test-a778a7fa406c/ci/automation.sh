#mvn clean verify -Dtest.env="$1" -Dcucumber.options="--tags ~@defect" -s ./ci/omnia-settings.xml
echo "test cases are running on $1 environment"
echo "test cases are running on tag $2"
echo "test case type is $3"

mvn clean verify \
  -Dtest.env="$1" \
  -Dcucumber.options="--tags $2" \
  -s ./ci/omnia-settings.xml

test_status=$?

echo "###############################[generating the test reports]###############################"

mvn serenity:aggregate -s ./ci/omnia-settings.xml

if [ $test_status -eq 0 ]; then
   echo "test cases has been executed successfully"
   sh ci/success_notify.sh $1 $3
else
   echo "test cases execution has been failed"
   sh ci/failure_notify.sh $1 $3
fi
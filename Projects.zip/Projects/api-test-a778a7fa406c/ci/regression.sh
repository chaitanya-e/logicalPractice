#mvn clean verify -Dtest.env="$1" -Dcucumber.options="--tags ~@defect" -s ./ci/omnia-settings.xml
echo "test cases are running on $1 environment"
echo "test cases are running on tag $2"
echo "testRail.update.status value is $3"
echo "testRail.update.status value is $4"
echo "test case type is $5"

mvn clean verify \
  -Dtest.env="$1" \
  -Dcucumber.options="--tags $2" \
  -DtestRail.update.status="$3" \
  -DtestRail.runId="$4" \
  -s ./ci/omnia-settings.xml

test_status=$?

echo "###############################[generating the test reports]###############################"

mvn serenity:aggregate -s ./ci/omnia-settings.xml

if [ $test_status -eq 0 ]; then
   echo "test cases has been executed successfully"
   sh ci/success_notify.sh $1 $5
else
   echo "test cases execution has been failed"
   sh ci/failure_notify $1 $5
fi
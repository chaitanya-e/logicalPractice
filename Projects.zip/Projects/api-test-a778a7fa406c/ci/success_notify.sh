#! /bin/sh

#STARTED_BY=$1
#UPSTREAM_TRIGGER=$(echo "$CAUSE" | sed -e 's/[^a-zA-Z0-9-]/_/g')

#echo "the STARTED_BY being passed: $STARTED_BY"
#echo "the UPSTREAM_TRIGGER being passed: $UPSTREAM_TRIGGER"

#REPORT_URL="https://s3.console.aws.amazon.com/s3/buckets/${BASE_S3_URL}/${PROJECT_NAME}/${GIT_BRANCH/\//-}/${BUILD_NUMBER}/"
REPORT_URL="https://artifactory.bwinparty.corp/artifactory/lcgomnia-generic-local/serenity-test-reports/${PROJECT_NAME}/${GIT_BRANCH/\//-}/${BUILD_NUMBER}"

mkdir -p target/site/logs
cp log.txt target/site/logs
zip -qr $1-$2-success.zip target/site/
# copy the report to S3 so we can access it via the teams message link
#aws s3 cp "./report.zip" "s3://${BASE_S3_URL}/${PROJECT_NAME}/${GIT_BRANCH}/${BUILD_NUMBER}/" --quiet
curl -u ${ARTIFACTORY_USR}:${ARTIFACTORY_PSW} -X PUT "${REPORT_URL}/$1-$2-success.zip" -T "$1-$2-success.zip"

# send a notification to the Test Report Teams channel
curl -x infrastructure-proxy.gib1.egalacoral.com:3128 -X POST -H 'Content-type: application/json' --data '{
    "@type": "MessageCard",
    "@context": "http://schema.org/extensions",
    "themeColor": "36A64F",
    "summary": "tests passed!",
    "sections": [{
        "activityTitle": "All tests have passed in dialy sanity!!",
        "activitySubtitle": "tests results below",
        "activityImage": "https://teamsnodesample.azurewebsites.net/static/img/image5.png",
        "facts": [{
            "name": "Test Outcome",
            "value": "Success!"
        },
        {
            "name": "Report URL",
            "value": "'${REPORT_URL}/$1-$2-success.zip'"
        },
        {
            "name": "Environment",
            "value": "'$1'"
        }
        ],
        "markdown": false
    }],
      "potentialAction": [
            {
                "@context": "http://schema.org",
                "@type": "ViewAction",
                "name": "Download file",
                "target": [
                    "'${REPORT_URL}/$1-$2-success.zip'"
                ]
            }
        ]
}' https://coralracing.webhook.office.com/webhookb2/cbd98fd5-732a-4bcf-a750-538cda4c330c@60c43c0a-64ac-4050-bf3e-31e1cdfffdeb/IncomingWebhook/0ef53d6601f543a994a570bb5dbf57d6/7f793052-3d4a-4600-aa4e-8e3927248b88
/**
 * Provides the classes necessary to create WebDriver instances and to set options
 * for browsers.
 */
package drivers;

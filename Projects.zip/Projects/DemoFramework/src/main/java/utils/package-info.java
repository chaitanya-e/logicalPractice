/**
 * Provides the class to start framework execution and an abstract class to be used by test projects.
 */
package utils;

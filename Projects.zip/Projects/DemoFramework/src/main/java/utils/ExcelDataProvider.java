package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.ITestContext;
import org.testng.SkipException;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.JsonFormatter;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import drivers.Drivers;
import log4j.LogClass;
import properties.PropertiesFile;

/**
 * This is the core class of the framework. Here are used TestNG annotations.
 * Java Reflection is used to launch projects classes.
 * 
 * @author fabio.caccia
 * @author Sowdamini.Ampolu, Emani Chaitanya (Changes made for consolidated
 *         results dashboard
 *
 */
public class ExcelDataProvider {

	/**
	 * test context which contains all the information for a given test run. An
	 * instance of this context is passed to the test listeners so they can query
	 * information about their environment
	 */
	public static ITestContext context;
	
	/**
	 * Context which is set in the test to be returned.
	 */
	public static ITestContext contextToBeReturned;
	
	/**
	 * Html report
	 */
	public static ExtentSparkReporter htmlReporter;
	/**
	 * Extent report
	 */
	public static ExtentReports extent;
	/**
	 * Extent test
	 */
	public static ExtentTest test;
	/**
	 * Project path
	 */
	public static String projectPath = System.getProperty("user.dir");

	/**
	 * Iteration from parameter
	 */
	public static String iteration;
	/**
	 * Establish if to stop execution on fail
	 */
	public static String exitOnFail;
	/**
	 * The class order of execution
	 */
	public static String classOrder;
	/**
	 * Test name
	 */
	public static String testName;

	public static String suiteName;
	/**
	 * Iterations to be executed
	 */
	public static String iterationsToRun;
	/**
	 * Iterations that are consecutive
	 */
	public String[] itersConsecutive;
	/**
	 * Ordered array of iterations to run
	 */
	public List<Integer> iterations = new ArrayList<Integer>();

	public static String reportName;
	public static String reportPathAndName;
	public static String jsonFilePathAndName;

	public static String email;

	/**
	 * Browser to be opened
	 */
	public static String browser;

	/**
	 * HashMap to Store Module and Tests for Consolidated Report
	 */
	public static HashMap<String, String> module_tests_results = new HashMap<String, String>();

	/**
	 * Variables for the construction of JSON Object
	 */
	public static String runtype;
	public static String env;
	public static String label;
	public static String generatemongoreport;
	public static String projectCollectionName;
	public static String nameOfTest;
	public static String testName_final;
	public static String pathNameReport;
	public static String channel;
	public static String jenkinsRemoteToken;
	public static String jenkinsJobName;

	/**
	 * Property files path for mongo db
	 */
	static Path path = Paths.get(System.getProperty("user.dir"));
	static String dir = path.getParent().toString();
	static String configFilePath = dir + "\\SeleniumJavaFrameWork\\src\\test\\resources\\config.properties";

	
	/**
	 * This method reads the parameter values from the xml TestNG file and executes
	 * the <b>esegui()</b> method. Iterations to run are checked here. If there are
	 * iterations to be skipped, an execption will be launched. TestName, browser
	 * and class order are set here. Each test class is launched and all of its
	 * variables are set.
	 * 
	 * @param mapdata the data values from Excel, given by the data provider
	 * @param context test context which contains all the information for a given
	 *                test run. An instance of this context is passed to the test
	 *                listeners so they can query information about their
	 *                environment
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws NoSuchFieldException
	 * @throws IOException
	 */
	@Test(dataProvider = "test1data")
	public void test(Map<String, String> mapdata, ITestContext context)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException, NoSuchFieldException, IOException {

		SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
		Date date = new Date();
		String data = formatter.format(date);

		SimpleDateFormat formatter2 = new SimpleDateFormat("dd_MM_yyyy");
		Date date2 = new Date();
		String data2 = formatter2.format(date2);

		try {
			reportName = context.getName() + " Iteration " + mapdata.get("iteration") + " " + data + ".html";
			testName = context.getName();
			pathNameReport = projectPath + "\\src\\main\\resources\\report\\" + data2 + "\\" + context.getName()
					+ ".html";
			System.out.println(pathNameReport);// For checking the path
			String jsonPath = projectPath + "\\src\\main\\resources\\report\\" + data2 + "\\" + context.getName()
					+ ".json";

			reportPathAndName = pathNameReport;
			jsonFilePathAndName = jsonPath;

			htmlReporter = new ExtentSparkReporter(pathNameReport);
			htmlReporter.config().setTimelineEnabled(true);
			JsonFormatter json = new JsonFormatter(jsonPath);
			extent = new ExtentReports();
			extent.createDomainFromJsonArchive(jsonPath);
			extent.attachReporter(json, htmlReporter);

		} catch (Exception e) {
			e.printStackTrace();
		}

		test = extent.createTest(
				context.getName() + ", Iteration: " + mapdata.get("iteration") + " - " + mapdata.get("note"),
				"Browser: " + context.getCurrentXmlTest().getParameter("browser"));
		exitOnFail = context.getCurrentXmlTest().getParameter("exitonfail");
		/**
		 * New suite level parameters added in Testng.xml for consolidated results
		 * dashboard
		 */
		nameOfTest = context.getName() + ", Iteration: " + mapdata.get("iteration") + " - " + mapdata.get("note");
		runtype = getXMLParameter(context, "runType");
		label = getXMLParameter(context, "label");
		env = getXMLParameter(context, "environment");
		channel = getXMLParameter(context, "channel");
		generatemongoreport = getXMLParameter(context, "generatemongoreport");
		jenkinsRemoteToken = getXMLParameter(context, "jenkinsRemoteToken");
		jenkinsJobName = getXMLParameter(context, "jenkinsJobName");

		/**
		 * Imposto le iterazioni che devono essere eseguite
		 */
		iterationsToRun = context.getCurrentXmlTest().getParameter("iterationstorun");
		String[] iters = iterationsToRun.split(",");
		for (int i = 0; i < iters.length; i++) {
			if (iters[i].contains("-")) {
				itersConsecutive = iters[i].split("-");
				for (int j = Integer.parseInt(itersConsecutive[0]); j < Integer.parseInt(itersConsecutive[1]) + 1; j++)
					iterations.add(j);
			} else
				iterations.add(Integer.parseInt(iters[i]));
		}

		browser = context.getCurrentXmlTest().getParameter("browser");
		iteration = mapdata.get("iteration");
		classOrder = context.getCurrentXmlTest().getParameter("classorder");
		testName = context.getName();
		suiteName = context.getCurrentXmlTest().getSuite().getName();
		email = context.getCurrentXmlTest().getParameter("email");

		if (!iterations.contains(Integer.parseInt(iteration)))
			throw new SkipException("Iteration skipped: " + iteration);

		Drivers.avviaDriver(browser);
		Drivers.driver.manage().window().maximize();
		ExcelDataProvider.logInfo("Open browser: " + browser);

		File file = new File(context.getCurrentXmlTest().getParameter("resource"));
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(1);
		wb.close();

		int rowCount = sheet.getLastRowNum();

		DataFormatter df = new DataFormatter();
		for (int i = 0; i < rowCount + 1; i++) {

			String key = df.formatCellValue(sheet.getRow(i).getCell(0));
			String className = df.formatCellValue(sheet.getRow(i).getCell(1));

			Class<?> c = Class.forName(context.getCurrentXmlTest().getParameter("package") + "." + className);
			Object instance = c.getDeclaredConstructor().newInstance();

			for (Map.Entry<String, String> entry : mapdata.entrySet()) {
				if (entry.toString().split("\\.")[0].equals(key.split("\\.")[0])) {
					Field field = c.getDeclaredField(entry.getKey().substring(entry.getKey().indexOf(".") + 1));
					LogClass.logger.info("variable: " + field);
					field.set(instance, entry.getValue());
				}
			}

			Field f = c.getDeclaredField("skip");
			f.setAccessible(true);
			Object skipValue = f.get(instance);

			if (skipValue == null) {
				Method method = c.getDeclaredMethod("esegui");
				ExcelDataProvider.logInfo("Invoke method \"esegui\" from class " + c.toString());
				contextToBeReturned = context; 
				method.invoke(instance);
			} else
				ExcelDataProvider.logInfo("Class " + c.getName() + " skipped");
		}

		Drivers.driver.quit();

		try {
			extent.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method returns the current test context
	 * 
	 */
	public static ITestContext getContext() {
		return contextToBeReturned;
	}

	/**
	 * Reads the Excel file for data-driven testing and saves values into data
	 * provider
	 * 
	 * @param context test context which contains all the information for a given
	 *                test run. An instance of this context is passed to the test
	 *                listeners so they can query information about their
	 *                environment
	 * @return the values from the Excel file
	 * @throws IOException
	 */
	@DataProvider(name = "test1data")
	public Object[][] getData(ITestContext context) throws IOException {
		Object[][] obj = null;
		try {
			File file = new File(context.getCurrentXmlTest().getParameter("resource"));
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheetAt(0);
			wb.close();

			int rowCount = sheet.getLastRowNum();
			int colCount = sheet.getRow(0).getLastCellNum();

			obj = new Object[colCount - 1][1];
			DataFormatter df = new DataFormatter();
			for (int i = 0; i < colCount - 1; i++) {
				Map<String, String> datamap = new HashMap<String, String>();
				for (int j = 0; j < rowCount + 1; j++) {
					String a = df.formatCellValue(sheet.getRow(j).getCell(0));
					String b = df.formatCellValue(sheet.getRow(j).getCell(i + 1));

					if (!b.equals(""))
						datamap.put(a, b);
				}
				obj[i][0] = datamap;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}

	/**
	 * Deletes the intermediate JSON File generated during extent report creation
	 * 
	 */
	@AfterTest
	public void deleteExtentReportJSONFile() {
		ExcelDataProvider.logInfo("Deleting JSON File created during the Test for generation of extent report");
		try {
			Files.deleteIfExists(Paths.get(jsonFilePathAndName));
		} catch (NoSuchFileException e) {
			ExcelDataProvider.logInfo("No such file/directory exists, Cannot delete file - " + jsonFilePathAndName);
		} catch (DirectoryNotEmptyException e) {
			ExcelDataProvider.logInfo("Directory is not empty, Cannot delete file - " + jsonFilePathAndName);
		} catch (IOException e) {
			ExcelDataProvider.logInfo("Invalid permissions, Cannot delete file - " + jsonFilePathAndName);
		}
		ExcelDataProvider.logPass("Successfully deleted the JSON file - " + jsonFilePathAndName);
	}

	/**
	 * Reports an info message into console and log4j.
	 * 
	 * @param message the message to be reported
	 */
	public static void logInfo(String message) {
		LogClass.logger.info(message);
		// ExcelDataProvider.test.info(message);
	}

	/**
	 * Reports an info message into console and log4j. Reports the same message as a
	 * pass message
	 * 
	 * @param message the message
	 */
	public static void logPass(String message) {
		LogClass.logger.info("PASS: " + message);
		ExcelDataProvider.test.pass(message);
	}

	/**
	 * The below method iterates the json array elements to get the status,
	 * iteration, name for consolidated results dashboard
	 * 
	 * @author Sowdamini.Ampolu, Emani Chaitanya
	 * @throws IOException
	 */
	public static void iterationDataStructure(String testStatus, String testLog) throws IOException {
		try {
			/**
			 * Code Added for Consolidated Dash board Project
			 */
			if (!module_tests_results.containsKey(testName)) {
				testName_final = "";
			}

			/**
			 * testName1 has data starting from 'Iteration : #'
			 */
			String testName1 = nameOfTest.substring(nameOfTest.indexOf(",") + 1).trim();
			String reportURL = constructJenkinsURL();
			/**
			 * The testName_final should be in the below format testName_final has
			 * <Iteration_along_with_Note>@[PASS/FAIL]@reporturl@<log>|;
			 */
			testName_final = testName_final + testName1 + "@" + testStatus + "@" + reportURL + "@" + testLog + "|";

			if (module_tests_results.containsKey(testName)) {
				module_tests_results.replace(testName, testName_final);
			} else
				module_tests_results.put(testName, testName_final);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * The below method creates the json object as per the requiremnt from the
	 * eurobetMogo.jar
	 * 
	 * @author Sowdamini.Ampolu, Emani Chaitanya Construct a JSON Object for MongoDB
	 *         - Consolidated Report
	 */
	@AfterSuite(alwaysRun = true)
	public static void createJSONObject() {

		/**
		 * Code Added for Consolidated Dashboard Project
		 */
		JSONObject finalInnerJSON = new JSONObject();
		JSONObject finalOuterJSON = new JSONObject();
		JSONObject testCaseJSON;
		JSONObject testResultJSON;
		JSONObject mappingJSON;
		JSONObject reportJSON;

		JSONArray modulesArr = new JSONArray();
		JSONArray reportsArr = new JSONArray();
		JSONArray testCaseArr;
		JSONArray allMappingsArr = new JSONArray();

		String moduleReportURL = "";

		for (Map.Entry<String, String> set : module_tests_results.entrySet()) {
			mappingJSON = new JSONObject();
			testCaseArr = new JSONArray();

			String moduleName = set.getKey();

			/**
			 * Formatting of Value into multiple sub-segments
			 */
			String[] value_formatter = set.getValue().split("\\|");
			for (String iteration : value_formatter) {
				testCaseJSON = new JSONObject();
				testResultJSON = new JSONObject();

				String result[] = iteration.split("@");
				testResultJSON.put("Status", result[1]);
				String iterationText = result[0].trim();
				String logText = result[3];
				String reporturl = result[2];
				moduleReportURL = reporturl;
				testResultJSON.put("Log", logText);
				testResultJSON.put("reportUrl", reporturl);
				testCaseJSON.put(iterationText, testResultJSON);

				testCaseArr.put(testCaseJSON);
			}

			/**
			 * JSON Construction for Modules
			 */
			modulesArr.put(moduleName);

			/**
			 * JSON Array Construction for Reports Key
			 */
			reportJSON = new JSONObject();
			reportJSON.put(moduleName, moduleReportURL);
			reportsArr.put(reportJSON);

			/**
			 * JSON Construction for Test Case
			 */
			mappingJSON.put(moduleName, testCaseArr);

			allMappingsArr.put(mappingJSON);
		}

		finalInnerJSON.put("modules", modulesArr);
		finalInnerJSON.put("mapping", allMappingsArr);
		finalInnerJSON.put("reports", reportsArr);
		finalOuterJSON.put("test", runtype);
		finalOuterJSON.put("data", finalInnerJSON);
		finalOuterJSON.put("label", label);
		finalOuterJSON.put("env", env);
		finalOuterJSON.put("channel", channel);
		finalOuterJSON.put("jenkinsRemoteBuildTriggerURL", remoteJenkinsBuildTriggerURL());
		finalOuterJSON.put("moduleName", suiteName);

		String jsonAsStringObject = finalOuterJSON.toString();
		JsonObject jsonObjectForMongoDb = (JsonObject) JsonParser.parseString(jsonAsStringObject);
		ExcelDataProvider.logInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		ExcelDataProvider.logInfo(jsonAsStringObject);
		ExcelDataProvider.logInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		if (generatemongoreport.equalsIgnoreCase("yes")) {

			/**
			 * Get the details of ip, port, db name from config file and read here
			 */

			String ipAddress = PropertiesFile.getProperty("ipAddrressOfMongoDb", configFilePath);
			String propertyString = PropertiesFile.getProperty("portNumberOfMongoDb", configFilePath);
			int portNumber = Integer.parseInt(propertyString);

			/**
			 * Connect to database and create the collection as per the name of your
			 * project. projectCollectionName : This parameter indicates the collection name
			 * and is from testng.xml. eg: Columbus, vegas,PMS
			 */

			GetMongoDb mongoObj = new GetMongoDb();
			mongoObj.createConnection(ipAddress, portNumber, env, label, jsonObjectForMongoDb);

		}
	}

	/**
	 * The below method fetch the parameter values form testng.xml. If no paramters
	 * are given then it sets default values.
	 * 
	 * @author Sowdamini.Ampolu, Emani Chaitanya
	 * @param context
	 * @param parameterName
	 * @return
	 */
	public static String getXMLParameter(ITestContext context, String parameterName) {
		String returnParameter = null;
		if (context.getCurrentXmlTest().getParameter(parameterName) == null) {
			switch (parameterName) {
			case "runType":
				returnParameter = "Regression";
				break;
			case "label":
				returnParameter = "Eurobet";
				break;
			case "environment":
				returnParameter = "Test";
				break;
			case "generatemongoreport":
				returnParameter = "no";
				break;
			case "jenkinsRemoteToken":
				returnParameter = "EurobetToken";
				break;
			case "channel":
				returnParameter = "Web";
				break;
			case "jenkinsJobName":
				returnParameter = "Eurobet";
				break;
			default:
				ExcelDataProvider.logInfo("Pass Valid Arguments to method ExcelDataProvider.getXMLParameter");
			}
		} else
			returnParameter = context.getCurrentXmlTest().getParameter(parameterName);
		return returnParameter;
	}

	/**
	 * The below method will construct a url that will open the Jenkins HTML Logs
	 * 
	 * @author Sowdamini.Ampolu
	 * @return
	 */
	public static String constructJenkinsURL() {
		String ipAddressJenkins = PropertiesFile.getProperty("ipAddressOfJenkinsServer", configFilePath);
		int index = -1;
		String reportFileFromSrc = null;
		String[] arrayElementsOfFullReport = null;
		String finalURL = null;

		if (pathNameReport != null) {
			reportFileFromSrc = pathNameReport.substring(pathNameReport.indexOf("\\src"));
			arrayElementsOfFullReport = pathNameReport.split("\\\\");

			for (int i = 0; i < arrayElementsOfFullReport.length; i++) {
				if (arrayElementsOfFullReport[i].equals("src")) {
					index = i;
					break;
				}
			}
		}

		finalURL = "http://" + ipAddressJenkins + "/" + arrayElementsOfFullReport[index - 1]
				+ reportFileFromSrc.replace("\\", "/");
		ExcelDataProvider.logInfo(finalURL);
		return finalURL;
	}

	/**
	 * The below method constructs a URL that will trigger the build on Jenkins
	 * server.
	 * 
	 * @author Emani Chaitanya
	 * @return
	 */
	public static String remoteJenkinsBuildTriggerURL() {
		String ipAddressJenkins = PropertiesFile.getProperty("ipAddressOfJenkinsServer", configFilePath);
		String finalURL = "http://" + ipAddressJenkins + ":8080/buildByToken/build?job=" + jenkinsJobName
				+ "&token=" + jenkinsRemoteToken;
		ExcelDataProvider.logInfo(finalURL);
		return finalURL;
	}
}

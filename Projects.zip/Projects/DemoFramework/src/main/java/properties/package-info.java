/**
 * Provides the class to create a properties file, get a property value and set a property.
 */
package properties;

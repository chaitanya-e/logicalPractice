/**
 * Provides the class to set up the Log4J logger.
 */
package log4j;
